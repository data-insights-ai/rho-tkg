import importlib.util,json,pathlib,subprocess
root=pathlib.Path('/var/tmp/rho-v5-p07-p09-audit-20261012').resolve()
out=pathlib.Path('/var/tmp/rho-v5-ci-focused-20261012')
spec=importlib.util.spec_from_file_location('ci',root/'scripts/ci-changes.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
go='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go'
raw=subprocess.check_output([go,'list','-json','./...'],cwd=root/'v5',text=True);(out/'metadata.jsonl').write_text(raw)
base='1d29a14c^';head='1d29a14c';paths=ci.changed_paths(base,head)
directory=root/'v5/internal/graphapply';changed=[root/p for p in paths if p.startswith('v5/internal/graphapply/')]
defs={p:ci.changed_definitions(p,base) for p in changed if p.name.endswith('_test.go') and p.is_file()}
names=ci.graph_selection(directory,changed,defs)
package='github.com/data-insights-ai/rho-tkg/v5/internal/graphapply'
raw=subprocess.check_output([go,'test','-short','-list','^(Test|Fuzz|Example)',package],cwd=root/'v5',text=True);(out/'inventory.txt').write_text(raw)
ci.validate_inventory(names,raw,package)
(out/'probe.json').write_text(json.dumps({'qualificationOnlyHistoricalDiff':{'base':base,'head':head},'policy':ci.plan(paths),'requiredParents':names,'compiledSelectorsValidated':len(names),'metadataPackages':len(list(ci.json_objects((out/'metadata.jsonl').read_text())))},indent=2)+'\n')
print('PASS metadata and',len(names),'compiled graphapply selectors; no behavioral test execution')
