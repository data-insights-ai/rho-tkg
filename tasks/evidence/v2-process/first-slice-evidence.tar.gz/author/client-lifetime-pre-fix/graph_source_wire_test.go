package graphapply

import (
	"bytes"
	"encoding/binary"
	"errors"
	"testing"

	"github.com/data-insights-ai/rho-tkg/v5/internal/graphstate"
	"github.com/data-insights-ai/rho-tkg/v5/internal/raftlog"
)

// Written before principal validation. These are inert codec/budget guards,
// never evidence of Host admission, completed reads or authenticated authority.
// The principal records genuine RED output before any production correction.
func TestGraphSourceWireRequestAdmissionSymmetry(t *testing.T) {
	base := graphSourceRequest{kind: sourceGet, sequence: 7, nonce: [16]byte{3}, maximum: 128, rows: 1}
	for _, tc := range []struct {
		name string
		edit func(*graphSourceRequest)
		want error
	}{
		{"key-64KiB-plus-one", func(r *graphSourceRequest) { r.key = make([]byte, (64<<10)+1) }, errLimit},
		{"upper-64KiB-plus-one", func(r *graphSourceRequest) { r.upper = make([]byte, (64<<10)+1) }, errLimit},
		{"after-64KiB-plus-one", func(r *graphSourceRequest) { r.after = make([]byte, (64<<10)+1) }, errLimit},
		{"command-1MiB-plus-one", func(r *graphSourceRequest) { r.command = make([]byte, (1<<20)+1) }, errLimit},
		{"unknown-phase", func(r *graphSourceRequest) { r.phase = crossPhase(5) }, errInvalid},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := base
			tc.edit(&r)
			wire, err := encodeGraphSourceRequest(r)
			if !errors.Is(err, tc.want) || wire != nil {
				t.Fatalf("encoder admitted a request outside independently specified field/phase limits: bytes=%d error=%v want=%v", len(wire), err, tc.want)
			}
		})
	}
	for _, edit := range []func(*graphSourceRequest){
		func(r *graphSourceRequest) { r.key = make([]byte, 64<<10) },
		func(r *graphSourceRequest) { r.upper = make([]byte, 64<<10) },
		func(r *graphSourceRequest) { r.after = make([]byte, 64<<10) },
		func(r *graphSourceRequest) { r.command = make([]byte, 1<<20) },
		func(r *graphSourceRequest) { r.phase = crossPhase(4) },
	} {
		r := base
		edit(&r)
		wire, err := encodeGraphSourceRequest(r)
		if err != nil {
			t.Fatal("exact field boundary refused", err)
		}
		got, err := decodeGraphSourceRequest(wire)
		if err != nil || !bytes.Equal(got.key, r.key) || !bytes.Equal(got.upper, r.upper) || !bytes.Equal(got.after, r.after) || !bytes.Equal(got.command, r.command) || got.phase != r.phase {
			t.Fatal("encoder/decoder exact-boundary disagreement", err)
		}
	}
}

func TestGraphSourceWireInfoReadLimitAdmissionSymmetry(t *testing.T) {
	_, server, info, _ := sourceSessionFixture(t)
	t.Cleanup(func() { _ = server.close() })
	for _, tc := range []struct {
		name string
		edit func(*graphSourceInfo)
	}{
		{"rows-4096-plus-one", func(i *graphSourceInfo) { i.limits.Rows = 4097 }},
		{"bytes-64MiB-plus-one", func(i *graphSourceInfo) { i.limits.Bytes = (64 << 20) + 1 }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			invalid := info
			tc.edit(&invalid)
			wire, err := encodeGraphSourceInfo(invalid)
			if !errors.Is(err, errInvalid) || wire != nil {
				t.Fatalf("encoder admitted read limits beyond decoder's independent immutable ceilings: bytes=%d err=%v", len(wire), err)
			}
		})
	}
}

func TestGraphSourceWirePageMustChargeFutureAndTombstoneVisits(t *testing.T) {
	// No row is retained, yet each native logical-key visit costs at least
	// 64 metadata bytes and one nonempty key byte. Future/tombstone work counts.
	for _, tc := range []struct {
		name string
		page raftlog.ApplicationPage
	}{
		{"phantom-zero-work", raftlog.ApplicationPage{Visited: 1, Bytes: 0, Complete: true}},
		{"future-one-short", raftlog.ApplicationPage{Visited: 1, Bytes: 64, Complete: true}},
		{"two-omitted-visits-one-short", raftlog.ApplicationPage{Visited: 2, Bytes: 129, Complete: true}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			wire, err := encodeGraphSourcePage(tc.page, 128)
			if err != nil {
				if !errors.Is(err, errCorrupt) && !errors.Is(err, errInvalid) {
					t.Fatal("page shape refusal lost diagnosis", err)
				}
				return
			}
			page, err := decodeGraphSourcePage(wire, raftlog.ReadBudget{Rows: 2, Bytes: 256})
			if !errors.Is(err, errCorrupt) || page.Rows != nil || page.Next != nil || page.Visited != 0 || page.Bytes != 0 || page.Complete {
				t.Fatal("omitted logical keys escaped native source work accounting", page, err)
			}
		})
	}
	wire, err := encodeGraphSourcePage(raftlog.ApplicationPage{Visited: 2, Bytes: 130, Complete: true}, 128)
	if err != nil {
		t.Fatal(err)
	}
	page, err := decodeGraphSourcePage(wire, raftlog.ReadBudget{Rows: 2, Bytes: 130})
	if err != nil || page.Visited != 2 || page.Bytes != 130 || !page.Complete || len(page.Rows) != 0 {
		t.Fatal("valid empty-output native work counterpart", page, err)
	}
}

func TestGraphSourceRemoteBudgetNilReceiveIsInvalid(t *testing.T) {
	// Matches admit's pointer/arena boundary. No fake source or budget arena.
	for _, b := range []*graphRemoteBudget{nil, {}} {
		if err := b.receive(0, 0); !errors.Is(err, errInvalid) {
			t.Fatal("invalid budget receiver/arena became a panic or successful reservation", err)
		}
	}
	arena, err := graphstate.NewOutputBudget(128)
	if err != nil {
		t.Fatal(err)
	}
	b := newGraphRemoteBudget(materializerLimits{sourceBytes: 1, sourceRows: 1}, arena)
	if err := b.receive(0, 0); err != nil || arena.Used() != 128 {
		t.Fatal("valid zero-payload response still reserves its fixed128 bytes", err)
	}
}

// Keep the endian package available for the additional independent literal
// vectors written below while the principal executes the first RED candidates.
var _ = binary.BigEndian
