package graphapply

import (
	"bytes"
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"

	"github.com/data-insights-ai/rho-tkg/v5/internal/graphstate"
	"github.com/data-insights-ai/rho-tkg/v5/internal/graphstore"
)

// Drives the genuine six-voter in-process Host fixture. This is a transport
// unit guard; process acceptance remains the separate six OS child test.
type nativeGraphTestPump struct {
	n     *allocationTestNetwork
	group int
	host  *allocationHost
}

func (p *nativeGraphTestPump) drive(ctx context.Context, event allocationEvent) (allocationEvent, error) {
	result := event
	queue := event.packets
	result.packets = nil
	for count := 0; len(queue) > 0; count++ {
		if err := ctx.Err(); err != nil {
			return allocationEvent{}, err
		}
		if count >= 4096 {
			return allocationEvent{}, errLimit
		}
		packet := queue[0]
		queue = queue[1:]
		if packet.Snapshot || packet.To < 1 || packet.To > 3 {
			return allocationEvent{}, errInvalid
		}
		e, err := p.n.hosts[p.group][packet.To-1].Step(packet)
		if err != nil {
			return allocationEvent{}, err
		}
		if len(queue)+len(e.packets) > 128 {
			return allocationEvent{}, errLimit
		}
		queue = append(queue, e.packets...)
		result.replies = append(result.replies, e.replies...)
		result.crossReplies = append(result.crossReplies, e.crossReplies...)
		result.requestReplies = append(result.requestReplies, e.requestReplies...)
	}
	return result, nil
}
func (p *nativeGraphTestPump) Allocation(ctx context.Context, q allocationQuery) (allocationReply, error) {
	e, err := p.host.Read(q)
	if err != nil {
		return allocationReply{}, err
	}
	id := e.readID
	e, err = p.drive(ctx, e)
	if err != nil {
		return allocationReply{}, err
	}
	for _, r := range e.replies {
		if r.id == id && r.question == q {
			return r, nil
		}
	}
	return allocationReply{}, graphstore.ErrSourceUnavailable
}
func (p *nativeGraphTestPump) Cross(ctx context.Context, q crossQuery) (crossReply, error) {
	e, err := p.host.ReadCrossPhase(q.tx, q.phase, q.nonce)
	if err != nil {
		return crossReply{}, err
	}
	e, err = p.drive(ctx, e)
	if err != nil {
		return crossReply{}, err
	}
	for _, r := range e.crossReplies {
		if r.err != nil {
			return r, nil
		}
		if r.proof.question == q {
			return r, nil
		}
	}
	return crossReply{}, graphstore.ErrSourceUnavailable
}
func (p *nativeGraphTestPump) Request(ctx context.Context, q crossRequestQuestion) (crossRequestReply, error) {
	e, err := p.host.readCrossRequest(q)
	if err != nil {
		return crossRequestReply{}, err
	}
	id := e.readID
	e, err = p.drive(ctx, e)
	if err != nil {
		return crossRequestReply{}, err
	}
	for _, r := range e.requestReplies {
		if r.err != nil {
			return r, nil
		}
		if r.proof.id == id && r.proof.question == q {
			return r, nil
		}
	}
	return crossRequestReply{}, graphstore.ErrSourceUnavailable
}
func (p *nativeGraphTestPump) Submit(ctx context.Context, proposal allocationProposal) ([]byte, error) {
	e, err := p.host.Submit(proposal)
	if err != nil {
		return nil, err
	}
	if _, err = p.drive(ctx, e); err != nil {
		return nil, err
	}
	return p.host.machine.store.ApplicationRecord(ctx, p.host.driver.Applied(), true, 64<<10)
}

type nativeGraphTestTransport struct {
	service *graphPeerService
	pause   atomic.Bool
	entered chan struct{}
	release chan struct{}
}

func (p *nativeGraphTestTransport) Peer() graphPeerIdentity { return p.service.peer }
func (p *nativeGraphTestTransport) RoundTrip(ctx context.Context, wire []byte) ([]byte, error) {
	r, err := decodeGraphSourceRequest(wire)
	if err != nil {
		return nil, err
	}
	response, err := p.service.serve(ctx, wire)
	if err != nil {
		return nil, err
	}
	if p.pause.Load() && r.kind == sourceGet {
		select {
		case p.entered <- struct{}{}:
		default:
		}
		// Test-controlled reply pause AFTER real native capture/access. This does
		// not replace a proof, manufacture data or simulate physical IO failure.
		select {
		case <-ctx.Done():
			return nil, ctx.Err()
		case <-p.release:
		}
	}
	return response, nil
}
func authenticatedNativeSourceFixture(t *testing.T, ctx context.Context) (*remoteGraphSource, *nativeGraphTestTransport) {
	t.Helper()
	n, server, _, _ := sourceSessionFixture(t)
	pump := &nativeGraphTestPump{n: n, group: 0, host: n.hosts[0][0]}
	service, err := newGraphPeerService(pump.host, server, pump)
	if err != nil {
		t.Fatal(err)
	}
	transport := &nativeGraphTestTransport{service: service, entered: make(chan struct{}, 1), release: make(chan struct{})}
	output, err := graphstate.NewOutputBudget(32 << 20)
	if err != nil {
		t.Fatal(err)
	}
	endpoint, err := newGraphAuthenticatedEndpoint(n.d, transport, newGraphRemoteBudget(pump.host.machine.limits, output))
	if err != nil {
		t.Fatal(err)
	}
	source, err := endpoint.openSource(ctx)
	if err != nil {
		t.Fatal(err)
	}
	return source, transport
}
func TestGraphSourceClientOwnerCancellationStopsPausedNativeReply(t *testing.T) {
	owner, cancelOwner := context.WithCancel(t.Context())
	defer cancelOwner()
	source, transport := authenticatedNativeSourceFixture(t, owner)
	transport.pause.Store(true)
	defer close(transport.release)
	done := make(chan error, 1)
	key := graphstore.RangePublicationKey(graphstore.Namespace{Graph: graphstate.GraphID{1}, Partition: 3}, 1)
	go func() {
		row, found, err := source.Get(t.Context(), key, 64<<10)
		if found || len(row.Key)+len(row.Value) != 0 {
			done <- errors.New("cancelled native peer returned data")
			return
		}
		done <- err
	}()
	deadline, cancel := context.WithTimeout(t.Context(), 3*time.Second)
	defer cancel()
	select {
	case <-transport.entered:
	case <-deadline.Done():
		t.Fatal("native authenticated peer reply was not paused")
	}
	cancelOwner()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-deadline.Done():
		t.Fatal("client source owner cancellation did not reach in-flight RPC")
	}
	if err := source.Close(); err != nil {
		t.Fatal(err)
	}
}
func TestGraphSourceClientCloseCancelsPausedLiveQuery(t *testing.T) {
	source, transport := authenticatedNativeSourceFixture(t, t.Context())
	transport.pause.Store(true)
	defer close(transport.release)
	queryDone := make(chan error, 1)
	key := graphstore.RangePublicationKey(graphstore.Namespace{Graph: graphstate.GraphID{1}, Partition: 3}, 1)
	go func() { _, _, err := source.Get(t.Context(), key, 64<<10); queryDone <- err }()
	deadline, cancel := context.WithTimeout(t.Context(), 3*time.Second)
	defer cancel()
	select {
	case <-transport.entered:
	case <-deadline.Done():
		t.Fatal("native authenticated reply not paused")
	}
	closed := make(chan error, 1)
	go func() { closed <- source.Close() }()
	select {
	case err := <-queryDone:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-deadline.Done():
		t.Fatal("client Close waited for query mutex before initiating cancellation")
	}
	select {
	case err := <-closed:
		if err != nil {
			t.Fatal(err)
		}
	case <-deadline.Done():
		t.Fatal("client close did not release native source")
	}
}

func TestGraphSourceAuthenticatedNativeRootAndGetRoundTrip(t *testing.T) {
	for _, kind := range []string{"root", "found", "absent"} {
		t.Run(kind, func(t *testing.T) {
			source, transport := authenticatedNativeSourceFixture(t, t.Context())
			defer func() {
				if err := source.Close(); err != nil {
					t.Error(err)
				}
			}()
			lease, err := transport.service.sources.lease(source.info.cookie)
			if err != nil {
				t.Fatal(err)
			}
			if kind == "root" {
				want, err := lease.view.RootBounded(t.Context(), 172)
				if err != nil {
					t.Fatal(err)
				}
				got, err := source.RootBounded(t.Context(), 172)
				if err != nil || got.Generation != want.Generation || got.Index != want.Index || got.ImageHash != want.ImageHash || !bytes.Equal(got.Image, want.Image) || len(got.Image) != 172 {
					t.Fatal("genuine bounded native root framing", got, err)
				}
				return
			}
			key := graphstore.RangePublicationKey(graphstore.Namespace{Graph: graphstate.GraphID{1}, Partition: 3}, 1)
			if kind == "absent" {
				key = graphstore.RangePublicationKey(graphstore.Namespace{Graph: graphstate.GraphID{1}, Partition: 3}, 7)
			}
			want, found, err := lease.view.Get(t.Context(), key, 64<<10)
			if err != nil || found != (kind == "found") {
				t.Fatal("independent native point control", found, err)
			}
			got, present, err := source.Get(t.Context(), key, 64<<10)
			if err != nil || present != found || got.Deleted != want.Deleted || !bytes.Equal(got.Key, want.Key) || !bytes.Equal(got.Value, want.Value) {
				t.Fatal("genuine native point response framing", kind, present, got, err)
			}
		})
	}
}

func TestGraphSourceClientCloseUsesPrepaidCapacityAfterCallLimit(t *testing.T) {
	source, transport := authenticatedNativeSourceFixture(t, t.Context())
	// Independent protocol ceiling: consume the remaining 1022 calls after the
	// prepaid close slot and real sourceOpen, with zero-payload admissions.
	budget := source.endpoint.budget
	if budget.calls != 2 {
		t.Fatal("open did not prepay one close call", budget.calls)
	}
	for range 1022 {
		if err := budget.admit(0, 0); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := source.RootBounded(t.Context(), 172); !errors.Is(err, errLimit) {
		t.Fatal("exhausted ordinary call allowance", err)
	}
	if err := source.Close(); err != nil {
		t.Fatal("known native owner could not close after exhaustion", err)
	}
	lease, err := transport.service.sources.lease(source.info.cookie)
	if err != nil || !lease.done() {
		t.Fatal("prepaid close retained native owner", err)
	}
	if budget.calls != 1024 {
		t.Fatal("close reset/widened ordinary global calls", budget.calls)
	}
}

func TestGraphSourceQueuedAuthenticatedStreamWaitUsesCurrentCancellation(t *testing.T) {
	source, transport := authenticatedNativeSourceFixture(t, t.Context())
	transport.pause.Store(true)
	defer close(transport.release)
	first := make(chan error, 1)
	key := graphstore.RangePublicationKey(graphstore.Namespace{Graph: graphstate.GraphID{1}, Partition: 3}, 1)
	go func() { _, _, err := source.Get(t.Context(), key, 64<<10); first <- err }()
	select {
	case <-transport.entered:
	case <-time.After(3 * time.Second):
		t.Fatal("actual native reply never paused")
	}
	ctx, cancel := context.WithTimeout(t.Context(), time.Second)
	defer cancel()
	queued := make(chan error, 1)
	go func() {
		_, err := source.endpoint.call(ctx, graphSourceRequest{kind: sourceRoot, cookie: source.info.cookie, maximum: 172}, 1024)
		queued <- err
	}()
	select {
	case err := <-queued:
		if !errors.Is(err, context.DeadlineExceeded) {
			t.Fatal("queued stream deadline sentinel", err)
		}
	case <-time.After(2 * time.Second):
		source.cancel()
		<-first
		// Unblock and drain the actual queued request before Goexit.
		<-queued
		t.Fatal("cancelled request remained queued behind another authenticated RPC")
	}
	source.cancel()
	<-first
	if err := source.Close(); err != nil {
		t.Fatal(err)
	}
}
func TestGraphSourceQueuedNativeServiceWaitUsesCurrentCancellation(t *testing.T) {
	source, transport := authenticatedNativeSourceFixture(t, t.Context())
	lease, err := transport.service.sources.lease(source.info.cookie)
	if err != nil {
		t.Fatal(err)
	}
	pause := &pausedGraphSourceData{ApplicationReadSource: lease.view, entered: make(chan struct{}, 1), release: make(chan struct{})}
	lease.mu.Lock()
	lease.read = pause
	lease.mu.Unlock()
	defer close(pause.release)
	first := make(chan error, 1)
	key := graphstore.RangePublicationKey(graphstore.Namespace{Graph: graphstate.GraphID{1}, Partition: 3}, 1)
	go func() { _, _, err := source.Get(t.Context(), key, 64<<10); first <- err }()
	select {
	case <-pause.entered:
	case <-time.After(3 * time.Second):
		t.Fatal("actual native service data never paused")
	}
	// The controlled native-data entry happens after sequence publication. This
	// queued request has the same genuine caller association and owned cookie.
	wire, err := encodeGraphSourceRequest(graphSourceRequest{kind: sourceRoot, sequence: source.endpoint.stream.sequence + 1, nonce: [16]byte{213}, cookie: source.info.cookie, maximum: 172})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(t.Context(), time.Second)
	defer cancel()
	queued := make(chan error, 1)
	go func() { _, err := transport.service.serve(ctx, wire); queued <- err }()
	select {
	case err := <-queued:
		if !errors.Is(err, context.DeadlineExceeded) {
			t.Fatal("queued service deadline sentinel", err)
		}
	case <-time.After(2 * time.Second):
		lease.cancel()
		<-first
		<-queued
		t.Fatal("cancelled native service remained queued behind owned data work")
	}
	lease.cancel()
	<-first
	// Direct native close cleans the owner; the queued inert envelope does not
	// mutate this genuine endpoint's request sequence or become proof authority.
	if err := transport.service.sources.closeSource(source.info.cookie); err != nil {
		t.Fatal(err)
	}
}
