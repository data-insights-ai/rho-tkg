package graphapply

import (
	"bytes"
	"context"
	"errors"
	"io"
	"os"
	"sync"
	"testing"
	"time"

	"github.com/data-insights-ai/rho-tkg/v5/internal/graphstate"
	"github.com/data-insights-ai/rho-tkg/v5/internal/replica"
	"github.com/data-insights-ai/rho-tkg/v5/pkg/temporal"
)

// These envelopes are embedding events, not graph authority. The parent binds
// each origin to the actual configured child pipe; graph bodies remain opaque.
const (
	processSourcePackets byte = iota + 1
	processSourceRelay
	processSourceRelayCancel
	processSourcePending = 16
	processSourceWorkers = 2
)

type graphProcessEnvelope struct {
	kind             byte
	incarnation      [16]byte
	sequence, target uint64
	body             []byte
}

func encodeGraphProcessEnvelope(e graphProcessEnvelope) ([]byte, error) {
	if e.kind < processSourcePackets || e.kind > processSourceRelayCancel || e.sequence == 0 || e.incarnation == ([16]byte{}) {
		return nil, errInvalid
	}
	return processEncoding(func(w *boundedWriter) {
		w.add([]byte("GPE1"))
		w.tag(e.kind)
		w.add(e.incarnation[:])
		w.u64(e.sequence)
		w.u64(e.target)
		w.field(e.body)
	})
}
func decodeGraphProcessEnvelope(wire []byte) (graphProcessEnvelope, error) {
	c := graphCursor{b: wire}
	if !bytes.Equal(c.take(4), []byte("GPE1")) {
		return graphProcessEnvelope{}, errCorrupt
	}
	e := graphProcessEnvelope{kind: c.tag(), incarnation: c.array(), sequence: c.u64(), target: c.u64(), body: c.field(processFrameBytes - 64)}
	if c.err != nil || len(c.b) != 0 || e.kind < processSourcePackets || e.kind > processSourceRelayCancel || e.sequence == 0 || e.incarnation == ([16]byte{}) {
		return graphProcessEnvelope{}, errors.Join(errCorrupt, c.err)
	}
	return e, nil
}

type graphProcessAnswer struct {
	response processResponse
	err      error
}
type graphProcessPacketJob struct {
	origin uint64
	packet replica.Packet
}
type graphProcessRelayJob struct {
	envelope graphProcessEnvelope
	ctx      context.Context
	cancel   context.CancelFunc
}
type graphProcessHub struct {
	ctx                    context.Context
	cancel                 context.CancelFunc
	peers                  map[uint64]*graphProcessMux
	packets                chan graphProcessPacketJob
	wg                     sync.WaitGroup
	mu                     sync.Mutex
	packetBytes, delivered int
}
type graphProcessMux struct {
	p           *graphProcess
	id          uint64
	hub         *graphProcessHub
	mu, writeMu sync.Mutex
	pending     map[uint64]chan graphProcessAnswer
	relays      map[uint64]context.CancelFunc
	relayQueue  chan graphProcessRelayJob
	err         error
}

// attachGraphProcessMuxes runs only after all configured pipes exist, before the
// first campaign. Legacy child modes keep their original synchronous exchange.
func attachGraphProcessMuxes(t *testing.T, all map[uint64]*graphProcess) {
	t.Helper()
	ctx, cancel := context.WithCancel(t.Context())
	hub := &graphProcessHub{ctx: ctx, cancel: cancel, peers: make(map[uint64]*graphProcessMux), packets: make(chan graphProcessPacketJob, processPacketCount)}
	for id, p := range all {
		m := &graphProcessMux{p: p, id: id, hub: hub, pending: make(map[uint64]chan graphProcessAnswer), relays: make(map[uint64]context.CancelFunc), relayQueue: make(chan graphProcessRelayJob, processSourceWorkers)}
		hub.peers[id] = m
		p.mux = m
	}
	for _, m := range hub.peers {
		hub.wg.Go(m.readLoop)
		for range processSourceWorkers {
			hub.wg.Go(m.relayLoop)
		}
	}
	hub.wg.Go(hub.packetLoop)
	// Network cleanup is registered later and closes/reaps children first.
	t.Cleanup(func() { cancel(); hub.wg.Wait() })
}
func (m *graphProcessMux) fail(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.err != nil {
		return
	}
	m.err = err
	_ = m.p.stdin.Close()
	_ = m.p.stdout.Close()
	for _, ch := range m.pending {
		ch <- graphProcessAnswer{err: err}
	}
	clear(m.pending)
	for _, cancel := range m.relays {
		cancel()
	}
	clear(m.relays)
}
func (m *graphProcessMux) send(r processRequest, ch chan graphProcessAnswer) (uint64, error) {
	m.writeMu.Lock()
	defer m.writeMu.Unlock()
	m.mu.Lock()
	if m.err != nil {
		e := m.err
		m.mu.Unlock()
		return 0, e
	}
	if len(m.pending) >= processSourcePending {
		m.mu.Unlock()
		return 0, errLimit
	}
	m.p.sequence++
	r.sequence = m.p.sequence
	r.incarnation = m.p.incarnation
	if ch != nil {
		m.pending[r.sequence] = ch
	}
	wire, err := encodeProcessRequest(r)
	m.p.maxFrame = max(m.p.maxFrame, len(wire)+4)
	m.mu.Unlock()
	if err == nil {
		err = writeProcessFrame(m.p.stdin, wire)
	}
	if err != nil {
		m.fail(err)
	}
	return r.sequence, err
}
func (m *graphProcessMux) exchange(ctx context.Context, r processRequest) (processResponse, error) {
	ch := make(chan graphProcessAnswer, 1)
	seq, err := m.send(r, ch)
	if err != nil {
		return processResponse{}, err
	}
	select {
	case got := <-ch:
		return got.response, got.err
	case <-ctx.Done():
		m.mu.Lock()
		delete(m.pending, seq)
		m.mu.Unlock()
		_, sendErr := m.send(processRequest{op: processSourceCancel, index: seq}, nil)
		return processResponse{}, errors.Join(ctx.Err(), sendErr)
	case <-m.hub.ctx.Done():
		return processResponse{}, m.hub.ctx.Err()
	}
}
func (m *graphProcessMux) readLoop() {
	for {
		wire, err := readProcessFrame(m.p.stdout)
		if err != nil {
			m.fail(err)
			return
		}
		if bytes.HasPrefix(wire, []byte("GPE1")) {
			e, err := decodeGraphProcessEnvelope(wire)
			m.mu.Lock()
			valid := m.p.incarnation != ([16]byte{}) && e.incarnation == m.p.incarnation
			m.mu.Unlock()
			if err != nil || !valid {
				m.fail(errors.Join(errCorrupt, err))
				return
			}
			switch e.kind {
			case processSourcePackets:
				out, err := decodeProcessResponse(e.body)
				if err != nil || out.incarnation != e.incarnation {
					m.fail(errors.Join(errCorrupt, err))
					return
				}
				if err := m.hub.enqueue(m.id, out.packets); err != nil {
					m.fail(err)
					return
				}

			case processSourceRelay:
				m.mu.Lock()
				full := len(m.relays) >= processSourcePending
				_, duplicate := m.relays[e.sequence]
				ctx, cancel := context.WithCancel(m.hub.ctx)
				if !full && !duplicate {
					m.relays[e.sequence] = cancel
				}
				m.mu.Unlock()
				if full || duplicate {
					cancel()
					m.fail(errLimit)
					return
				}
				select {
				case m.relayQueue <- graphProcessRelayJob{e, ctx, cancel}:
				default:
					m.fail(errLimit)
					return
				}
			case processSourceRelayCancel:
				m.mu.Lock()
				cancel := m.relays[e.sequence]
				m.mu.Unlock()
				if cancel != nil {
					cancel()
				}
			}
			continue
		}
		if !bytes.HasPrefix(wire, []byte("GPR1")) {
			m.fail(errCorrupt)
			return
		}
		r, err := decodeProcessResponse(wire[4:])
		m.mu.Lock()
		if err == nil && m.p.incarnation == ([16]byte{}) {
			m.p.incarnation = r.incarnation
		}
		if err == nil && (r.incarnation != m.p.incarnation || r.sequence > m.p.sequence) {
			err = errCorrupt
		}
		ch := m.pending[r.sequence]
		delete(m.pending, r.sequence)
		m.p.maxFrame = max(m.p.maxFrame, len(wire)+4)
		m.p.maxHeld = max(m.p.maxHeld, r.stats[statViews])
		m.p.maxPinned = max(m.p.maxPinned, r.stats[statPinnedBytes])
		m.mu.Unlock()
		if err != nil {
			m.fail(err)
			return
		}
		if ch != nil {
			ch <- graphProcessAnswer{response: r}
		}
	}
}
func (h *graphProcessHub) enqueue(origin uint64, packets []replica.Packet) error {
	for _, packet := range packets {
		if packet.Snapshot || packet.From != origin || h.peers[packet.To] == nil || (packet.To <= 3) != (origin <= 3) {
			return errInvalid
		}
		cost := cap(packet.Payload) + 64
		h.mu.Lock()
		full := cost > processQueueBytes-h.packetBytes
		if !full {
			h.packetBytes += cost
		}
		h.mu.Unlock()
		if full {
			return errLimit
		}
		select {
		case h.packets <- graphProcessPacketJob{origin, packet}:
		default:
			h.mu.Lock()
			h.packetBytes -= cost
			h.mu.Unlock()
			return errLimit
		}
	}
	return nil
}
func (h *graphProcessHub) packetLoop() {
	for {
		select {
		case <-h.ctx.Done():
			return
		case job := <-h.packets:
			h.mu.Lock()
			h.packetBytes -= cap(job.packet.Payload) + 64
			h.delivered++
			full := h.delivered > processDeliveries
			h.mu.Unlock()
			if full {
				h.peers[job.origin].fail(errLimit)
				continue
			}
			ctx, cancel := context.WithTimeout(h.ctx, 10*time.Second)
			r, err := h.peers[job.packet.To].exchange(ctx, processRequest{op: processStep, packet: job.packet})
			cancel()
			if err == nil {
				err = processResponseError(r)
			}
			if err == nil {
				err = h.enqueue(job.packet.To, r.packets)
			}
			if err != nil {
				h.peers[job.origin].fail(err)
			}
		}
	}
}
func (m *graphProcessMux) relayLoop() {
	for {
		select {
		case <-m.hub.ctx.Done():
			return
		case job := <-m.relayQueue:
			e := job.envelope
			target := uint64(1)
			if e.target == 8 {
				target = 4
			} else if e.target != 3 {
				job.cancel()
				m.fail(errInvalid)
				continue
			}
			ctx, cancel := context.WithTimeout(job.ctx, 10*time.Second)
			r, err := m.hub.peers[target].exchange(ctx, processRequest{op: processSourceServe, entity: m.id, data: e.body})
			cancel()
			if err == nil {
				err = processResponseError(r)
			}
			mask := graphErrorMask(err)
			_, sendErr := m.send(processRequest{op: processSourceReply, index: e.sequence, entity: uint64(mask), data: r.aux}, nil)
			m.mu.Lock()
			delete(m.relays, e.sequence)
			m.mu.Unlock()
			job.cancel()
			if sendErr != nil {
				m.fail(sendErr)
			}
		}
	}
}

// The child pump has a single bounded native read/submission slot. This preserves
// precise error correlation even for native cross replies whose error has no ID.
// Host Step/Tick/cancel and IPC remain on the independent event lane.
type graphProcessPumpCall struct {
	ctx        context.Context
	kind       byte
	allocation allocationQuery
	cross      crossQuery
	request    crossRequestQuestion
	proposal   allocationProposal
	id         allocationReadID
	reply      chan graphProcessPumpReply
}
type graphProcessPumpReply struct {
	allocation allocationReply
	cross      crossReply
	request    crossRequestReply
	body       []byte
	err        error
}
type graphProcessChildPump struct {
	ctx      context.Context
	calls    chan *graphProcessPumpCall
	canceled chan *graphProcessPumpCall
}

func (p *graphProcessChildPump) wait(c *graphProcessPumpCall) (graphProcessPumpReply, error) {
	c.reply = make(chan graphProcessPumpReply, 1)
	select {
	case p.calls <- c:
	case <-c.ctx.Done():
		return graphProcessPumpReply{}, c.ctx.Err()
	case <-p.ctx.Done():
		return graphProcessPumpReply{}, p.ctx.Err()
	}
	select {
	case r := <-c.reply:
		return r, r.err
	case <-c.ctx.Done():
		select {
		case p.canceled <- c:
		case <-p.ctx.Done():
		}
		return graphProcessPumpReply{}, c.ctx.Err()
	case <-p.ctx.Done():
		return graphProcessPumpReply{}, p.ctx.Err()
	}
}
func (p *graphProcessChildPump) Allocation(ctx context.Context, q allocationQuery) (allocationReply, error) {
	r, e := p.wait(&graphProcessPumpCall{ctx: ctx, kind: sourceOpen, allocation: q})
	return r.allocation, e
}
func (p *graphProcessChildPump) Cross(ctx context.Context, q crossQuery) (crossReply, error) {
	r, e := p.wait(&graphProcessPumpCall{ctx: ctx, kind: sourceCrossRead, cross: q})
	return r.cross, e
}
func (p *graphProcessChildPump) Request(ctx context.Context, q crossRequestQuestion) (crossRequestReply, error) {
	r, e := p.wait(&graphProcessPumpCall{ctx: ctx, kind: sourceRequestLookup, request: q})
	return r.request, e
}
func (p *graphProcessChildPump) Submit(ctx context.Context, q allocationProposal) ([]byte, error) {
	r, e := p.wait(&graphProcessPumpCall{ctx: ctx, kind: sourceSubmit, proposal: q})
	return r.body, e
}

type graphProcessChildWriter struct {
	mu          sync.Mutex
	incarnation [16]byte
	sequence    uint64
}

func (w *graphProcessChildWriter) frame(wire []byte) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return writeProcessFrame(os.Stdout, wire)
}
func (w *graphProcessChildWriter) event(kind byte, sequence, target uint64, body []byte) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	if sequence == 0 {
		w.sequence++
		sequence = w.sequence
	}
	wire, err := encodeGraphProcessEnvelope(graphProcessEnvelope{kind, w.incarnation, sequence, target, body})
	if err != nil {
		return err
	}
	return writeProcessFrame(os.Stdout, wire)
}

type graphProcessChildTransport struct {
	peer  graphPeerIdentity
	owner *graphProcessChildRelay
}
type graphProcessChildRelay struct {
	mu      sync.Mutex
	writer  *graphProcessChildWriter
	next    uint64
	pending map[uint64]chan graphProcessPumpReply
	ctx     context.Context
}

func (p *graphProcessChildTransport) Peer() graphPeerIdentity { return p.peer }
func (p *graphProcessChildTransport) RoundTrip(ctx context.Context, wire []byte) ([]byte, error) {
	o := p.owner
	o.mu.Lock()
	if len(o.pending) >= processSourcePending {
		o.mu.Unlock()
		return nil, errLimit
	}
	o.next++
	sequence := o.next
	ch := make(chan graphProcessPumpReply, 1)
	o.pending[sequence] = ch
	o.mu.Unlock()
	defer func() { o.mu.Lock(); delete(o.pending, sequence); o.mu.Unlock() }()
	if err := o.writer.event(processSourceRelay, sequence, p.peer.scope.partition, wire); err != nil {
		return nil, err
	}
	select {
	case r := <-ch:
		return r.body, r.err
	case <-ctx.Done():
		return nil, errors.Join(ctx.Err(), o.writer.event(processSourceRelayCancel, sequence, p.peer.scope.partition, nil))
	case <-o.ctx.Done():
		return nil, o.ctx.Err()
	}
}
func graphProcessSourceFact(ctx context.Context, h *allocationHost, v graphstate.ReadView, id uint64) (certifiedProcessFact, error) {
	f := certifiedProcessFact{}
	entity, err := v.Entity(ctx, graphstate.EntityID(id))
	if err != nil || !entity.Found {
		return f, err
	}
	f.Exists = true
	h.mu.Lock()
	cfg, err := h.currentConfiguration()
	h.mu.Unlock()
	if err != nil {
		return f, err
	}
	point, err := temporal.RationalPosition(cfg.defaultAxis.Axis(), temporal.RationalInt64(0))
	if err != nil {
		return f, err
	}
	projection, err := graphstate.Project(ctx, v, graphstate.EntityID(id), point, graphstate.Effective, h.machine.limits.graph.Planner)
	if err != nil {
		return f, err
	}
	f.Active, f.Life, f.Labels = projection.Active, uint64(projection.Life), projection.Labels
	f.Source, f.Target = uint64(projection.Record.Source), uint64(projection.Record.Target)
	if entity.Record.Kind == graphstate.Node {
		scope, err := temporal.All(cfg.defaultAxis.Axis())
		if err != nil {
			return f, err
		}
		page, err := v.IncidentRelationships(ctx, graphstate.IncidentPredicate{Endpoint: graphstate.EntityID(id), Life: projection.Life, Window: scope}, 0, graphstate.ReadBudget{Rows: 16, Bytes: 64 << 10})
		if err != nil {
			return f, err
		}
		if !page.Complete {
			return f, errLimit
		}
		for _, edge := range page.Entities {
			f.Incident = append(f.Incident, uint64(edge))
		}
	}
	return f, nil
}

// Resume identifiers survive an uncertain operation. Decoding this inert
// envelope confers no phase/decision authority; only the native worker Run did.
func encodeGraphProcessCoordinatorResult(r crossProcessResult, runErr error) ([]byte, error) {
	scope, err := encodeAllocationScope(r.resume.scope)
	if err != nil {
		return nil, err
	}
	var decision []byte
	if r.decision != (crossStatus{}) {
		decision, err = encodeCrossStatus(r.decision)
		if err != nil {
			return nil, err
		}
	}
	return processEncoding(func(w *boundedWriter) {
		w.add([]byte("GCR1"))
		w.field(scope)
		w.add(r.resume.request[:])
		w.add(r.resume.tx[:])
		w.add(r.resume.business[:])
		if errors.Is(runErr, errCrossProcessPending) {
			w.tag(1)
		} else {
			w.tag(0)
		}
		w.field(decision)
	})
}
func decodeGraphProcessCoordinatorResult(response processResponse) (crossProcessResult, error) {
	c := graphCursor{b: response.aux}
	if !bytes.Equal(c.take(4), []byte("GCR1")) {
		return crossProcessResult{}, errors.Join(errCorrupt, processResponseError(response))
	}
	scope := c.field(allocationScopeBytes)
	r := crossProcessResult{}
	copy(r.resume.request[:], c.take(16))
	r.resume.tx = c.array()
	copy(r.resume.business[:], c.take(32))
	pending := c.tag()
	decision := c.field(256)
	if c.err != nil || len(c.b) != 0 || pending > 1 || r.resume.request == (requestID{}) || r.resume.tx == ([16]byte{}) || r.resume.business == ([32]byte{}) {
		return crossProcessResult{}, errors.Join(errCorrupt, c.err)
	}
	var err error
	r.resume.scope, err = decodeAllocationScope(scope)
	if err != nil {
		return crossProcessResult{}, err
	}
	if len(decision) > 0 {
		r.decision, err = decodeCrossStatus(decision)
		if err != nil || r.decision.tx != r.resume.tx {
			return crossProcessResult{}, errors.Join(errCorrupt, err)
		}
	}
	err = processResponseError(response)
	if pending == 1 {
		err = errors.Join(err, errCrossProcessPending)
	}
	return r, err
}

type graphProcessWorkerResult struct {
	request  processRequest
	response processResponse
	err      error
}

func graphSourceProcessChild(t *testing.T, h *allocationHost, o *certifiedProcessOwners, init declaredInitCommand) {
	t.Helper()
	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()
	writer := &graphProcessChildWriter{incarnation: o.incarnation}
	pump := &graphProcessChildPump{ctx: ctx, calls: make(chan *graphProcessPumpCall, processSourcePending), canceled: make(chan *graphProcessPumpCall, processSourcePending)}
	server, err := newGraphSourceServer(ctx, h, defaultGraphSourceLimits(h.machine.limits))
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if err := server.close(); err != nil {
			t.Error(err)
		}
	}()
	services := make(map[uint64]*graphPeerService)
	relay := &graphProcessChildRelay{writer: writer, pending: make(map[uint64]chan graphProcessPumpReply), ctx: ctx}
	transports := make(map[uint64]graphPeerWireTransport)
	for _, part := range []uint64{3, 8} {
		voter := uint64(1)
		if part == 8 {
			voter = 4
		}
		transports[part] = &graphProcessChildTransport{graphPeerIdentity{mustProcessScope(h, part), voter}, relay}
	}
	coordinator, err := newCrossProcessCoordinator(h, transports)
	if err != nil {
		t.Fatal(err)
	}
	requests := make(chan processRequest, processSourceWorkers)
	inputErr := make(chan error, 1)
	go func() {
		for {
			wire, e := readProcessFrame(os.Stdin)
			if e != nil {
				inputErr <- e
				return
			}
			r, e := decodeProcessRequest(wire)
			if e != nil {
				inputErr <- e
				return
			}
			select {
			case requests <- r:
			case <-ctx.Done():
				return
			}
		}
	}()
	results := make(chan graphProcessWorkerResult, processSourceWorkers)
	workers := make(map[uint64]context.CancelFunc)
	var wg sync.WaitGroup
	var active *graphProcessPumpCall
	queue := make([]*graphProcessPumpCall, 0, processSourcePending)
	var pause bool
	paused := make([]processRequest, 0, processSourceWorkers)
	var pauseBarrier *processRequest
	finish := func(c *graphProcessPumpCall, r graphProcessPumpReply) {
		if c.ctx.Err() == nil {
			c.reply <- r
		}
		active = nil
	}
	emit := func(e allocationEvent) error {
		if len(e.snapshotSends)+len(e.capacityReplies)+len(e.cutReplies) != 0 {
			return errInvalid
		}
		if active != nil {
			switch active.kind {
			case sourceOpen:
				if len(e.replies) > 0 {
					if len(e.replies) != 1 || e.replies[0].id != active.id {
						return errInvalid
					}
					finish(active, graphProcessPumpReply{allocation: e.replies[0]})
					e.replies = nil
				}
			case sourceCrossRead:
				if len(e.crossReplies) > 0 {
					if len(e.crossReplies) != 1 || e.crossReplies[0].err == nil && e.crossReplies[0].proof.id != active.id {
						return errInvalid
					}
					finish(active, graphProcessPumpReply{cross: e.crossReplies[0]})
					e.crossReplies = nil
				}
			case sourceRequestLookup:
				if len(e.requestReplies) > 0 {
					if len(e.requestReplies) != 1 || e.requestReplies[0].err == nil && e.requestReplies[0].proof.id != active.id {
						return errInvalid
					}
					finish(active, graphProcessPumpReply{request: e.requestReplies[0]})
					e.requestReplies = nil
				}
			}
		}
		if err := o.event(e); err != nil {
			return err
		}
		if len(e.packets) > 0 {
			wire, err := encodeProcessResponse(processResponse{incarnation: o.incarnation, sequence: 1, packets: e.packets})
			if err != nil {
				return err
			}
			return writer.event(processSourcePackets, 0, 0, wire)
		}
		return nil
	}
	startPump := func(c *graphProcessPumpCall) error {
		if c.ctx.Err() != nil {
			return nil
		}
		active = c
		var event allocationEvent
		var err error
		switch c.kind {
		case sourceOpen:
			event, err = h.Read(c.allocation)
		case sourceCrossRead:
			event, err = h.ReadCrossPhase(c.cross.tx, c.cross.phase, c.cross.nonce)
		case sourceRequestLookup:
			event, err = h.readCrossRequest(c.request)
		case sourceSubmit:
			event, err = h.Submit(c.proposal)
		}
		if err != nil {
			finish(c, graphProcessPumpReply{err: err})
			return nil
		}
		c.id = event.readID
		return emit(event)
	}
	pollSubmit := func() error {
		if active == nil || active.kind != sourceSubmit {
			return nil
		}
		c, _, err := decodeCrossCommand(active.proposal.wire, h.machine.limits)
		if err != nil {
			finish(active, graphProcessPumpReply{err: err})
			return nil
		}
		arena, err := graphstate.NewOutputBudget(h.machine.limits.outputBytes)
		if err != nil {
			return err
		}
		manifest, err := decodeCrossManifest(c.manifest, h.machine.limits, arena)
		if err != nil {
			return err
		}
		status, _, err := h.machine.observeCrossTransaction(crossQuery{tx: manifest.tx, nonce: [16]byte{1}, phase: c.phase}, h.driver.Applied())
		if errors.Is(err, replica.ErrUnavailable) {
			return nil
		}
		if err != nil {
			return err
		}
		body, err := encodeCrossStatus(status)
		finish(active, graphProcessPumpReply{body: body, err: err})
		return nil
	}
	launch := func(r processRequest) error {
		if len(workers) >= processSourceWorkers {
			return errLimit
		}
		workerCtx, stop := context.WithCancel(ctx)
		workers[r.sequence] = stop
		var service *graphPeerService
		if r.op == processSourceServe {
			if r.entity < 1 || r.entity > 6 {
				delete(workers, r.sequence)
				stop()
				return errInvalid
			}
			service = services[r.entity]
			if service == nil {
				var e error
				service, e = newGraphPeerService(h, server, pump)
				if e != nil {
					return e
				}
				services[r.entity] = service
			}
		}
		wg.Go(func() {
			out := processResponse{}
			var e error
			switch r.op {
			case processSourceServe:
				out.aux, e = service.serve(workerCtx, r.data)
			case processSourceCoordinate:
				var original partitionGraphCommand
				original, e = decodePartitionGraphCommand(r.data, h.machine.limits)
				if e == nil {
					var result crossProcessResult
					result, e = coordinator.Run(workerCtx, original.request.id, original.request.operations, original.request.revision.Provenance(), original.request.claims)
					if result.resume.request != (requestID{}) {
						var encodeErr error
						out.aux, encodeErr = encodeGraphProcessCoordinatorResult(result, e)
						e = errors.Join(e, encodeErr)
					}
				}
			case processSourceObserve:
				var read *crossProcessRead
				read, e = coordinator.OpenQuiescentSources(workerCtx)
				if e == nil {
					var fact certifiedProcessFact
					fact, e = graphProcessSourceFact(workerCtx, h, read.ReadView(), r.entity)
					if e == nil {
						out.aux, e = encodeCertifiedProcessFact(fact)
					}
					e = errors.Join(e, read.Close())
				}
			}
			select {
			case results <- graphProcessWorkerResult{r, out, e}:
			case <-ctx.Done():
			}
		})
		return nil
	}
	respond := func(r processRequest, response processResponse, err error) error {
		if len(response.aux) > 1<<20 {
			response.aux = nil
			err = errors.Join(err, errLimit)
		}
		response.incarnation, response.sequence = o.incarnation, r.sequence
		if r.op != processClose {
			var e error
			response.stats, response.cutID, response.manifestID, e = processStats(h.machine.store)
			err = errors.Join(err, e)
		}
		response.applied, response.ready = h.driver.Applied(), o.ready
		response.code, response.detail = processError(err)
		response.causeMask = processCauseMask(err)
		wire, e := encodeProcessResponse(response)
		if e != nil {
			return e
		}
		return writer.frame(append([]byte("GPR1"), wire...))
	}
	defer func() {
		cancel()
		for _, stop := range workers {
			stop()
		}
		if active != nil && active.id != (allocationReadID{}) {
			_ = h.cancelSourceRead(active.id)
		}
		wg.Wait()
	}()
	for {
		if active == nil && len(queue) > 0 {
			c := queue[0]
			queue[0] = nil
			queue = queue[1:]
			if err := startPump(c); err != nil {
				t.Fatal(err)
			}
			if err := pollSubmit(); err != nil {
				t.Fatal(err)
			}
		}
		select {
		case e := <-inputErr:
			if !errors.Is(e, io.EOF) {
				t.Error(e)
			}
			return
		case <-ctx.Done():
			return
		case c := <-pump.calls:
			if len(queue) >= processSourcePending {
				c.reply <- graphProcessPumpReply{err: errLimit}
			} else {
				queue = append(queue, c)
			}
		case c := <-pump.canceled:
			if active == c {
				if c.id != (allocationReadID{}) {
					_ = h.cancelSourceRead(c.id)
				}
				active = nil
			}
			for i, q := range queue {
				if q == c {
					queue = append(queue[:i], queue[i+1:]...)
					break
				}
			}
		case result := <-results:
			stop := workers[result.request.sequence]
			delete(workers, result.request.sequence)
			if stop != nil {
				stop()
			}
			if err := respond(result.request, result.response, result.err); err != nil {
				t.Fatal(err)
			}
		case r := <-requests:
			if r.incarnation != o.incarnation && (r.sequence != 1 || r.incarnation != ([16]byte{})) {
				t.Fatal("source IPC incarnation")
			}
			var event allocationEvent
			response := processResponse{}
			var e error
			async := false
			switch r.op {
			case processCampaign:
				event, e = h.Campaign()
			case processTick:
				event, e = h.Tick()
			case processStep:
				event, e = h.Step(r.packet)
			case processCertifiedRead:
				event, e = o.read(r)
			case processCertifiedAction:
				var p allocationProposal
				p, e = o.action(t, r, init)
				if e == nil && len(p.wire) > 0 {
					response.aux, e = encodeCertifiedProcessProposal(p)
				}
			case processPropose:
				var p allocationProposal
				p, e = decodeCertifiedProcessProposal(r.data)
				if e == nil {
					event, e = h.Submit(p)
				}
			case processStateOp:
				_, response.image, e = h.machine.store.Checkpoint()
				relay.mu.Lock()
				response.handles = []uint64{uint64(len(workers) + len(paused)), uint64(len(relay.pending))}
				relay.mu.Unlock()
			case processEntryRecord:
				response.outcome, e = h.machine.store.ApplicationRecord(ctx, r.index, true, 64<<10)
				if e == nil {
					response.changes, e = h.machine.store.ApplicationRecord(ctx, r.index, false, 1<<20)
				}
			case processCertifiedObserve:
				var fact certifiedProcessFact
				fact, e = certifiedProcessObservation(ctx, h, r.entity)
				if e == nil {
					response.aux, e = encodeCertifiedProcessFact(fact)
				}
			case processSourceReply:
				relay.mu.Lock()
				ch := relay.pending[r.index]
				relay.mu.Unlock()
				if ch != nil {
					var replyErr error
					if r.entity != 0 {
						replyErr = graphWireError{uint16(r.entity)}
					}
					ch <- graphProcessPumpReply{body: bytes.Clone(r.data), err: replyErr}
				}
			case processSourceCancel:
				if pauseBarrier != nil && pauseBarrier.sequence == r.index {
					pauseBarrier = nil
				}
				if stop := workers[r.index]; stop != nil {
					stop()
				}
				for i, q := range paused {
					if q.sequence == r.index {
						paused = append(paused[:i], paused[i+1:]...)
						break
					}
				}
			case processSourcePausedBarrier:
				if len(paused) > 0 {
					response.handles = []uint64{uint64(len(paused)), uint64(len(workers))}
				} else if pauseBarrier != nil {
					e = errLimit
				} else {
					copyRequest := r
					pauseBarrier = &copyRequest
					async = true
				}
			case processSourcePause:
				pause = r.entity != 0
				if !pause {
					for _, q := range paused {
						if e = launch(q); e != nil {
							break
						}
					}
					paused = nil
				}
			case processSourceServe, processSourceCoordinate, processSourceObserve:
				if pause && r.op == processSourceServe {
					if len(paused) >= processSourceWorkers {
						e = errLimit
					} else {
						paused = append(paused, r)
						async = true
						if pauseBarrier != nil {
							if err := respond(*pauseBarrier, processResponse{handles: []uint64{uint64(len(paused)), uint64(len(workers))}}, nil); err != nil {
								t.Fatal(err)
							}
							pauseBarrier = nil
						}
					}
				} else {
					e = launch(r)
					async = e == nil
				}
			case processClose:
				cancel()
				for _, stop := range workers {
					stop()
				}
				wg.Wait()
				e = h.Close()
				if err := respond(r, response, e); err != nil {
					t.Error(err)
				}
				return
			default:
				e = errInvalid
			}
			if async {
				continue
			}
			// Ordinary bootstrap traffic stays in its synchronous response, so existing
			// tinyGraphTransport still owns that traffic. Worker-pump packets are events.
			if e == nil {
				e = emit(allocationEvent{readID: event.readID, replies: event.replies, crossReplies: event.crossReplies, requestReplies: event.requestReplies, snapshotSends: event.snapshotSends, capacityReplies: event.capacityReplies, cutReplies: event.cutReplies})
			}
			response.packets = event.packets
			if e == nil {
				e = pollSubmit()
			}
			if err := respond(r, response, e); err != nil {
				t.Fatal(err)
			}
		}
	}
}

func TestGraphSourceProcessEnvelopeRejectsUnboundAndExtraInput(t *testing.T) {
	valid := graphProcessEnvelope{processSourceRelay, [16]byte{1}, 1, 8, []byte{1, 2}}
	wire, err := encodeGraphProcessEnvelope(valid)
	if err != nil {
		t.Fatal(err)
	}
	decoded, err := decodeGraphProcessEnvelope(wire)
	if err != nil || decoded.incarnation != valid.incarnation || decoded.target != 8 || !bytes.Equal(decoded.body, valid.body) {
		t.Fatal(decoded, err)
	}
	for _, b := range [][]byte{nil, wire[:len(wire)-1], append(bytes.Clone(wire), 0)} {
		if _, err := decodeGraphProcessEnvelope(b); !errors.Is(err, errCorrupt) {
			t.Fatal("malformed embedding frame", err)
		}
	}
	valid.incarnation = [16]byte{}
	if _, err := encodeGraphProcessEnvelope(valid); !errors.Is(err, errInvalid) {
		t.Fatal(err)
	}
	// This frame identifies only an embedding request; it never imports a proof.
}

// This guard waits for an actually queued peer call, then exercises real Host
// event progress and cancellation. It makes no certified-cut claim.
func TestGraphSourceSixProcessesPausedPeerKeepsNativeLaneAndCancels(t *testing.T) {
	n := newCertifiedProcessNetwork(t)
	n.all[4].call(t, processRequest{op: processSourcePause, entity: 1})
	source := n.all[1].call(t, processRequest{op: processCertifiedAction, entity: certifiedCreateCrossEdge, index: 3})
	proposal, err := decodeCertifiedProcessProposal(source.aux)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(t.Context())
	defer cancel()
	done := make(chan error, 1)
	go func() {
		_, err := n.all[1].exchange(ctx, processRequest{op: processSourceCoordinate, data: proposal.wire})
		done <- err
	}()
	paused := n.all[4].call(t, processRequest{op: processSourcePausedBarrier})
	if len(paused.handles) != 2 || paused.handles[0] != 1 || paused.handles[1] != 0 {
		t.Fatal("no exact paused service association", paused.handles)
	}
	for _, op := range []byte{processTick, processStateOp} {
		n.all[4].call(t, processRequest{op: op})
	}
	// An independent native quorum read also progresses on the coordinator while
	// its peer worker awaits the paused destination. The parent's event mux must
	// deliver worker packets without inventing completed read evidence.
	n.read(t, 1, observeConfiguration, 0)
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal("coordinator cancellation", err)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("canceled coordinator did not complete")
	}
	n.all[4].call(t, processRequest{op: processSourcePause})
	// Synchronize on worker terminal responses before inspecting native owners.
	// Quiescent coordinator reads exercise the same persistent endpoint streams.
	n.all[1].call(t, processRequest{op: processSourceObserve, entity: 1})
	for id, p := range n.all {
		r := p.call(t, processRequest{op: processStateOp})
		if r.stats[statViews] != 0 || r.stats[statPinnedBytes] != 0 || len(r.handles) != 2 || r.handles[0] != 0 || r.handles[1] != 0 {
			t.Fatal("canceled source owner residue", id, r.stats, r.handles)
		}
	}
	oracle := newCertifiedProcessOracle()
	n.compare(t, oracle)
}
