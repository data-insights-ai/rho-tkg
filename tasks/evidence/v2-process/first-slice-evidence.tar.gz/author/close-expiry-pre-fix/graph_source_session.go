package graphapply

import (
	"bytes"
	"context"
	"crypto/rand"
	"errors"
	"math"
	"sync"
	"time"

	"github.com/data-insights-ai/rho-tkg/v5/internal/graphstore"
	"github.com/data-insights-ai/rho-tkg/v5/internal/raftlog"
	"github.com/data-insights-ai/rho-tkg/v5/internal/replica"
)

type graphSourceLimits struct {
	sessions, calls, rows, bytes, output, frame int
	lifetime                                    time.Duration
}

func defaultGraphSourceLimits(l materializerLimits) graphSourceLimits {
	return graphSourceLimits{sessions: 2, calls: 1024, rows: l.sourceRows, bytes: l.sourceBytes, output: l.outputBytes, frame: min(2<<20, l.outputBytes), lifetime: time.Minute}
}
func (l graphSourceLimits) validate() error {
	if l.sessions < 1 || l.sessions > 16 || l.calls < 1 || l.calls > 65536 || l.rows < 1 || l.rows > 1<<20 || l.bytes < 1 || l.bytes > 64<<20 || l.output < 1 || l.output > 64<<20 || l.frame < 512 || l.frame > 2<<20 || l.lifetime <= 0 || l.lifetime > time.Minute {
		return errInvalid
	}
	return nil
}

// A cookie identifies one server-owned retained view. It is not a certificate,
// durability result or client-supplied ownership/absence assertion.
type graphSourceCookie struct {
	issuer   [16]byte
	sequence uint64
	secret   [16]byte
}
type graphSourceInfo struct {
	cookie      graphSourceCookie
	readID      allocationReadID
	nonce       [16]byte
	observation allocationObservation
	root        raftlog.ApplicationRoot
	floor       uint64
	limits      raftlog.ReadBudget
}
type graphSourceLease struct {
	mu                         sync.Mutex
	view                       *raftlog.ApplicationView
	read                       graphstore.ApplicationReadSource
	info                       graphSourceInfo
	limits                     graphSourceLimits
	ctx                        context.Context
	cancel                     context.CancelFunc
	deadline                   time.Time
	stop                       func() bool
	closed                     bool
	closeErr                   error
	calls, rows, bytes, output int
}
type graphSourceServer struct {
	mu       sync.Mutex
	host     *allocationHost
	limits   graphSourceLimits
	ctx      context.Context
	next     uint64
	slots    []*graphSourceLease
	closed   bool
	closeErr error
}

func newGraphSourceServer(ctx context.Context, h *allocationHost, l graphSourceLimits) (*graphSourceServer, error) {
	if ctx == nil || h == nil || h.machine == nil || !crossGraphAgreement(h.machine.SemanticContractID()) {
		return nil, errInvalid
	}
	if err := l.validate(); err != nil {
		return nil, err
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.closed {
		return nil, replica.ErrStopped
	}
	if h.sourceServer != nil {
		return nil, errInvalid
	}
	l.sessions = min(l.sessions, h.machine.store.ApplicationLimits().MaxViews)
	if l.sessions < 1 {
		return nil, errLimit
	}
	s := &graphSourceServer{host: h, limits: l, ctx: ctx, slots: make([]*graphSourceLease, l.sessions)}
	h.sourceServer = s
	return s, nil
}

// open borrows only this issuer's genuine completed configuration proof. Capture
// is serialized with Host events; lifetime ownership moves to the source server.
func (s *graphSourceServer) open(ctx context.Context, proof allocationProof) (info graphSourceInfo, err error) {
	if s == nil || ctx == nil {
		return info, errInvalid
	}
	h := s.host
	h.mu.Lock()
	defer h.mu.Unlock()
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return info, replica.ErrStopped
	}
	if err := errors.Join(ctx.Err(), s.ctx.Err()); err != nil {
		return info, err
	}
	if err := h.ownProof(proof, observeConfiguration); err != nil {
		return info, err
	}
	for _, lease := range s.slots {
		if lease != nil && lease.info.readID == proof.id {
			if lease.info.nonce != proof.question.nonce || lease.info.observation != proof.observation {
				return info, errInvalid
			}
			if lease.done() {
				return info, graphstore.ErrSourceUnavailable
			}
			return ownGraphSourceInfo(lease.info), nil
		}
	}
	slot := -1
	for i, lease := range s.slots {
		if lease == nil || lease.done() {
			slot = i
			break
		}
	}
	if slot < 0 || s.next == math.MaxUint64 {
		return info, errLimit
	}
	view, err := h.machine.store.ApplicationView(proof.observation.source.index)
	if err != nil {
		return info, err
	}
	defer func() {
		if err != nil {
			err = errors.Join(err, view.Close())
			info = graphSourceInfo{}
		}
	}()
	root, err := view.RootBounded(ctx, 172)
	if err != nil {
		return info, err
	}
	metadata, err := graphstore.DecodeRoot(root.Image)
	if err != nil || metadata.SemanticEpoch() != proof.observation.epoch || metadata.EffectDigest() != proof.observation.effect {
		return info, errors.Join(errInvalid, err)
	}
	l := h.machine.limits.allocation
	l.readRows, l.readBytes = min(l.readRows, s.limits.rows), min(l.readBytes, s.limits.bytes)
	q := reader{ctx: ctx, view: view, ns: h.machine.ns, base: root, limits: l, bytes: cap(root.Image)}
	floor, err := readPartitionRoundFloor(&q, proof.observation.configuration)
	if err != nil {
		return info, err
	}
	s.next++
	info = graphSourceInfo{cookie: graphSourceCookie{issuer: h.session, sequence: s.next}, readID: proof.id, nonce: proof.question.nonce, observation: proof.observation, root: root, floor: floor, limits: view.ReadLimits()}
	if _, err := rand.Read(info.cookie.secret[:]); err != nil {
		return info, err
	}
	leaseCtx, cancel := context.WithTimeout(s.ctx, s.limits.lifetime)
	lease := &graphSourceLease{view: view, read: view, info: info, limits: s.limits, ctx: leaseCtx, cancel: cancel, deadline: time.Now().Add(s.limits.lifetime), rows: q.rows, bytes: q.bytes + 4096 + cap(root.Image), output: 4096 + cap(root.Image)}
	if lease.bytes > s.limits.bytes || lease.output > s.limits.output {
		cancel()
		return graphSourceInfo{}, errLimit
	}
	lease.stop = context.AfterFunc(leaseCtx, func() { _ = lease.close() })
	s.slots[slot] = lease
	return ownGraphSourceInfo(info), nil
}

func ownGraphSourceInfo(info graphSourceInfo) graphSourceInfo {
	info.root.Image = owned(info.root.Image)
	return info
}
func (l *graphSourceLease) done() bool { l.mu.Lock(); defer l.mu.Unlock(); return l.closed }
func (l *graphSourceLease) close() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.closed {
		return l.closeErr
	}
	l.closed = true
	l.cancel()
	if l.stop != nil {
		l.stop()
	}
	l.closeErr = l.view.Close()
	return l.closeErr
}
func (s *graphSourceServer) lease(cookie graphSourceCookie) (*graphSourceLease, error) {
	if s == nil {
		return nil, errInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil, replica.ErrStopped
	}
	for _, l := range s.slots {
		if l != nil && l.info.cookie == cookie {
			return l, nil
		}
	}
	return nil, graphstore.ErrSourceUnavailable
}
func (s *graphSourceServer) close() error {
	if s == nil {
		return errInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return s.closeErr
	}
	s.closed = true
	var err error
	for _, l := range s.slots {
		if l != nil {
			err = errors.Join(err, l.close())
		}
	}
	s.closeErr = err
	return s.closeErr
}
func (s *graphSourceServer) closeSource(cookie graphSourceCookie) error {
	l, err := s.lease(cookie)
	if err != nil {
		return err
	}
	return l.close()
}

// begin/charge serialize one bounded operation against the fixed retained view.
// Lifetime expiry remains owner-side even if a client never sends another frame.
func (l *graphSourceLease) begin(ctx context.Context, rows, bytes int) error {
	if ctx == nil || rows < 0 || bytes < 0 {
		return errInvalid
	}
	if err := errors.Join(ctx.Err(), l.ctx.Err()); err != nil {
		return errors.Join(graphstore.ErrSourceUnavailable, err)
	}
	if l.closed || time.Now().After(l.deadline) {
		return graphstore.ErrSourceUnavailable
	}
	if l.calls >= l.limits.calls || rows > l.limits.rows-l.rows || bytes > l.limits.bytes-l.bytes {
		return errLimit
	}
	l.calls++
	l.rows += rows
	l.bytes += bytes
	return nil
}
func (l *graphSourceLease) charge(bytes int) error {
	if bytes < 0 || bytes > l.limits.bytes-l.bytes || bytes > l.limits.output-l.output {
		return errLimit
	}
	l.bytes += bytes
	l.output += bytes
	return nil
}
func (s *graphSourceServer) root(ctx context.Context, cookie graphSourceCookie, maximum int) (root raftlog.ApplicationRoot, err error) {
	l, err := s.lease(cookie)
	if err != nil {
		return root, err
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if maximum < 0 || maximum > 172 {
		return root, errLimit
	}
	if err := l.begin(ctx, 0, 512); err != nil {
		return root, err
	}
	root, err = l.view.RootBounded(ctx, maximum)
	if err == nil {
		err = l.charge(256 + 4*cap(root.Image))
	}
	if err != nil {
		return raftlog.ApplicationRoot{}, err
	}
	return root, nil
}
func (s *graphSourceServer) get(ctx context.Context, cookie graphSourceCookie, key []byte, maximum int) (row raftlog.KV, found bool, err error) {
	l, err := s.lease(cookie)
	if err != nil {
		return row, false, err
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if maximum < 0 || maximum > min(l.info.limits.Bytes, l.limits.frame-512) {
		return row, false, errLimit
	}
	if err := l.begin(ctx, 1, 512+4*len(key)); err != nil {
		return row, false, err
	}
	row, found, err = l.read.Get(ctx, key, maximum)
	if err == nil && found && !bytes.Equal(row.Key, key) {
		err = errCorrupt
	}
	if err == nil {
		err = l.charge(256 + 4*(cap(row.Key)+cap(row.Value)))
	}
	if err != nil {
		return raftlog.KV{}, false, err
	}
	return row, found, nil
}
func (s *graphSourceServer) scan(ctx context.Context, cookie graphSourceCookie, lower, upper, after []byte, budget raftlog.ReadBudget) (page raftlog.ApplicationPage, err error) {
	l, err := s.lease(cookie)
	if err != nil {
		return page, err
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	if budget.Rows < 1 || budget.Bytes < 1 || budget.Rows > min(l.info.limits.Rows, l.limits.rows-l.rows) || budget.Bytes > min(l.info.limits.Bytes, l.limits.frame-512, (l.limits.bytes-l.bytes)/4, (l.limits.output-l.output)/4) {
		return page, errLimit
	}
	if err := l.begin(ctx, 0, 512+4*(len(lower)+len(upper)+len(after))); err != nil {
		return page, err
	}
	page, err = l.read.Scan(ctx, lower, upper, after, budget)
	if page.Visited > l.limits.rows-l.rows {
		err = errors.Join(errLimit, err)
	}
	l.rows += page.Visited
	if err == nil {
		err = l.charge(256 + 4*page.Bytes)
	}
	if err != nil {
		return raftlog.ApplicationPage{}, err
	}
	return page, nil
}
