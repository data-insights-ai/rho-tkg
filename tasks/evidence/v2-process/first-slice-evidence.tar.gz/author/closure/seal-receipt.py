from pathlib import Path
import json,hashlib,re,collections
root=Path('/var/tmp/rho-v5-v2-process-20261011');ev=Path('/var/tmp/rho-v5-v2-process-evidence-20261011');out=ev/'closure';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((out/'source-manifest.json').read_text())
assert all(sha(root/p)==h for p,h in m['files'].items())
def events(p):
 for line in p.read_text().splitlines():
  try:x=json.loads(line)
  except ValueError:continue
  if isinstance(x,dict):yield x
def status(p):
 result={}
 for x in events(p):
  if x.get('Test') and '/' not in x['Test'] and x['Action'] in ('pass','skip','fail'):result[(x['Package'],x['Test'])]=x['Action']
 assert 'fail' not in result.values(),p
 return result
inventory=collections.defaultdict(list)
for x in events(out/'inventory.jsonl'):
 for line in x.get('Output','').splitlines():
  if re.fullmatch(r'(?:Test|Fuzz|Example)\w+',line):inventory[x['Package']].append(line)
listed={(p,n) for p,names in inventory.items() for n in names};assert len(listed)==644
lanes=json.loads((ev/'final/lanes.json').read_text())['lanes'];modes={};jobs=[]
for mode in ['normal','race']:
 combined={}
 for lane in lanes:
  name=lane['lane'];p=ev/'final'/f'{name}-{mode}.jsonl';w=p.with_suffix('.watchdog.json');watch=json.loads(w.read_text());assert watch['exit_code']==0;results=status(p);assert set(results).isdisjoint(combined);combined.update(results);jobs.append({'path':str(p.relative_to(ev)),'watchdog':str(w.relative_to(ev)),'sha256':sha(p),'source_receipt':str(p.with_suffix('.receipt.json').relative_to(ev)),'qualification':'executed full affected production freeze; final production differs only by same-line audited comment; test-only deltas qualified separately'})
 assert len(combined)==635
 for directory in ['coverage-delta','method-delta','lint-test-amendment']:
  p=ev/directory/f'{mode}.jsonl';w=p.with_suffix('.watchdog.json');watch=json.loads(w.read_text());assert watch['exit_code']==0;combined.update(status(p));jobs.append({'path':str(p.relative_to(ev)),'watchdog':str(w.relative_to(ev)),'sha256':sha(p),'qualification':'fresh focused test-only amendment, unchanged production executable tokens'})
 cohort=ev/'final'/f'registered-AS4-{mode}.jsonl';w=cohort.with_suffix('.watchdog.json');watch=json.loads(w.read_text());assert watch['exit_code']==0;cohort_status=status(cohort);assert len(cohort_status)==1 and list(cohort_status.values())==['pass'];combined.update(cohort_status);jobs.append({'path':str(cohort.relative_to(ev)),'watchdog':str(w.relative_to(ev)),'sha256':sha(cohort),'qualification':'fresh required AS4 cohort; replaces general-lane skip'})
 assert set(combined)==listed,(mode,len(combined),listed-set(combined),set(combined)-listed)
 passed=[f'{p}:{n}' for (p,n),s in combined.items() if s=='pass'];skips=[f'{p}:{n}' for (p,n),s in combined.items() if s=='skip'];assert len(passed)==640 and len(skips)==4,(mode,len(passed),skips)
 modes[mode]={'listed':644,'passed':640,'skipped':skips,'missing':[],'extra':[],'failed':[]}
(out/'inventory.json').write_text(json.dumps({'packages':inventory,'modes':modes},indent=2)+'\n')
scanner_jobs=[]
for name in ['static','lint-final','security','vuln','inventory']:
 w=out/f'{name}.watchdog.json';watch=json.loads(w.read_text());assert watch['exit_code']==0
 log=out/('inventory.jsonl' if name=='inventory' else f'{name}.log');scanner_jobs.append({'name':name,'log':str(log.relative_to(ev)),'sha256':sha(log),'watchdog':str(w.relative_to(ev)),'watchdog_sha256':sha(w),'command':watch['command'],'exit_code':0})
methods=json.loads((out/'direct-public-methods.json').read_text())
for name,f in methods.items():
 assert f['percent']>=80
 witness=f['direct_witness'];assert witness['expression'] in (root/witness['file']).read_text().splitlines()[witness['line']-1],(name,witness)
cov=json.loads((out/'coverage-summary.json').read_text());cov['percent']=100*cov['covered']/cov['statements'];(out/'coverage-summary.json').write_text(json.dumps(cov,indent=2)+'\n')
receipt={'scope':'finite same-GraphID two-partition six-process cross-edge orchestration; package4 remains open','source_manifest':'source-manifest.json','source_manifest_sha256':sha(out/'source-manifest.json'),'source_go_sha256':m['go_source_sha256'],'base':m['base'],'production_executable_delta_since_exhaustive_freeze':[],'production_comment_byte_delta':m['production_comparison'],'test_delta':m['test_only_delta_from_exhaustive'],'inventory':'inventory.json','inventory_sha256':sha(out/'inventory.json'),'test_results':modes,'tests':jobs,'static_scanners':scanner_jobs,'coverage':{'covered':cov['covered'],'statements':cov['statements'],'percent':cov['percent'],'profile':'coverage.out','profile_sha256':sha(out/'coverage.out'),'file_map':'coverage-summary.json','lower_package_carry':'../final/coverage-summary.json; exact lower-source hashes/equal block counts only; no graphapply/graphstore lower carry','all24_changed_executable_files_at_least80':True,'graph_source_go':'types/interfaces/constants only, no executable statements'},'direct_methods':{'count':len(methods),'all_at_least80':True,'map':'direct-public-methods.json','map_sha256':sha(out/'direct-public-methods.json')},'mutants':[{'name':name,'receipt':f'../mutants/{name}/receipt.json','sha256':sha(ev/'mutants'/name/'receipt.json'),'result':'KILLED at intended wrong-answer assertion'} for name in ['reply-binding','current-root']],'qualifications':['nil-comment-only-carry.json','nosec-comment-only-carry.json','observer Incident physical-work allowance changed Rows16/64KiB to Rows100/1MiB; returned tuple16 and global source/output/IPC/runtime caps unchanged','graph facts are six caller paths over configured leader sources; six-voter native local resolve/root/outcome/CDC/pin parity independently asserted','OpenQuiescentSources is authority-qualified per-source current view, not certified graph cut or E15-E18 closure','first RED is legitimate missing remote orchestration, not a local API bug; original immutable archive root tasks/evidence/v2-process/first-slice-red.json','prior failed lint/fixture/timeout logs retained in failed-first-freeze,pre-native-guard-freeze,method-delta/lint.log,closure/lint-hidden-nil.log,closure/security-admitted-lifetime.log,lint-test-amendment/unused-import-build-failure.jsonl','vuln0reachable; tool reports2package/2module advisory findings without reachable calls; these are not asserted as4distinct CVEs'],'deferred':['remote certified cuts/E15-E18 full oracle','ownership transfer/E17','GC retention/physical-host fault matrix','substrate comparison/FDB','public consumer API'],'review':'/var/tmp/rho-v5-v2-process-review-20261011; same reviewer final acceptance pending receipt','commit':None}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'artifacts.sha256.json').write_text(json.dumps({str(p.relative_to(ev)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifacts.sha256.json'},indent=2)+'\n')
print('sealed receipt',sha(out/'receipt.json'),'inventory644/pass640 in both modes','coverage',cov['percent'],'methods',len(methods))
