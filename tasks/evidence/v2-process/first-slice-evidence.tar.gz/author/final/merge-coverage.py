import pathlib,json,hashlib,collections
out=pathlib.Path(__file__).parent;root=pathlib.Path('/var/tmp/rho-v5-v2-process-20261011');module='github.com/data-insights-ai/rho-tkg/v5/';cur=json.loads((out/'source-manifest.json').read_text())['files'];prev=json.loads(pathlib.Path('/var/tmp/rho-v5-v2-certified-final-20261011/source.json').read_text())['files'];preclaim=json.loads(pathlib.Path('/var/tmp/rho-v5-v2-preclaim-evidence-20261011/source.json').read_text());profiles=[(str(p),cur,False) for p in sorted(out.glob('*.cover'))];profiles+=[('/var/tmp/rho-v5-v2-certified-final-20261011/coverage.out',prev,True),('/var/tmp/rho-v5-v2-preclaim-evidence-20261011/coverage.out',preclaim,True)];blocks={};counts={};accepted=[];excluded=collections.Counter()
for filename,source,carry in profiles:
 kept=0
 for line in pathlib.Path(filename).read_text().splitlines()[1:]:
  position,statements,count=line.split();file=position.split(':')[0];relative='v5/'+file.removeprefix(module)
  if carry and relative.startswith(('v5/internal/graphapply/','v5/internal/graphstore/')):excluded['changed-dependency-package']+=1;continue
  if source.get(relative)!=cur.get(relative) or relative not in cur:excluded['different-source']+=1;continue
  key=(position,int(statements));assert position not in counts or counts[position]==key[1],(filename,key,counts.get(position))
  counts[position]=key[1]
  blocks[key]=max(blocks.get(key,0),int(count));kept+=1
 accepted.append({'path':filename,'sha256':hashlib.sha256(pathlib.Path(filename).read_bytes()).hexdigest(),'carried':carry,'accepted_blocks':kept})
(out/'coverage.out').write_text('mode: set\n'+''.join(f'{p} {s} {int(n>0)}\n' for (p,s),n in sorted(blocks.items())))
files=collections.defaultdict(lambda:[0,0])
for (p,s),n in blocks.items():file=p.split(':')[0];files[file][0]+=s if n else 0;files[file][1]+=s
summary={'covered':sum(v[0] for v in files.values()),'statements':sum(v[1] for v in files.values()),'files':{k:{'covered':v[0],'statements':v[1],'percent':100*v[0]/v[1] if v[1] else None} for k,v in files.items()},'profiles':accepted,'excluded':dict(excluded)};(out/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary['covered'],summary['statements'],100*summary['covered']/summary['statements'])
for p in json.loads((out/'source-manifest.json').read_text())['changed_go']:
 if p.endswith('_test.go'):continue
 value=summary['files'].get(module+p.removeprefix('v5/'))
 print(p,value)
