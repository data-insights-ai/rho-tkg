import pathlib,json,subprocess,os,hashlib,sys
r=pathlib.Path('/var/tmp/rho-v5-v2-process-20261011');e=pathlib.Path(__file__).parent;manifest=json.loads((e/'source-manifest.json').read_text());lanes=json.loads((e/'lanes.json').read_text())['lanes']
order=['graphapply-process-source','graphapply-certified','graphapply-cross','graphapply-registry','graphapply-replicated','graphapply-rest','graphstore-partition','graphstore-current','graphstore-rest'];lanes.sort(key=lambda l:order.index(l['lane']))
env=dict(os.environ,GOTOOLCHAIN='go1.26.9',GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off')
def check():
 changed=[p for p,h in manifest['files'].items() if hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]
 if changed:raise RuntimeError('source changed: '+repr(changed))
mode=sys.argv[1];selected=set(sys.argv[2:])
for lane in lanes:
 if selected and lane['lane'] not in selected:continue
 receipt=e/(lane['lane']+'-'+mode+'.receipt.json')
 if receipt.exists() and json.loads(receipt.read_text()).get('exit_code')==0:continue
 check();cmd=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096','--seconds','180','--report',str(e/(lane['lane']+'-'+mode+'.watchdog.json')),'--','go','test','-count=1','-json']
 if mode=='normal':cmd+=['-coverpkg=./...','-coverprofile='+str(e/(lane['lane']+'.cover'))]
 elif mode=='race':cmd+=['-race']
 else:raise RuntimeError('unknown mode')
 cmd+=['-run',lane['regex'],lane['package']]
 print('START',lane['lane'],mode,flush=True)
 with (e/(lane['lane']+'-'+mode+'.jsonl')).open('w') as output:result=subprocess.run(cmd,cwd=r/'v5',env=env,stdout=output,stderr=subprocess.STDOUT)
 check();receipt.write_text(json.dumps({'source':manifest['go_source_sha256'],'lane':lane['lane'],'mode':mode,'names':lane['names'],'exit_code':result.returncode,'command':cmd},indent=2)+'\n');print('DONE',lane['lane'],mode,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
