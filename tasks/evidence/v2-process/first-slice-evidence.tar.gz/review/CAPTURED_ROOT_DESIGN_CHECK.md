# Captured root metadata optimization — narrow design check

No specific safety blocker found. Same reviewer, read-only check, 2026-10-11. This permits the approved implementation optimization; it is not final feature/P4 acceptance.

remoteGraphSource.RootBounded now returns an exact owned copy of the authenticated sourceInfo root captured at open. decodeGraphSourceInfo already owns the root backing and checks the exact immutable root/hash; endpoint open binds the completed response to expected peer, issuer, nonce and source scope. The getter checks caller context, local closed state, owner cancellation and finite TTL, then native image-ceiling semantics and shared output/source accounting before copying. Negative maxima use ErrInvalid, maxima below actual image length use ErrLimit without output charge, larger maxima do not allocate by requested size. All root coordinates/hash/image remain the captured values; no current-root substitution or caller-selected root is introduced.

Metadata availability does not establish remote peer availability, retained data availability, fresh quorum evidence, readiness or a certified cut. Required Get/Scan remain actual identity/issuer/cookie-bound source RPC and must return typed zero-output failure on disconnect/expiry rather than graph absence or successful completion. No control/empty/recovery authority is added and no global cap is increased.

The added direct guard covers metadata size/alias/cancellation/owner-cancel behavior and separately exercises the retained sourceRoot wire service. Final normal/race/coverage/gates still need review, including disconnected required-data refusal and complete six-voter oracle/resolve/CDC/owner cleanup under unchanged caps. Reviewer performed no runtime or source mutation.
