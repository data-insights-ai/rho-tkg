# P4 first process slice — test-only independent review

**Verdict: ready for the next production orchestration seam.** No blocking fixture/test-assumption defect or concrete nonblocking defect found in this finite RED-first slice. **Package 4 is not accepted**, and the intentionally failing cross-edge test is not independently mergeable as a green feature checkpoint. Correct local remote-participant refusal is not a safety regression.

Same Sol6.1 independent reviewer, 2026-10-11. Tree `/var/tmp/rho-v5-v2-process-20261011`, base `0f430e44fba4ec1550272b14adaebb696a6d5090`. Read the full three-file diff and complete process/transport/oracle APIs and relevant existing fixtures, plus PLAN §5.3/package4 requirements. Only `replicated_{process,graph,oracle}_test.go` change (685 additions / 1 deletion); no production or documentation delta. All three hashes match `red-source.json` (SHA256 `21cb9a4e5aac29fc84103bbef8bc5c9e1f7dd2a09d40c54e6f629104314a0cb7`); current full diff exactly equals retained `red-source.patch` (SHA256 `acad632904324358e3fde1fdb9b8ce80b1c772343c3e047ece5edc60f13d6452`). `git diff --check` passes.

## Source assessment

- `replicated_process_test.go:1449,1608` and `replicated_graph_test.go:42`: one GraphID `{1}`, declared partitions3/8, two distinct declared group identities, real voter sets1/2/3 and4/5/6. Six OS children each open a separate disk directory, genuine bound Store, certified materializer and actual Host/Driver. Parent campaigns and drains real Raft packets; graph operations are committed through Host Submit. Bootstrap/factory prerequisites are established rather than forged as graph outcomes.
- `replicated_process_test.go:1459,1477,1501`: completed proof stays in the issuing child/actual Host. Each read has child-incarnation/sequence nonce, exact ReadID/question/Host owner validation. Only source-produced proposal scope/wire crosses IPC; parent validates graph/partition/agreement and submits to the destination child. No serialized proof, Store owner, fabricated quorum completion, direct Install/Persist graph mutation or synthetic cross-commit success is used.
- `replicated_oracle_test.go:95–118`: expected existence, active life, endpoints, labels and incident sets are literal map semantics over fixed client inputs. No production planner/reducer/candidate/projection/codec derives expectations. Observation decoding shares bounded IPC primitives but not semantic expectation generation. Missing relationship, outgoing posting, incoming posting and phantom guards demonstrate exact comparisons. Comparison covers all three voters per group, two local nodes and fixed absent controls; incidence arrays are exact, not cardinality-only.
- `replicated_graph_test.go:133,215`: outcomes bind actual applied index and submitted wire hash; all target voters compare checkpoint/outcome/ordered CDC bytes and zero residual views/pins. RED checks unchanged graph image on all six, empty refusal CDC, unchanged remote group stats/applied index, exact absent-edge/posting facts, then actual healthy local writes on both groups before its final intended failure.
- IPC uses finite2MiB frames,128-packet/8MiB queues,4,096 delivery bounds,16-element fact collections and10-second RPC deadlines. New schedules are finite/fixed. `replicated_graph_test.go:56` cleanup runs explicitly even after the intentional test failure, uses the existing bounded shutdown/kill/reap helper, reports cleanup errors independently, verifies successful Wait, ProcessDone and closed stdin/stdout for all six. Normal and race RED cleanup succeeded, not merely a failure-suppressed fallback.

## Reviewed terminal evidence

All commands retain 4GiB /180-second watchdogs. No reviewer runtime was used.

| Run | Exit | Watchdog seconds | Peak tree MiB | Terminal evidence |
|---|---:|---:|---:|---|
| Positive local controls + independent oracle, normal | 0 | 4.920 | 552.531 | Both tests PASS; six reaped;558 calls/276 packets |
| Same positives, race | 0 | 18.502 | 596.766 | PASS; same cleanup; no race diagnostic |
| Cross-edge original RED, normal | 1 | 2.215 | 428.531 | durable reason9;603 calls/284 packets; six reaped |
| Same original RED, race | 1 | 9.067 | 472.938 | same intended reason9 failure; no race diagnostic; six reaped |

Both REDs first prove node1/life2 on partition3 and node17/life18 on partition8 succeeded (kind7/reason0), then the submitted local cross-edge yields kind8/reason9 `reasonRemoteParticipant` with empty changes. Both post-refusal AddLabel writes succeed (kind9/reason0), exact oracle controls remain healthy, and failure occurs only at the broader cross-edge acceptance assertion (`replicated_graph_test.go:246`). No unavailable transport, fake proof, child crash, race warning or cleanup error is being interpreted as the business RED. The durable original refusal/outcome is legitimate missing higher-level feature evidence.

## Scope and next seam boundary

`certifiedProcessObservation` at `replicated_process_test.go:1552` reads each local quiescent current applied view. It does **not** collect or validate a distributed cut and is not a serial-history/cut oracle. Byte equality across voters is replica parity, not an independent CDC semantics oracle. The current GREEN controls plus original RED are sufficient to begin the finite production seam; they do not prove E15/E16/E17/E18, concurrency/serializability, transfer, process/message-fault recovery, retained cross-cut stability or engine comparison.

The future cross-edge GREEN must use actual remote prepare/decision/resolve orchestration and authority-qualified observations; local refusal must remain correct. These tests must not become green by bypassing participant authority, injecting outcomes/proofs, replacing expected graph facts with production output, or calling direct storage installs. Process observations cannot be promoted to certified cut evidence without the real retained certificate/scope/applied-barrier protocol. The same reviewer will inspect that production feature and its gates. No new production plan, source edit, commit or push was made here.
