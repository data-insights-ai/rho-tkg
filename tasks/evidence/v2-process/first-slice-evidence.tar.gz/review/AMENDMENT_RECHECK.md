# P4 finite orchestration slice — amendment source recheck

Same independent reviewer, 2026-10-11. Read-only source/evidence inspection; no reviewer runtime or repository changes.

Current manifest SHA256 `16f918782b0e3c59554b34b109521cf47c09b1dee54238a46e5af18d66ce8d47`; all430 live Go hashes independently match. The only changes from the preserved pre-native-guard freeze are `v5/internal/graphstore/catalog.go` and `v5/internal/graphapply/graph_source_transport_test.go`.

Native compatibility restoration is correct: `Catalog.check` checks caller context outside the native view lock, preserves the previous concrete `ApplicationView.Root()` guard, and uses context-bound `RootBounded` only for a data-only remote source. This avoids invoking a side-effecting custom `Context.Err` under `ApplicationView.mu`, the concrete cause of the preserved graphstore-rest timeout. The existing close-at callback fixture is unchanged. Remote cancellation, retained-root ownership and known metadata ceiling remain enforced.

The new genuine-source test directly exercises remote `Root`, `ApplicationBinding` and `ReadLimits`, with exact captured identity, owned image, nil receiver, cancellation, exhausted shared output ledger and closed source assertions. It directly asserts `graphWireError.Error`. Focused normal and race JSON independently show all three named guards pass (native association close, remote blocked-query cancellation and new direct metadata methods), no skips/failures; watchdogs exit0 at13.674/17.458 seconds and669.688/618.297MiB under unchanged180-second/4096MiB caps.

The preceding process-fixture amendment is also correct: only after the correlated, successful terminal Close reply does the parent drain bounded trailing test output through EOF. Overflow and unexpected errors still fail. Ordinary IPC framing, actual successful child Wait and all-six reap assertions remain. The failed coverage-instrumented cleanup freeze is retained separately and cannot count as acceptance evidence.

No concrete source blocker remains in the finite reviewed slice. FINAL ACCEPTANCE IS PENDING amended exact-source applicable gates, exhaustive inventories and receiver-specific new/direct method coverage. This source recheck does not accept wholeP4, certified remote cuts, serialE15–18, follower-source/failover, physical-host or engine-comparison claims. Six caller graph projections use configured leader sources1/4; all six native voters independently assert resolve/root/outcome/CDC/pin state.
