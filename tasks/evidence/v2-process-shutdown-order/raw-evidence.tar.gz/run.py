import hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path('/var/tmp/rho-v5-p08-reap-investigation-20261012'); e=Path('/var/tmp/rho-v5-p08-reap-evidence-20261012'); freeze=json.loads((e/'freeze.json').read_text()); m=json.loads((e/'fixed-source-hashes.json').read_text()); stage=sys.argv[1]
assert stage in ('mutant-guard','fixed-guard','fixed-guard-race','union','union-race','vet')
if stage=='mutant-guard': m['v5/internal/graphapply/replicated_process_test.go']=json.loads((e/'mutant-provenance.json').read_text())['mutant_helper_sha256']
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in m.items())
go='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go'
selection=freeze['union_regex'] if stage.startswith('union') else '^'+freeze['guard']+'$'
command=[go,'test','-count=1','-json','-timeout=150s','-run',selection,'./internal/graphapply']
if stage.endswith('race'): command.insert(2,'-race')
if stage=='vet': command=[go,'vet','./internal/graphapply']
env=dict(os.environ,GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local')
receipt={'command':command,'cwd':str(r/'v5'),'env':{k:env[k] for k in ('GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GOWORK','GOTOOLCHAIN')},'freeze_sha256':hashlib.sha256((e/'freeze.json').read_bytes()).hexdigest(),'source_hashes':m,'stage':stage,'scope':'test harness shutdown ordering only; original P08/E17 semantics unchanged'}
(e/(stage+'-command.json')).write_text(json.dumps(receipt,indent=2)+'\n')
limited=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096MiB','--seconds','180','--report',str(e/(stage+'-limit.json')),*command]
with (e/(stage+('.jsonl' if stage!='vet' else '.stdout.log'))).open('w') as out,(e/(stage+'.stderr.log')).open('w') as err:
 result=subprocess.run(limited,cwd=r/'v5',env=env,stdout=out,stderr=err,check=False)
limit=json.loads((e/(stage+'-limit.json')).read_text()); print(json.dumps({'stage':stage,'exit_code':result.returncode,'elapsed_s':limit['elapsed_s'],'peak_tree_rss_mib':limit['peak_tree_rss_mib']})); sys.exit(result.returncode)
