import os,sys,json,subprocess,hashlib,shutil
from pathlib import Path
repo=Path("/var/tmp/rho-v5-v2-partition-writes-integrated-20261011");out=Path(__file__).parent
go="/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin"
env=os.environ.copy();env.update(PATH=go+":/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin",GOWORK="off",GOTOOLCHAIN="local",GOPROXY="off",GOSUMDB="off",GOCACHE="/var/tmp/rho-v5-go-build-cache-go1.26.9",GOFLAGS="-p=1",GOMAXPROCS="2",GOMEMLIMIT="2GiB")
source=json.loads((out/"source-before.json").read_text())
def verify():
 for f in source["files"]:
  if hashlib.sha256((repo/f["path"]).read_bytes()).hexdigest()!=f["sha256"]:raise RuntimeError("source changed: "+f["path"])
verify()
docker="/usr/local/bin/docker run --rm --memory=4g --cpus=2 -e GOTOOLCHAIN=local -e GOWORK=off -e GOMAXPROCS=2 -e GOFLAGS=-p=1 -v "+str(repo)+":/src -w /src/v5 -v rho-tkg-gocache:/go -v rho-tkg-buildcache:/root/.cache/go-build golang:1.26.9"
image=subprocess.check_output(["/usr/local/bin/docker","image","inspect","golang:1.26.9","--format","{{json .}}"],env=env,text=True);(out/"docker-image.json").write_text(image)

commands=[("history-normal",["go","test","-count=1","-timeout=150s","-v","./internal/raftlog","-run","^TestApplicationViewHistory"],4096,180),("history-race",["go","test","-race","-count=1","-timeout=150s","-v","./internal/raftlog","-run","^TestApplicationViewHistory"],4096,180)]
for target in ["fmt-check","vet","build","cover","lint-docker","security-docker","vulncheck-docker"]:
 make=["/usr/bin/make","-C",str(repo/"v5")]
 if target.endswith("-docker"):make.append("DOCKER_GO="+docker)
 commands.append((target,make+[target],8192,1000))
for target,operation,rss,seconds in commands:
 verify()
 if shutil.disk_usage(repo).free<2*2**30:raise RuntimeError("disk launch guard")
 cmd=["/usr/bin/python3","/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py","--rss-mib",str(rss),"--seconds",str(seconds),"--report",str(out/(target+"-budget.json")),"--"]+operation
 print("START "+target,flush=True)
 with (out/(target+".log")).open("wb") as log:r=subprocess.run(cmd,cwd=repo/"v5",env=env,stdout=log,stderr=subprocess.STDOUT)
 verify();print("END "+target+" exit="+str(r.returncode),flush=True)
 (out/"final-status.json").write_text(json.dumps({"last":target,"exit_code":r.returncode,"source_verified":True},indent=2)+"\n")
 if r.returncode:sys.exit(r.returncode)
 if target=="cover":
  shutil.copy2(repo/"v5/coverage.out",out/"coverage.out")
  shutil.copy2(repo/"v5/coverage.html",out/"coverage.html")
  (out/"coverage-functions.txt").write_text(subprocess.check_output(["go","tool","cover","-func="+str(out/"coverage.out")],cwd=repo/"v5",env=env,text=True))
 tool={"lint-docker":"golangci-lint","security-docker":"gosec","vulncheck-docker":"govulncheck"}.get(target)
 if tool:
  capture=docker.split()+["sh","-c","go version; go version -m /go/bin/"+tool+"; cat /sys/fs/cgroup/memory.max; cat /sys/fs/cgroup/cpu.max"]
  with (out/(tool+"-provenance.log")).open("wb") as log:r=subprocess.run(capture,env=env,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:raise RuntimeError("tool provenance failed")
print("CORRECTION GATES PASS",flush=True)
