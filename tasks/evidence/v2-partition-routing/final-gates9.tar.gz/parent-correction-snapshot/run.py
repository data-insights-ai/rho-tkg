import json, hashlib, os, subprocess
from pathlib import Path
repo=Path("/var/tmp/rho-v5-v2-partition-writes-integrated-20261011")
out=Path(__file__).parent
manifest=Path("/var/tmp/rho-v5-v2-partition-final-combined-gates9-20261011/source-before.json")
expected=json.loads(manifest.read_text())
def verify():
    for f in expected["files"]:
        assert hashlib.sha256((repo/f["path"]).read_bytes()).hexdigest()==f["sha256"], f["path"]
    actual={str(p.relative_to(repo)) for p in (repo/"v5").rglob("*.go")}
    wanted={f["path"] for f in expected["files"] if f["path"].startswith("v5/") and f["path"].endswith(".go")}
    assert actual==wanted, sorted(actual^wanted)
verify()
(out/"source-before.json").write_bytes(manifest.read_bytes())
env=os.environ.copy()
env.update(PATH="/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin:/usr/bin:/bin:/usr/sbin:/sbin",GOWORK="off",GOTOOLCHAIN="local",GOPROXY="off",GOSUMDB="off",GOCACHE="/var/tmp/rho-v5-go-build-cache-go1.26.9",GOFLAGS="-p=1",GOMAXPROCS="2",GOMEMLIMIT="2GiB")
cmd=["/usr/bin/python3","/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py","--rss-mib","4096","--seconds","180","--report",str(out/"budget.json"),"--","go","test","-race","-count=1","-timeout=150s","-v","./internal/graphstore","./internal/graphapply","-run","^(TestFinalReview|TestTrustedWriterWideSummaryAndRetainedRoot|TestPartitionNonemptyGraphSnapshotRetainedHistoryFailoverAndReopen)"]
with (out/"tests.log").open("wb") as log:
    result=subprocess.run(cmd,cwd=repo/"v5",env=env,stdout=log,stderr=subprocess.STDOUT)
verify()
text=(out/"tests.log").read_text()
passes=[line for line in text.splitlines() if line.startswith("--- PASS:")]
receipt={"exit_code":result.returncode,"source_verified_before_after":True,"manifest_sha256":hashlib.sha256(manifest.read_bytes()).hexdigest(),"log_sha256":hashlib.sha256((out/"tests.log").read_bytes()).hexdigest(),"top_level_passes":passes,"command":cmd,"qualification":"Independent parent execution of the correction regressions and preserved wide scalar writer control; complements prior full package review and author gates. Does not close overall V2."}
(out/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2))
raise SystemExit(result.returncode)
