import re,json,subprocess,collections,hashlib
from pathlib import Path
repo=Path("/var/tmp/rho-v5-v2-partition-writes-integrated-20261011");out=Path(__file__).parent
blocks={}
for line in (out/"coverage.out").read_text().splitlines()[1:]:
 where,n,hit=line.split();n=int(n);hit=int(hit)
 if where in blocks:assert blocks[where][0]==n
 blocks[where]=(n,max(hit,blocks.get(where,(n,0))[1]))
comparison="93d04f3ad27084c8f5378130e7d526ffb239463d"
owned=sorted(p for p in subprocess.check_output(["git","diff","--name-only",comparison,"HEAD","--","v5"],cwd=repo,text=True).splitlines() if p.endswith(".go") and not p.endswith("_test.go"))
new=set(subprocess.check_output(["git","diff","--diff-filter=A","--name-only",comparison,"HEAD","--","v5"],cwd=repo,text=True).splitlines())
changed={}
for name in owned:
 if name in new:changed[name]=set(range(1,len((repo/name).read_text().splitlines())+1));continue
 diff=subprocess.check_output(["git","diff","--unified=0",comparison,"HEAD","--",name],cwd=repo,text=True);lines=set();pos=0
 for line in diff.splitlines():
  if line.startswith("@@"):pos=int(re.search(r"\+(\d+)",line)[1])
  elif line.startswith("+") and not line.startswith("+++"):lines.add(pos);pos+=1
  elif line.startswith("-") and not line.startswith("---"):pass
  elif line and not line.startswith(("diff ","index ","---","+++")):pos+=1
 changed[name]=lines
files=collections.defaultdict(lambda:[0,0]);proxies=collections.defaultdict(lambda:[0,0]);total=[0,0]
for where,(n,hit) in blocks.items():
 path,span=where.rsplit(":",1);name=path.replace("github.com/data-insights-ai/rho-tkg/v5/","v5/");c=n if hit else 0;files[name][0]+=c;files[name][1]+=n;total[0]+=c;total[1]+=n
 if name in changed:
  a,b=span.split(",");first,last=int(a.split(".")[0]),int(b.split(".")[0])
  if any(i in changed[name] for i in range(first,last+1)):proxies[name][0]+=c;proxies[name][1]+=n
rows=[]
for name in owned:
 c,n=files[name];pc,pn=proxies[name];rows.append({"path":name,"new_file":name in new,"covered":c,"statements":n,"percent":100*c/n if n else None,"changed_block_covered":pc,"changed_block_statements":pn,"changed_block_percent":100*pc/pn if pn else None})
functions=[]
for line in (out/"coverage-functions.txt").read_text().splitlines():
 parts=line.split()
 if len(parts)!=3 or parts[0]=="total:":continue
 location,name,percent=parts;path,number=location.rstrip(":").rsplit(":",1);path=path.replace("github.com/data-insights-ai/rho-tkg/v5/","v5/")
 if path in owned and name[0].isupper():functions.append({"path":path,"line":int(number),"method":name,"percent":float(percent.rstrip("%"))})
summary={"comparison_base":comparison,"base":subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip(),"coverage_sha256":hashlib.sha256((out/"coverage.out").read_bytes()).hexdigest(),"module":{"covered":total[0],"statements":total[1],"percent":100*total[0]/total[1]},"files":rows,"exported_functions":functions,"qualification":"Duplicate coverpkg blocks coalesced before statement totals. Changed-block proxy includes entire executable blocks intersecting added/replaced source lines and may include preexisting statements; no heap/RSS claim."}
(out/"coverage-summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print("module",summary["module"])
for row in rows:
 if row["new_file"] and row["percent"] is not None and row["percent"]<80:print("NEW FILE BLOCKER",row)
 if not row["new_file"] and row["changed_block_percent"] is not None and row["changed_block_percent"]<80:print("CHANGED PROXY",row["path"],row["changed_block_percent"])
for f in functions:
 if f["percent"]==0:print("EXPORTED ZERO BLOCKER",f)
