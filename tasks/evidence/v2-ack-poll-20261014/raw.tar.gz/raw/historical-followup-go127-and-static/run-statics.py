import subprocess
from pathlib import Path
root=Path('/var/tmp/rho-v2-ack-poll-evidence-20261014')
name='rho-v2-ack-poll-static-20261014'
command=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--seconds','180','--rss-mib','4096','--report',str(root/'static.watchdog.json'),'--','docker','run','--rm','--name',name,'--cpus=2','--memory=4g','--memory-swap=4g','-e','GOMAXPROCS=2','-e','GOMEMLIMIT=2GiB','-e','GOFLAGS=-p=1','-e','GOWORK=off','-e','GOTOOLCHAIN=local','-v','/var/tmp/rho-v2-ack-attribution-20261014:/src','-w','/src/v5','-v','rho-tkg-gocache:/go','-v','rho-tkg-buildcache:/root/.cache/go-build','golang:1.26.9','sh','-c','go version && go install github.com/golangci/golangci-lint/v2/cmd/golangci-lint@v2.13.2 && go install github.com/securego/gosec/v2/cmd/gosec@v2.29.0 && golangci-lint --version && gosec -version && go vet ./internal/graphapply && go build ./internal/graphapply && go test -run "^$" ./internal/graphapply && golangci-lint run --config ../.golangci.yml ./internal/graphapply && gosec -quiet ./internal/graphapply']
(root/'static.command.json').write_text(__import__('json').dumps(command,indent=2)+'\n')
try:
    with (root/'static.stdout.txt').open('wb') as out,(root/'static.stderr.txt').open('wb') as err:
        code=subprocess.call(command,stdout=out,stderr=err)
finally:
    result=subprocess.run(['docker','rm','-f',name],capture_output=True,text=True)
    (root/'static.cleanup.txt').write_text(result.stdout+result.stderr)
raise SystemExit(code)
