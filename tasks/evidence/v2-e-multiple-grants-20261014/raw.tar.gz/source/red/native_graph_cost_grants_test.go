package graphapply

import (
	"testing"

	"github.com/data-insights-ai/rho-tkg/v5/internal/idalloc"
	"github.com/data-insights-ai/rho-tkg/v5/internal/raftlog"
)

// Before the setup fix this refuses at homeCount > MaxBlockSize. Passing this
// guard permits setup only; it proves no million-fact runtime or RSS bound.
func TestNativeGraphCostMillionFactProfileUsesBoundedGrantBlocks(t *testing.T) {
	s := nativeGraphCostSpec{Version: 1, Facts: 1_000_000, Writers: 1}
	var init declaredInitCommand
	l := raftlog.DefaultLimits()
	p := raftlog.DefaultApplicationPolicy(1)
	g := raftlog.ApplicationGenerationLimits{}
	if err := nativeGraphCostProfile(&s, &init, &l, &p, &g); err != nil {
		t.Fatal("multiple grants must fund the declared ID interval", err)
	}
	if init.maxBlock != idalloc.MaxBlockSize || l.MaxRetainedEntries != 1_000_000 || p.RetainedApplicationRecords != 65536+s.Facts*512 {
		t.Fatal("block reservation changed unrelated retained quotas", init.maxBlock, l, p)
	}
}
