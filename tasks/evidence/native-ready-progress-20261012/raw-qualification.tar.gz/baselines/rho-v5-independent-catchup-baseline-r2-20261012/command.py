import subprocess,sys,hashlib,json
from pathlib import Path
go=Path("/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go")
f=Path("internal/replica/ready_capacity_regression_test.go")
subprocess.run([str(go.parent/"gofmt"),"-w",str(f)],check=True)
Path("/var/tmp/rho-v5-independent-catchup-baseline-r2-20261012/test-source-sha256.txt").write_text(hashlib.sha256(f.read_bytes()).hexdigest()+"\n")
cmd=[str(go),"test","-short","-count=1","-v","-run","^TestIndependentCapacity","./internal/replica"]
print("ACTUAL BASELINE COMMAND "+json.dumps(cmd),flush=True)
sys.exit(subprocess.run(cmd).returncode)
