import os,sys,json,subprocess,hashlib,shutil
from pathlib import Path
repo=Path("/var/tmp/rho-v5-v2-partition-writes-integrated-20261011");out=Path(__file__).parent
go="/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin"
env=os.environ.copy();env.update(PATH=go+":/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin",GOWORK="off",GOTOOLCHAIN="local",GOPROXY="off",GOSUMDB="off",GOCACHE="/var/tmp/rho-v5-go-build-cache-go1.26.9",GOFLAGS="-p=1",GOMAXPROCS="2",GOMEMLIMIT="2GiB")


import difflib
stage="v5/internal/graphstore/full_stage.go"
routing="v5/internal/graphstore/partition_routing.go"
reserve="\t\t\t\tif v.arena != nil {\n\t\t\t\t\tif err := v.arena.Reserve(backing); err != nil {\n\t\t\t\t\t\treturn nil, callerError(err)\n\t\t\t\t\t}\n\t\t\t\t}\n"
original=(repo/stage).read_text()
assert original.count(reserve)==2
mutants=[("scope-clone",stage,original.replace(reserve,"",1),"^TestFinalReviewScopeScalarCloneRequiresFreshBackingAdmission$"),("descriptor-clone",stage,original[:original.index("if op.Value.Kind() == graphstate.ScalarDescriptor")] + original[original.index("if op.Value.Kind() == graphstate.ScalarDescriptor"):].replace(reserve,"",1),"^TestFinalReviewDescriptorScalarCloneRequiresFreshBackingAdmission$"),("epoch-floor",routing,(repo/routing).read_text().replace("o.Epoch < p.InitialEpoch","o.Epoch == 0",1),"^TestFinalReviewRegressedRangeEpochCannotAuthorizeLocalWrites$")]
results=[]
for name,path,mutant,test in mutants:
 original=(repo/path).read_text()
 mutated=out/(name+"-real-mutant.go");mutated.write_text(mutant)
 (out/(name+"-real-mutant.patch")).write_text("".join(difflib.unified_diff(original.splitlines(True),mutant.splitlines(True),fromfile=path,tofile=path)))
 overlay=out/(name+"-real-overlay.json");overlay.write_text(json.dumps({"Replace":{str(repo/path):str(mutated)}},indent=2)+"\n")
 cmd=["/usr/bin/python3","/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py","--rss-mib","4096","--seconds","180","--report",str(out/(name+"-real-mutant-budget.json")),"--","go","test","-count=1","-timeout=150s","-v","./internal/graphstore","-run",test]
 try:
  (repo/path).write_text(mutant)
  with (out/(name+"-real-mutant.log")).open("wb") as log:r=subprocess.run(cmd,cwd=repo/"v5",env=env,stdout=log,stderr=subprocess.STDOUT)
 finally:
  (repo/path).write_text(original)
 log=(out/(name+"-real-mutant.log")).read_text()
 assert r.returncode==1 and "--- FAIL: TestFinalReview" in log and "[build failed]" not in log,(name,r.returncode,log)
 assert (repo/path).read_text()==original
 results.append({"mutant":name,"path":path,"command":cmd,"exit":r.returncode,"working_source_unchanged":True})
 print(name+" caught",flush=True)
(out/"real-mutant-results.json").write_text(json.dumps(results,indent=2)+"\n")
for f in out.iterdir():
 if "mutant" in f.name or "overlay" in f.name:shutil.copy2(f,repo/"tasks/evidence/v2-partition-routing/final-review-corrections"/f.name)
