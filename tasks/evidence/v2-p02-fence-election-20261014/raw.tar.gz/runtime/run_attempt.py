import os,json,hashlib,pathlib,subprocess,sys
root=pathlib.Path('/var/tmp/rho-v5-p02-fence-election-20261014'); out=pathlib.Path('/var/tmp/rho-v5-p02-runtime-20261014'); attempt=int(sys.argv[1])
files=sorted(root.glob('v5/**/*.go'))+[root/'v5/go.mod',root/'v5/go.sum']
freeze={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/f'attempt{attempt}-frozen-source.json').write_text(json.dumps({'sourceBaseCommit':'aed8cbb0','status':'corrected uncommitted actual source','sourceSHA256':freeze},indent=2)+'\n')
art=out/f'normal-attempt{attempt}-artifacts';art.mkdir(exist_ok=False)
env=os.environ.copy();env.update(GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local',TMPDIR=str(art));env['PATH']='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin:'+env['PATH']
cmd=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096','--seconds','180','--report',str(out/f'normal-attempt{attempt}-watchdog.json'),'--','/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go','test','-count=1','-json','-timeout=150s','-run','^TestPrepareFenceP02ActualOrderingAcrossElection$','./internal/graphapply']
with (out/f'normal-attempt{attempt}.log').open('w') as log:r=subprocess.run(cmd,cwd=root/'v5',env=env,stdout=log,stderr=subprocess.STDOUT)
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
print(json.dumps({'attempt':attempt,'exit':r.returncode,'watchdog':json.loads((out/f'normal-attempt{attempt}-watchdog.json').read_text())}))
raise SystemExit(r.returncode)
