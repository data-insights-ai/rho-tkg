import pathlib,json,hashlib,tarfile,gzip,io,re,subprocess
root=pathlib.Path('/var/tmp/rho-v5-p02-fence-election-20261014'); raw=pathlib.Path('/var/tmp/rho-v5-p02-runtime-20261014'); dest=root/'tasks/evidence/v2-p02-fence-election-20261014';dest.mkdir(exist_ok=False)
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();frozen=json.loads((raw/'attempt10-frozen-source.json').read_text())['sourceSHA256']
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==sha for p,sha in frozen.items())
items={}
def add(name,p):
 assert name not in items
 items[name]=pathlib.Path(p).read_bytes()
for p in sorted(raw.glob('*')):
 if p.is_file() and (p.suffix in ('.log','.json','.py') or p.name=='coverage.out'):
  add('runtime/'+p.name,p)
for mode in ('normal-attempt10','race','coverage'):
 for p in sorted((raw/(mode+'-artifacts')).glob('rho-*/p02-*.json')):
  if not p.name.startswith('p02-encountered-'):add(mode+'/'+p.name,p)
  else:add(mode+'/encountered/'+p.name,p)
 for p in sorted((raw/(mode+'-artifacts')).glob('rho-*/1/p02-fence-stage.json')):add(mode+'/stage/'+p.name,p)
for mode in ('normal','normal-attempt2','normal-attempt3','normal-attempt4','normal-attempt5','normal-attempt6','normal-attempt7','normal-attempt8','normal-attempt9'):
 for p in sorted((raw/(mode+'-artifacts')).glob('rho-*/p02-encountered-*.json')):add('failures/'+mode+'/'+p.name,p)
 for p in sorted((raw/(mode+'-artifacts')).glob('rho-*/1/p02-fence-stage.json')):add('failures/'+mode+'/stage/'+p.name,p)
add('source/final-go-manifest.json',raw/'attempt10-frozen-source.json')
source_paths=['v5/internal/graphapply/prepare_fence_p02_process_test.go','v5/internal/graphapply/prepare_fence_p02_harness_test.go','v5/internal/graphapply/replicated_process_test.go','tools/v5-substrate/check-p02-history.py','scripts/ci-changes.py','scripts/ci-changes-test.py']
for name in source_paths:add('source/'+name,root/name)
manifest={n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(items.items())}
with (dest/'raw.tar.gz').open('wb') as target:
 with gzip.GzipFile(fileobj=target,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,b in sorted(items.items()):
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(b))
def events(log):
 out=[]
 for line in (raw/log).open():
  try:v=json.loads(line)
  except ValueError:continue
  out.append(v)
 return out
def gate(mode,log,watch):
 es=events(log);terms=[e for e in es if e.get('Action') in ('pass','fail','skip')]; tests=[e for e in terms if e.get('Test')];parents=[e for e in tests if '/' not in e['Test']];package=[e for e in terms if not e.get('Test')][-1]
 assert package['Action']=='pass' and len(tests)==4 and all(t['Action']=='pass' for t in tests)
 cleanup=[e['Output'].strip() for e in es if 'paired cleanup:' in e.get('Output','')]
 assert len(cleanup)==3 and all('all-reaped=true' in l for l in cleanup)
 return {'status':'PASS','packageSeconds':package['Elapsed'],'parentCount':len(parents),'caseCount':len(tests)-len(parents),'failed':0,'skipped':0,'cleanup':cleanup,'watchdog':json.loads((raw/watch).read_text())}
gates={m:gate(m,log,watch) for m,log,watch in [('normal','normal-attempt10.log','normal-attempt10-watchdog.json'),('race','race.log','race-watchdog.json'),('coverage','coverage.log','coverage-watchdog.json')]}
for mode in ('vet','lint','security'):
 d=json.loads((raw/(mode+'-watchdog.json')).read_text());assert d['exit_code']==0;gates[mode]={'status':'PASS','watchdog':d}
failures=[]
for attempt in range(1,10):
 stem='normal' if attempt==1 else 'normal-attempt'+str(attempt);es=events(stem+'.log');d=json.loads((raw/(stem+'-watchdog.json')).read_text());assert d['exit_code']!=0
 failures.append({'attempt':attempt,'status':'RED—not accepted fault evidence','watchdog':d,'testTerminals':[e for e in es if e.get('Action') in ('pass','fail','skip') and e.get('Test')],'cleanup':[e['Output'].strip() for e in es if 'paired cleanup:' in e.get('Output','')]})
report={
 'date':'2026-10-14','scope':'Finite P02 native prepare/fence/election schedules only; not complete P02 family, full V2, power loss, full release coverage or old four-fault wrapper acceptance.',
 'parent':'TestPrepareFenceP02ActualOrderingAcrossElection','cases':['delayed-A-prepare','A-before-B-after','persisted-fence-before-application'],
 'sourceBaseCommit':'4b15598b','initialSourceCheckpoint':'aed8cbb0','qualificationSourceCommit':source_commit,'qualificationSourceNote':'Runtime used corrected uncommitted Go content based on aed8cbb0; final identical content committed afterward. All qualified Go/module SHA256 values match the complete frozen manifest.',
 'sourceSHA256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source_paths},'frozenGoSourceUnchanged':True,
 'environment':dict(GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local'),
 'pinnedGo':'/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go','goSHA256':'318dee99db233501f6c419fbb4616e5a345ed0b831dbd6c7669b24e1ff8e9e2e',
 'gates':gates,'historicalCompile':json.loads((raw/'compile-watchdog.json').read_text()),
 'coverage':{'percent':6.6,'scope':'Scoped parent-process production coverage diagnostic only; Go excludes test helpers and subprocess child profiles are not merged. No full-module 80% or release coverage claim.'},
 'clauseBinding':{
 'queuedPrepare':'Genuine pre-fence source capture and authenticated original crossPrepare are held before the participant receives it. Actual retained fence and election precede its Stage YES; original manifest, request, digest, retained vote and all encountered phase frames remain bound.',
 'participantOrdering':'Actual A YES floor6 is retained before real A/B fences106; original caller returns truthful pending after B election. Fresh authenticated same-B-coordinator recovery retains the original A vote; B votes106; COMMIT107.',
 'persistedFenceBeforeApplication':'Actual Stage wrapper observes original retained Raft entry Index/Term/Data/hash and HardCommit>=Index with prior checkpoint<Index, then actual A1 is SIGKILLed/reaped. A2 elected; same original fence applies before fresh source capture and YES106; COMMIT107. No manufactured floor/checkpoint/readiness.',
 'delayedLocal':'Ordinary source-produced local A Close is prepared before the retained fence, installed only after successor recovery/cross COMMIT at its actual assigned round>106 and>107. Complete local CDC checked; duplicate original preserves original identity/hash/index/why and returns documented requestReplay with zero CDC.',
 'historyRecovery':'Complete graph, both posting directions, bounded32 entity census, phantom absence, exact actual CDC, immutable original outcomes and old-cut equality checked before/after same-directory cohort reopen. Genuine election no-op entries captured before native compaction; no synthetic empty-entry proof.'},
 'oracle':{'status':'PASS','traces':9,'reports':json.loads((raw/'bridge-all-traces.log').read_text()),'implementation':'check-p02-history.py imports unchanged existing P06 wire primitives and hash-pinned independent serial/cut oracle. Closed-endpoint observation adapter compares actual JSON witnesses, supplies no reducer. Old four-fault acceptance wrapper not invoked.'},
 'failedAttempts':failures,'failureScope':'All nine RED normal attempts preserved literally with distinct source manifests. First RED cleanup included three unscheduled helper-timeout cleanup SIGKILLs; they are failure cleanup, never accepted fault schedule. Later RED attempts all reaped. Final qualified runs all owned children reaped, with one planned Stage leader SIGKILL per mode.',
 'failureCorrections':['Packet-only fence/election drainage while intentional relay gate is held','Fresh authenticated same-coordinator recovery after truthful follower ReadIndex pending; preserve original and recovery phase frames','Exact documented Register source-query projection versus actual retained Register floor','Finite phase-attempt capture excludes unrelated data-row traffic','Capture genuine election no-op entries before native log reclamation and snapshot compaction','Documented local requestReplay disposition preserves the complete original outcome identity/hash/index'],
 'cleanup':{'lease':'explicitly released to root after all approved heavy gates terminal','qualifiedIncarnations':111,'cleanExits':108,'intentionalStageLeaderKills':3,'allReaped':True,'watchdog':'180s/4096MiB aggregate; Go test150s; watchdog kills/reaps remaining owned descendants at each terminal','externalOriginalsPreserved':str(raw)},
 'remaining':'No approved finite component runtime gate remains. Source/receipt integration review and broader P02/V2 family acceptance are separate.',
 'raw':{'archive':'raw.tar.gz','sha256':hashlib.sha256((dest/'raw.tar.gz').read_bytes()).hexdigest(),'members':len(items),'bytes':(dest/'raw.tar.gz').stat().st_size,'manifest':'raw-manifest.json'}
}
(dest/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');(dest/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text('''# Finite native P02 prepare/fence/election receipt

The exact parent `TestPrepareFenceP02ActualOrderingAcrossElection` passes normal,
race and scoped coverage in all three cases, plus affected vet, configured lint
and security. Nine actual traces pass the existing independent serial/cut oracle.
Normal/race/coverage package times are 23.302/80.045/32.312 seconds; each mode
reaps 37 incarnations (36 clean exits and one planned A1 SIGKILL).

The schedules retain queued pre-fence Prepare, actual A-before/B-after YESes,
and a genuine fence persisted before Stage followed by leader loss/election.
Actual vote floors are [106,6] or [6,106], COMMIT is107; captured installed floors
remain6. The third case also installs and replays an original local Close prepared
before the fence. Complete current/old graph, postings, census, CDC and originals
are checked through same-directory rejoin/reopen. Register query projection and
local replay disposition are bound to their actual native API representations.

`receipt.json` binds final source, exact commands, raw traces and all nine prior
RED attempts. `raw-manifest.json` hashes every member of `raw.tar.gz`; external
original process directories remain preserved. Failed cleanup kills are not fault
acceptance. Scoped6.6% parent coverage excludes test helpers and unmerged child
profiles and makes no full-module/release coverage claim.

This finite receipt does not accept the complete P02 family, full V2, power loss,
or the old four-fault wrapper. The heavy lease was released after terminal gates.
''')
print(json.dumps({'directory':str(dest),'archive':report['raw'],'sourceCommit':source_commit}))
