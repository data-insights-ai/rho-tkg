import os,json,hashlib,pathlib,subprocess,sys
root=pathlib.Path('/var/tmp/rho-v5-p02-fence-election-20261014'); out=pathlib.Path('/var/tmp/rho-v5-p02-runtime-20261014'); go='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go'; scan='/var/tmp/rho-v5-migrate-main4517-0eb0a0ac-20261014/scanner-bin'
freeze=json.loads((out/'attempt10-frozen-source.json').read_text())['sourceSHA256']
def unchanged():assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
env=os.environ.copy();env.update(GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local');env['PATH']=str(pathlib.Path(go).parent)+':'+env['PATH']
base=[go,'test','-count=1','-json','-timeout=150s','-run','^TestPrepareFenceP02ActualOrderingAcrossElection$']
commands={'race':base+['-race','./internal/graphapply'],'coverage':base+['-covermode=atomic','-coverprofile='+str(out/'coverage.out'),'./internal/graphapply'],'vet':[go,'vet','./internal/graphapply'],'lint':[scan+'/golangci-lint','run','--config','../.golangci.yml','./internal/graphapply'],'security':[scan+'/gosec','-quiet','./internal/graphapply']}
for mode in sys.argv[1:]:
 unchanged();art=out/(mode+'-artifacts');art.mkdir(exist_ok=False);env['TMPDIR']=str(art)
 report=out/(mode+'-watchdog.json'); cmd=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096','--seconds','180','--report',str(report),'--']+commands[mode]
 with (out/(mode+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root/'v5',env=env,stdout=log,stderr=subprocess.STDOUT)
 unchanged();print(json.dumps({'gate':mode,'exit':r.returncode,'watchdog':json.loads(report.read_text())}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
