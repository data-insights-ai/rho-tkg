# Finite registry inventory integration review

Source: external commit `da78da2a`, composed without commit on accepted package 2 baseline `c61d1124` in `/var/tmp/rho-v5-v2-certified-reads-20261011`. All six staged paths / 1,892 additions were reviewed. The integration tree was not edited. Focused tests ran in an isolated 414-input copy retained with `source.json`; `review.patch` preserves the exact delta.

Recommendation: **semantic review passes; no concrete blocking or non-blocking defect found**. Inclusion still requires the remaining author/integration gates below. This is not acceptance of certified distributed reads or full V2.

The audit proves a complete registry census for its supported captured bank: every visible key run is traversed through bounded ControlPage work, every HKI lookup has the exact reciprocal HKV original, every HKV has its exact reciprocal lookup, and the canonical complete PIJ is inspected with graph/partition/group/lineage/protocol qualification and both hashes. Slot zero, insertion position and term, original creation outcomes, retained roots and the genesis origin are checked. Exact physical byte/record totals and one-to-one pair counts prevent omissions or extra/orphan controls from becoming a summary. Unknown families and malformed/foreign/rechecksummed entries refuse. Hash bytes alone do not admit a stored original; the full canonical inspector rederives the submitted identity and hashes.

The selected immutable format is 4 MiB per original, not an 8 MiB total-inventory ceiling. Phase visits/work and simultaneous ownership are bounded independently before action. Row and reciprocal payloads are dropped before historical checks. Cursor movement commits only after the row's validation, quota and cancellation refusals preserve the prior completed prefix, and errors yield no partial summary. Genuine handles are identity-checked and mutex-serialized; Close detaches the owner before native release and makes repeated callers await one completion.

Contract qualifications are material:

- The current constructor captures a current active view and census; Finish rechecks that it is still current. It may refuse if the active index/bank changes. It does not fabricate old totals from a newer current census.
- Prepared inventory uses the genuine supplied prepared bank, blocks claiming it while the audit reader is live, and never substitutes receiver-current history. The supplied term/voter context is inert expected metadata, not a quorum certificate; the audit checks the stored origin and term bounds against it. No activation authority is returned.
- These are registered GR2/AS4 empty-graph bootstrap inventories, under the separate compiled inventory agreement and version-2 shared contract. AS5 recovery/cross-partition graph readiness or arbitrary historical-current inventory support is not silently inferred.
- A summary is local read evidence. Register, factory, Host readiness, certified distributed graph cuts and snapshot activation remain outside this commit.

Test sufficiency: independent literal complete/missing/orphan pairs and byte censuses; foreign scope, bad contracts/hash/length/slot/index/term/outcome/unknown family refusals; exact and one-short work/ownership boundaries; cancellation and copied/nil/closed owner guards; three full 4 MiB originals exceeding 8 MiB total; real snapshot compaction/reopen; dormant genuine prepared audit and claim lifetime; graphstore caller validation/staging/accounting/pagination guards. New production file coverage is **337/382 statements = 88.2199%**. Advance, Finish and Close have direct tests. No fabricated hash-collision seam or distributed-cut oracle is claimed.

Independent focused verification, Go 1.26.9 / one invocation at a time / GOWORK off / two CPUs / GOMEMLIMIT 2 GiB / offline dependencies:

- `go test -short -count=1 -timeout=150s -coverprofile=... -run '^(TestRegisteredInventory|TestGuardCatalog|TestGuardExactComponent|TestGuardOwned|TestGuardPageUnbounded)' ./internal/graphapply ./internal/graphstore`: PASS, 12.405 seconds, 628.984 MiB peak process-tree RSS.
- Same focused selection with `-race`: PASS, 25.238 seconds, 581.531 MiB peak process-tree RSS.
- Both invocations retain the 4 GiB / 180-second watchdog; full commands and terminal receipts are in `normal-budget.json` and `race-budget.json`. The low package-wide percentages in focused output are intentional and are not full-module coverage evidence.

No relevant saved author gate report was found in the easy tracked evidence/reference lookup. Remaining gates before inclusion: compiler-matched format/vet/build; complete affected-package normal/race validation and combined coverage/direct-public inventory (or explicitly evidenced carry-forward for unchanged paths); pinned v5 golangci-lint v2.13.2, gosec v2.29.0 and govulncheck v1.7.0 on the exact composed source. Full-module/hosted integration is root-owned; this finite review did not rerun it or assume it completed.

Heavy slot explicitly released after sessions 14577 and 20947 terminated. No live process, probe source changes, commit, push, new phase, roadmap edit or extra reviewer was introduced.
