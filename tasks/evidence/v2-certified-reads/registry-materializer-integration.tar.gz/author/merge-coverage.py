from pathlib import Path
import json,hashlib
out=Path(__file__).parent;prior=Path('/var/tmp/rho-v5-v2-preclaim-evidence-20261011')
current=json.loads((out/'source.json').read_text());old=json.loads((prior/'source.json').read_text());prefix='github.com/data-insights-ai/rho-tkg/v5/'
blocks={};accepted=excluded=fresh=0
for label,profile in [('accepted-preclaim',prior/'coverage.out'),('fresh-registry',out/'registry-coverage.out')]:
 lines=profile.read_text().splitlines();assert lines[0]=='mode: set'
 for line in lines[1:]:
  span,statements,count=line.split();file=span.split(':')[0];path='v5/'+file.removeprefix(prefix);assert file.startswith(prefix)
  if label=='accepted-preclaim' and current.get(path)!=old.get(path):excluded+=1;continue
  if label=='accepted-preclaim':accepted+=1
  else:fresh+=1
  n=int(statements);hit=int(count)>0
  if span in blocks:
   old_n,old_hit=blocks[span];assert n==old_n,(span,n,old_n);hit=hit or old_hit
  blocks[span]=(n,hit)
(out/'coverage.out').write_text('\n'.join(['mode: set']+[f'{span} {n} {int(hit)}' for span,(n,hit) in sorted(blocks.items())])+'\n')
perfile={}
for span,(n,hit) in blocks.items():
 path='v5/'+span.split(':')[0].removeprefix(prefix);total,covered=perfile.get(path,(0,0));perfile[path]=(total+n,covered+(n if hit else 0))
total=sum(x[0] for x in perfile.values());covered=sum(x[1] for x in perfile.values());changed={}
for name in ['v5/internal/graphapply/registered_registry_codec.go','v5/internal/graphapply/registered_registry_materializer.go']:
 t,h=perfile[name];changed[name]={'covered':h,'total':t,'percent':100*h/t};assert 100*h/t>=80
summary={'prior_source_manifest_sha256':hashlib.sha256((prior/'source.json').read_bytes()).hexdigest(),'accepted_unchanged_blocks':accepted,'discarded_changed_source_blocks':excluded,'fresh_registry_blocks':fresh,'covered_statements':covered,'total_statements':total,'percent':100*covered/total,'changed_files':changed,'qualification':'Changed codec/materializer coverage is exclusively fresh. Remaining module coverage carries only exact unchanged file hashes from accepted preclaim/P3. Every overlapping statement count agrees. This is qualified coverage carry, not a fresh whole-module or exhaustive affected graphapply runtime run; the latter remains the combined P4 gate.'}
(out/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));assert summary['percent']>=80
