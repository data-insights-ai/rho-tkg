package raftlog

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"math"
	"sync"

	"github.com/cockroachdb/pebble/v2"
	pb "go.etcd.io/raft/v3/raftpb"
)

// ApplicationPolicy selects a provisional local-root checkpoint mode. The
// immutable KV/install contracts are independent of graph layout; LocalVoter
// fences this integration until transferable application snapshots exist.
// RetainedApplicationBytes counts ALL immutable logical keys/frames/values,
// roots, changes and outcomes; it is NOT a physical disk quota. WAL/SST and
// compaction amplification, OS cache and caller-retained copies are separate.
// KV/envelope reads are serialized and expose at most MaxPageBytes owned output
// capacity plus one bounded key/value lookahead. Root image capacity is bounded
// separately by MaxImageBytes; retained views share MaxViewBytes. These visible
// slice capacities do not measure allocator rounding, heap/RSS or temporary work.
// Policies are explicit, versioned and must match exactly on reopen.
type ApplicationPolicy struct {
	LocalVoter                                                         uint64
	MaxKeyBytes, MaxValueBytes, MaxImageBytes                          int
	MaxPageRows, MaxPageBytes                                          int
	MaxInstallWrites, MaxInstallBytes, MaxChangeBytes, MaxOutcomeBytes int
	MaxViews, MaxViewBytes                                             int
	RetainedApplicationBytes, RetainedApplicationRecords               uint64
	MaxTailEntries, MaxTailBytes, ReclaimEntries                       uint64
}

// DefaultApplicationPolicy returns finite candidate limits, not capacity/SLOs.
func DefaultApplicationPolicy(voter uint64) ApplicationPolicy {
	return ApplicationPolicy{voter, 1024, 1 << 20, 64 << 10, 4096, 2 << 20, 4096, 4 << 20, 1 << 20, 64 << 10, 16, 1 << 20, 1 << 30, 1_000_000, 64, 16 << 20, 32}
}

// Enabled distinguishes explicit application mode from the scalar adapter.
func (p ApplicationPolicy) Enabled() bool { return p != (ApplicationPolicy{}) }

// Validate checks finite limits and consensus admission headroom.
func (p ApplicationPolicy) Validate(l Limits) error { return p.validate(l) }
func (p ApplicationPolicy) validate(l Limits) error {
	if !p.Enabled() {
		return nil
	}
	if p.LocalVoter == 0 || p.LocalVoter >= math.MaxUint64-1 {
		return ErrInvalid
	}
	for _, n := range []int{p.MaxKeyBytes, p.MaxValueBytes, p.MaxImageBytes, p.MaxPageRows, p.MaxPageBytes, p.MaxInstallWrites, p.MaxInstallBytes, p.MaxChangeBytes, p.MaxOutcomeBytes, p.MaxViews, p.MaxViewBytes} {
		if n < 1 || n > 64<<20 {
			return ErrInvalid
		}
	}
	if p.MaxKeyBytes > 64<<10 || p.MaxValueBytes > 16<<20 || p.MaxImageBytes > l.MaxSnapshotBytes || p.MaxPageRows > 4096 || p.MaxInstallWrites > 4096 || p.MaxViews > 4096 || p.MaxViewBytes < p.MaxImageBytes || p.MaxPageBytes < 2*p.MaxKeyBytes+p.MaxValueBytes+64 || p.MaxChangeBytes > p.MaxPageBytes || p.MaxOutcomeBytes > p.MaxPageBytes || p.MaxInstallBytes < 1024+2*3*(9+appFrameBytes) || p.RetainedApplicationBytes < unsignedLimit(2*p.MaxInstallBytes) || p.RetainedApplicationBytes > 1<<40 || p.RetainedApplicationRecords < unsignedLimit(2*(p.MaxInstallWrites+3)) || p.RetainedApplicationRecords > 1<<40 || p.MaxTailEntries < 2 || p.MaxTailEntries > l.MaxRetainedEntries || p.MaxTailBytes < unsignedLimit(l.MaxEntryBytes+9+frameOverhead+9) || p.MaxTailBytes > l.MaxRetainedBytes || p.ReclaimEntries < 1 || p.ReclaimEntries > l.MaxRetainedEntries-2 || l.MaxRetainedEntries < 3 || l.MaxRetainedBytes < unsignedLimit(l.MaxEntryBytes+9+frameOverhead+9) {
		return ErrInvalid
	}
	return nil
}

type applicationMetadata struct {
	Policy                             ApplicationPolicy
	Bytes, Records, Through, TailBytes uint64
}

func applicationNumbers(a applicationMetadata) []uint64 {
	p := a.Policy
	return []uint64{p.LocalVoter, unsignedLimit(p.MaxKeyBytes), unsignedLimit(p.MaxValueBytes), unsignedLimit(p.MaxImageBytes), unsignedLimit(p.MaxPageRows), unsignedLimit(p.MaxPageBytes), unsignedLimit(p.MaxInstallWrites), unsignedLimit(p.MaxInstallBytes), unsignedLimit(p.MaxChangeBytes), unsignedLimit(p.MaxOutcomeBytes), unsignedLimit(p.MaxViews), unsignedLimit(p.MaxViewBytes), p.RetainedApplicationBytes, p.RetainedApplicationRecords, p.MaxTailEntries, p.MaxTailBytes, p.ReclaimEntries, a.Bytes, a.Records, a.Through, a.TailBytes}
} // #nosec G115 -- policy int fields validated positive before persistence.
func appendApplicationMeta(dst []byte, a applicationMetadata) []byte {
	dst = append(dst, 'A', 'M', 1, 0)
	for _, n := range applicationNumbers(a) {
		dst = binary.BigEndian.AppendUint64(dst, n)
	}
	return dst
}
func decodeApplicationMeta(src []byte) (applicationMetadata, []byte, error) {
	const size = 4 + 21*8
	if len(src) < size || !bytes.Equal(src[:4], []byte{'A', 'M', 1, 0}) {
		return applicationMetadata{}, nil, ErrCorrupt
	}
	var ns [21]uint64
	for i := range ns {
		ns[i] = binary.BigEndian.Uint64(src[4+8*i:])
	}
	for _, n := range ns[1:12] {
		if n > 64<<20 {
			return applicationMetadata{}, nil, ErrCorrupt
		}
	}
	p := ApplicationPolicy{ns[0], int(ns[1]), int(ns[2]), int(ns[3]), int(ns[4]), int(ns[5]), int(ns[6]), int(ns[7]), int(ns[8]), int(ns[9]), int(ns[10]), int(ns[11]), ns[12], ns[13], ns[14], ns[15], ns[16]}
	return applicationMetadata{p, ns[17], ns[18], ns[19], ns[20]}, src[size:], nil
} // #nosec G115 -- int fields prevalidated against 64 MiB.
func localConfiguration(c *pb.ConfState, id uint64) bool {
	return c != nil && len(c.ProtoReflect().GetUnknown()) == 0 && len(c.GetVoters()) == 1 && c.GetVoters()[0] == id && len(c.GetVotersOutgoing()) == 0 && len(c.GetLearners()) == 0 && len(c.GetLearnersNext()) == 0 && !c.GetAutoLeave()
}
func (s *Store) validateApplicationMeta(m metadata) error {
	a, p := m.App, m.App.Policy
	if !p.Enabled() {
		if a != (applicationMetadata{}) {
			return ErrInvalid
		}
		return nil
	}
	if err := p.validate(s.limits); err != nil {
		return err
	}
	if a.Bytes > p.RetainedApplicationBytes || a.Records > p.RetainedApplicationRecords || a.Through != m.Applied || a.TailBytes > p.MaxTailBytes || m.Last-m.Applied > p.MaxTailEntries {
		return ErrLimit
	}
	pending := m.Last - m.Applied
	totalBytes, totalRecords := applicationTotals(m)
	protected, pendingBytes, pendingRecords, err := recoveryProjected(m, s.limits, pending)
	if err != nil {
		return err
	}
	protected.logBytes += m.Recovery.Staged.logBytes
	protected.logRecords += m.Recovery.Staged.logRecords
	if err := recoveryFits(protected, totalBytes, totalRecords, m.LogBytes, m.LogCount, p, s.limits); err != nil {
		return err
	}
	totalBytes += protected.bytes
	totalRecords += protected.records
	if pendingBytes > p.RetainedApplicationBytes-totalBytes || pendingRecords > p.RetainedApplicationRecords-totalRecords {
		return ErrLimit
	}
	if m.Applied > 0 && (!applicationConfiguration(m, m.Conf) || !applicationConfiguration(m, m.Snap.GetMetadata().GetConfState()) || m.ImageBytes > unsignedLimit(p.MaxImageBytes)) {
		return ErrInvalid
	}
	if a.TailBytes < pending*(frameOverhead+9) || a.TailBytes > pending*unsignedLimit(s.limits.MaxEntryBytes+9) {
		return ErrCorrupt
	}
	return nil
}

const appFrameBytes = 36
const appDataTag byte = 8
const appRootTag byte = 9
const appChangeTag byte = 10
const appOutcomeTag byte = 11

func appIndexKey(tag byte, index uint64) []byte {
	return binary.BigEndian.AppendUint64([]byte{tag}, index)
}
func appPrefix(key []byte) []byte {
	b := make([]byte, 1, 2*len(key)+3)
	b[0] = appDataTag
	for _, c := range key {
		if c == 0 {
			b = append(b, 0, 255)
		} else {
			b = append(b, c)
		}
	}
	return append(b, 0, 0)
}
func appVersionKey(key []byte, index uint64) []byte {
	return binary.BigEndian.AppendUint64(appPrefix(key), ^index)
}
func appNextPrefix(prefix []byte) []byte { b := bytes.Clone(prefix); b[len(b)-1]++; return b }
func decodeAppKey(src []byte, maxBytes int) ([]byte, uint64, error) {
	return decodeTaggedAppKey(src, maxBytes, appDataTag)
}
func decodeTaggedAppKey(src []byte, maxBytes int, tag byte) ([]byte, uint64, error) {
	if len(src) < 12 || src[0] != tag || len(src) > 2*maxBytes+11 {
		return nil, 0, ErrCorrupt
	}
	key := make([]byte, 0, min(len(src), maxBytes))
	for i := 1; i < len(src)-8; i++ {
		c := src[i]
		if c == 0 {
			i++
			if i >= len(src)-8 {
				return nil, 0, ErrCorrupt
			}
			if src[i] == 0 {
				if i != len(src)-9 || len(key) == 0 {
					return nil, 0, ErrCorrupt
				}
				index := ^binary.BigEndian.Uint64(src[len(src)-8:])
				if index < 2 || index == math.MaxUint64 {
					return nil, 0, ErrCorrupt
				}
				return key, index, nil
			}
			if src[i] != 255 {
				return nil, 0, ErrCorrupt
			}
			c = 0
		}
		if len(key) >= maxBytes {
			return nil, 0, ErrCorrupt
		}
		key = append(key, c)
	}
	return nil, 0, ErrCorrupt
}
func appFrame(key, value []byte, deleted bool) []byte {
	b := make([]byte, appFrameBytes, appFrameBytes+len(value))
	copy(b, []byte{'A', 'V', 1, 0})
	if deleted {
		b[3] = 1
	}
	b = append(b, value...)
	h := sha256.New()
	_, _ = h.Write(key)
	_, _ = h.Write(b[:4])
	_, _ = h.Write(value)
	copy(b[4:36], h.Sum(nil))
	return b
}
func inspectAppFrame(key, src []byte, maxBytes int) ([]byte, bool, error) {
	if len(src) < appFrameBytes || len(src)-appFrameBytes > maxBytes || src[0] != 'A' || src[1] != 'V' || src[2] != 1 || src[3] > 1 || src[3] == 1 && len(src) != appFrameBytes {
		return nil, false, ErrCorrupt
	}
	h := sha256.New()
	_, _ = h.Write(key)
	_, _ = h.Write(src[:4])
	_, _ = h.Write(src[appFrameBytes:])
	if !bytes.Equal(src[4:36], h.Sum(nil)) {
		return nil, false, ErrCorrupt
	}
	return src[appFrameBytes:], src[3] == 1, nil
}
func (s *Store) appGet(key []byte, maxBytes int) ([]byte, bool, error) {
	b, c, err := s.db.Get(key)
	if errors.Is(err, pebble.ErrNotFound) {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	data, deleted, e := inspectAppFrame(key, b, maxBytes)
	out := []byte(nil)
	if e == nil {
		out = bytes.Clone(data)
	}
	return out, !deleted, errors.Join(e, c.Close())
}
func (s *Store) verifyApplicationRoot(index uint64) error {
	image, found, err := s.appGet(bankIndexKey(s.activeBank(), appRootTag, index), s.meta.App.Policy.MaxImageBytes)
	if err != nil {
		return storedReadFailure(err)
	}
	if !found || uint64(len(image)) != s.meta.ImageBytes || sha256.Sum256(image) != s.meta.ImageHash {
		return ErrCorrupt
	}
	if s.meta.Recovery.Config.enabled() {
		r, e := s.loadRecoveryRootAt(s.activeBank(), index)
		if e != nil || !sameRecoveryReservation(r, s.meta.Recovery.Reservation) {
			return errors.Join(ErrCorrupt, e)
		}
	}
	for _, tag := range []byte{appChangeTag, appOutcomeTag} {
		limit := s.meta.App.Policy.MaxChangeBytes
		if tag == appOutcomeTag {
			limit = s.meta.App.Policy.MaxOutcomeBytes
		}
		_, found, err := s.appGet(bankIndexKey(s.activeBank(), tag, index), limit)
		if err != nil {
			return storedReadFailure(err)
		}
		if !found {
			return ErrCorrupt
		}
	}
	return nil
}
func (s *Store) addInitialApplication(b *pebble.Batch, m *metadata, image []byte) error {
	if m.Recovery.Config.enabled() {
		key := appIndexKey(recoveryRootTag+m.Gen.Active, 1)
		value := appFrame(key, appendRecoveryRoot(m.Recovery.Reservation), false)
		if err := b.Set(key, value, nil); err != nil {
			return err
		}
		m.Recovery.Bytes = uint64(len(key) + len(value))
		m.Recovery.Records = 1
	}
	for _, v := range []struct {
		tag  byte
		data []byte
	}{{appRootTag, image}, {appChangeTag, nil}, {appOutcomeTag, nil}} {
		k := bankIndexKey(m.Gen.Active, v.tag, 1)
		value := appFrame(k, v.data, false)
		if err := b.Set(k, value, nil); err != nil {
			return err
		}
		m.App.Bytes += uint64(len(k) + len(value))
		m.App.Records++
	}
	m.App.Through = 1
	return s.validateApplicationMeta(*m)
}

// KV carries an owned value or an explicit tombstone. Empty present bytes and
// tombstones are different. Logical keys are nonempty arbitrary bounded bytes.
type KV struct {
	Key, Value []byte
	Deleted    bool
}

// ApplicationBatch is a private bounded checkpoint installation. Changes and
// Outcome are complete opaque envelopes supplied by the trusted state machine;
// this storage layer never interprets graph semantics or certifies a graph cut.
// BaseGeneration must match the captured local physical generation in RLM5;
// zero is the legacy binding, never replicated semantic time/effect identity.
type ApplicationBatch struct {
	RecoveryAdmission *ApplicationRecoveryAdmission
	RecoveryReserve   *ApplicationRecoveryReservation
	RecoveryUse       *ApplicationRecoveryUse
	BaseGeneration    uint64
	BaseImageHash     [32]byte
	BaseIndex         uint64
	Image             []byte
	Writes            []KV
	Changes, Outcome  []byte
	ControlPuts       []ApplicationControlPut
}

// ApplicationBudget bounds conservative encoded installation staging including
// framing/copies, not Go heap/RSS or caller-retained buffers.
type ApplicationBudget struct{ Writes, Bytes, ImageBytes, ChangeBytes, OutcomeBytes int }

// ApplicationLimits returns the immutable policy; nil returns disabled mode.
func (s *Store) ApplicationLimits() ApplicationPolicy {
	if s == nil {
		return ApplicationPolicy{}
	}
	return s.applicationPolicy
}

// ApplicationBudget returns the concrete state-machine staging limits.
func (s *Store) ApplicationBudget() ApplicationBudget {
	p := s.ApplicationLimits()
	return ApplicationBudget{p.MaxInstallWrites, p.MaxInstallBytes, p.MaxImageBytes, p.MaxChangeBytes, p.MaxOutcomeBytes}
}

func (p ApplicationPolicy) measure(b ApplicationBatch) (uint64, uint64, error) {
	if len(b.Writes)+len(b.ControlPuts) > p.MaxInstallWrites || len(b.Image) > p.MaxImageBytes || len(b.Changes) > p.MaxChangeBytes || len(b.Outcome) > p.MaxOutcomeBytes {
		return 0, 0, ErrLimit
	}
	retained := uint64(3*(9+appFrameBytes) + len(b.Image) + len(b.Changes) + len(b.Outcome))
	work := 2*retained + uint64(len(b.Image)+1024)
	for i, w := range b.Writes {
		if len(w.Key) == 0 || w.Deleted && len(w.Value) != 0 || i > 0 && bytes.Compare(b.Writes[i-1].Key, w.Key) >= 0 {
			return 0, 0, ErrInvalid
		}
		if len(w.Key) > p.MaxKeyBytes || len(w.Value) > p.MaxValueBytes {
			return 0, 0, ErrLimit
		}
		size := unsignedLimit(len(w.Key) + bytes.Count(w.Key, []byte{0}) + 3 + 8 + appFrameBytes + len(w.Value))
		retained += size
		work += 2*size + 64
		if work > unsignedLimit(p.MaxInstallBytes) {
			return 0, 0, ErrLimit
		}
	}
	cb, cr, cw, err := controlGrowth(p, b)
	if err != nil {
		return 0, 0, err
	}
	retained += cb
	work += cw
	if work > unsignedLimit(p.MaxInstallBytes) {
		return 0, 0, ErrLimit
	}
	return retained, uint64(len(b.Writes)+3) + cr, nil
}

// InstallApplication synchronously co-commits immutable KV versions, a retained
// root, full change group/outcome, checkpoint image and applied/tail ledgers.
// It accepts ONLY the next already committed normal entry and matching base.
// Errors before batch commit leave durable state unchanged. Uncertain write or
// close failures poison the store; callers must stop serving and reopen.
func (s *Store) InstallApplication(index uint64, b ApplicationBatch) error {
	if s == nil {
		return ErrInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.check(); err != nil {
		return err
	}
	p := s.meta.App.Policy
	if b.BaseGeneration != s.activeGeneration() {
		return ErrInvalid
	}
	if !p.Enabled() || index != s.meta.Applied+1 || index > s.meta.Hard.GetCommit() || b.BaseIndex != s.meta.Applied || b.BaseImageHash != s.meta.ImageHash {
		return ErrInvalid
	}
	if b.RecoveryReserve != nil || b.RecoveryUse != nil {
		if !s.meta.Recovery.Config.enabled() {
			return ErrInvalid
		}
		if b.RecoveryUse != nil && (b.RecoveryReserve != nil || b.RecoveryAdmission == nil) {
			return ErrInvalid
		}
	}
	recoveryState := s.meta.Recovery
	if b.RecoveryReserve != nil {
		var reserveErr error
		recoveryState, reserveErr = recoveryState.reserve(*b.RecoveryReserve, p, s.limits)
		if reserveErr != nil {
			return reserveErr
		}
	} else if b.RecoveryUse != nil {
		var consumeErr error
		recoveryState, _, consumeErr = recoveryState.consume(*b.RecoveryUse)
		if consumeErr != nil {
			return consumeErr
		}
	}
	added, count, err := p.measure(b)
	if recoveryState.Config.enabled() {
		added, count, err = p.measureRecovery(b, recoveryState.Reservation)
	}
	if err != nil {
		return err
	}
	if len(b.ControlPuts) > 0 && !s.meta.Controls.Config.enabled() {
		return ErrInvalid
	}
	cb, cr, _, err := controlGrowth(p, b)
	if err != nil {
		return err
	}
	// A cached completed Use may stage a no-op rather than consume a phase again.
	// Its pending charge still bounds the actual installation; neither replay nor
	// terminal retirement transfers that protected backing to arbitrary traffic.
	for _, q := range s.meta.Recovery.Queued {
		if q.Index == index && q.Purpose.Use != nil && (added > q.Credit.RetainedBytes || count > q.Credit.RetainedRecords) {
			return ErrLimit
		}
	}
	retained, rows := applicationTotals(s.meta)
	if added > p.RetainedApplicationBytes-retained || count > p.RetainedApplicationRecords-rows {
		return ErrLimit
	}
	prospective := s.meta
	if b.RecoveryUse != nil {
		entry, _, _, readErr := s.get(index)
		if readErr != nil {
			s.poison = readErr
			return readErr
		}
		if !b.RecoveryAdmission.matches(s, entry.GetData(), *b.RecoveryUse) {
			return ErrInvalid
		}
		var credit ApplicationRecoveryCredit
		prospective.Recovery, credit, err = prospective.Recovery.consume(*b.RecoveryUse)
		if err != nil {
			return err
		}
		if added > credit.RetainedBytes || count > credit.RetainedRecords {
			return ErrLimit
		}
	}
	if b.RecoveryReserve != nil {
		if recoveryMetadataFixedBytes+recoveryCreditBytes*len(b.RecoveryReserve.Credits) > maxMetadataBytes {
			return ErrLimit
		}
		future, err := recoveryGrowth(*b.RecoveryReserve, p, s.limits)
		if err != nil {
			return err
		}
		if err := recoveryFits(future, retained+added, rows+count, s.meta.LogBytes, s.meta.LogCount, p, s.limits); err != nil {
			return err
		}
		prospective.Recovery, err = prospective.Recovery.reserve(*b.RecoveryReserve, p, s.limits)
		if err != nil {
			return err
		}
	}
	prospective.Recovery = prospective.Recovery.afterApplied(index)
	prospective.Applied = index
	prospective.App.Through = index
	rb, rr := uint64(0), uint64(0)
	if recoveryState.Config.enabled() {
		rb, rr, _ = ApplicationRecoveryRootOverhead(len(recoveryState.Reservation.Credits))
		prospective.Recovery.Bytes += rb
		prospective.Recovery.Records += rr
	}
	prospective.App.Bytes += added - cb - rb
	prospective.App.Records += count - cr - rr
	prospective.Controls.Bytes += cb
	prospective.Controls.Records += cr
	syncActiveGeneration(&prospective)
	if err := generationCharge(prospective, prospective.Last-index, s.limits); err != nil {
		return err
	}
	e, _, _, err := s.get(index)
	if err != nil {
		s.poison = err
		return err
	}
	if e.GetType() != pb.EntryNormal {
		return ErrInvalid
	}
	size := uint64(frameOverhead + 9 + len(e.GetData()))
	if size > s.meta.App.TailBytes {
		s.poison = ErrCorrupt
		return ErrCorrupt
	}
	m := s.meta
	m.Recovery = prospective.Recovery
	m.Applied = index
	m.App.Through = index
	m.App.TailBytes -= size
	m.App.Bytes += added - cb - rb
	m.App.Records += count - cr - rr
	m.Controls.Bytes += cb
	m.Controls.Records += cr
	m.ImageBytes = uint64(len(b.Image))
	m.ImageHash = sha256.Sum256(b.Image)
	syncActiveGeneration(&m)
	if err := s.validate(m); err != nil {
		return err
	}
	work := 2*added + uint64(len(b.Image)+1024) + uint64(64*(len(b.Writes)+len(b.ControlPuts)))
	for _, w := range b.ControlPuts {
		work += 128 + 4*controlPhysicalKeyBytes(w.Key)
	}
	limit := unsignedLimit(p.MaxInstallBytes)
	if work > limit {
		return ErrLimit
	}
	for _, w := range b.ControlPuts {
		n, e := s.controlAbsent(w.Key, limit-work)
		if e != nil {
			return e
		}
		work += n
	}
	batch := s.db.NewBatch()
	if recoveryState.Config.enabled() {
		key := appIndexKey(recoveryRootTag+s.activeBank(), index)
		if err := batch.Set(key, appFrame(key, appendRecoveryRoot(recoveryState.Reservation), false), nil); err != nil {
			return errors.Join(err, batch.Close())
		}
	}
	fail := func(e error) error { return errors.Join(e, batch.Close()) }
	for _, w := range b.Writes {
		k := bankVersionKey(s.activeBank(), w.Key, index)
		if err := batch.Set(k, appFrame(k, w.Value, w.Deleted), nil); err != nil {
			return fail(err)
		}
	}
	for _, w := range b.ControlPuts {
		k := controlVersionKey(s.activeBank(), w.Key, index)
		if err := batch.Set(k, appFrame(k, w.Value, false), nil); err != nil {
			return fail(err)
		}
	}
	for _, v := range []struct {
		tag  byte
		data []byte
	}{{appRootTag, b.Image}, {appChangeTag, b.Changes}, {appOutcomeTag, b.Outcome}} {
		k := bankIndexKey(s.activeBank(), v.tag, index)
		if err := batch.Set(k, appFrame(k, v.data, false), nil); err != nil {
			return fail(err)
		}
	}
	if err := batch.Set(imageKey, b.Image, nil); err != nil {
		return fail(err)
	}
	return s.commit(m, batch)
}

// AdmitApplication conservatively reserves worst-case installation growth for
// the proposal AND one internal no-op before RawNode accepts work. Rejections
// are pre-proposal; unexpected failures after durable commit require fail-stop.
func (s *Store) AdmitApplication(commandBytes int) error {
	if s == nil {
		return ErrInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.check(); err != nil {
		return err
	}
	return s.admitApplicationLocked(commandBytes)
}

func (s *Store) admitApplicationLocked(commandBytes int) error {
	p := s.meta.App.Policy
	if !p.Enabled() || s.meta.Applied == 0 || commandBytes < 0 {
		return ErrInvalid
	}
	if commandBytes > s.limits.MaxEntryBytes-frameOverhead {
		return ErrLimit
	}
	count := s.meta.Last - s.meta.Applied + 2
	totalBytes, totalRecords := applicationTotals(s.meta)
	protected, pendingBytes, pendingRecords, err := recoveryProjected(s.meta, s.limits, count)
	if err != nil {
		return err
	}
	protected.logBytes += s.meta.Recovery.Staged.logBytes
	protected.logRecords += s.meta.Recovery.Staged.logRecords
	if err := recoveryFits(protected, totalBytes, totalRecords, s.meta.LogBytes, s.meta.LogCount, p, s.limits); err != nil {
		return err
	}
	totalBytes += protected.bytes
	totalRecords += protected.records
	logBytes := s.meta.LogBytes + protected.logBytes
	logRecords := s.meta.LogCount + protected.logRecords
	extra := uint64(commandBytes + 2*(frameOverhead+9))
	if count > p.MaxTailEntries || extra > p.MaxTailBytes-s.meta.App.TailBytes || logRecords+2 > s.limits.MaxRetainedEntries || extra > s.limits.MaxRetainedBytes-logBytes || pendingBytes > p.RetainedApplicationBytes-totalBytes || pendingRecords > p.RetainedApplicationRecords-totalRecords {
		return ErrLimit
	}
	return generationCharge(s.meta, count, s.limits)
}

// ReclaimApplication replaces the local recovery base only at its configured
// retained-log watermark. Application versions, roots, CDC and outcomes survive.
func (s *Store) ReclaimApplication() error {
	if s == nil {
		return ErrInvalid
	}
	s.publicationMu.Lock()
	defer s.publicationMu.Unlock()
	s.mu.Lock()
	if err := s.check(); err != nil {
		s.mu.Unlock()
		return err
	}
	p := s.meta.App.Policy
	if !p.Enabled() {
		s.mu.Unlock()
		return ErrInvalid
	}
	headroom := unsignedLimit(s.limits.MaxEntryBytes + 9 + frameOverhead + 9)
	needed := (s.meta.LogCount >= p.ReclaimEntries || s.meta.LogBytes > s.limits.MaxRetainedBytes-headroom || s.meta.LogCount > s.limits.MaxRetainedEntries-2) && s.meta.Applied > s.meta.Base
	s.mu.Unlock()
	if needed {
		return s.publishSnapshot()
	}
	return nil
}

// ReadBudget bounds visited logical keys as well as owned returned bytes. A
// tombstone consumes work even though it is not emitted in a scan.
type ReadBudget struct{ Rows, Bytes int }

// ApplicationPage owns copied rows and a last-visited logical key continuation.
// Bytes conservatively covers both visited-key work and retained output, including
// the Rows backing capacity; it is not a heap/RSS or allocator-size measurement.
// Next must be reused with the same view/range. Complete is explicit; empty
// output can have a continuation when a page contains only tombstones.
type ApplicationPage struct {
	Rows           []KV
	Next           []byte
	Complete       bool
	Visited, Bytes int
}

// ApplicationRoot is an owned local checkpoint reference, NOT a certified cut.
// Generation is a local physical-bank binding, zero in legacy mode; it is not
// replicated semantic time or an effect identity.
type ApplicationRoot struct {
	Generation uint64
	Index      uint64
	Image      []byte
	ImageHash  [32]byte
}

// ApplicationView reads immutable MVCC versions at one retained root. It pins
// no backend snapshot and keeps no per-record index. Close serializes with reads.
type ApplicationView struct {
	self, next  *ApplicationView
	prepared    *PreparedApplicationSnapshot
	reservation uint64
	bank        byte
	generation  uint64
	ref         *generationRef
	mu          sync.Mutex
	s           *Store
	index       uint64
	image       []byte
	closed      bool
}

// ApplicationView opens a bounded root handle. Roots never expire in this slice;
// retained-data quotas backpressure writes instead of reclaiming view evidence.
func (s *Store) ApplicationView(index uint64) (*ApplicationView, error) {
	if s == nil {
		return nil, ErrInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.check(); err != nil {
		return nil, err
	}
	p := s.meta.App.Policy
	if !p.Enabled() || index == 0 || index > s.meta.Applied {
		return nil, ErrInvalid
	}
	if s.views >= p.MaxViews {
		return nil, ErrLimit
	}
	key := bankIndexKey(s.activeBank(), appRootTag, index)
	raw, closer, err := s.db.Get(key)
	if errors.Is(err, pebble.ErrNotFound) {
		s.poison = ErrCorrupt
		return nil, ErrCorrupt
	}
	if err != nil {
		s.poison = err
		return nil, err
	}
	data, deleted, inspectErr := inspectAppFrame(key, raw, p.MaxImageBytes)
	if deleted {
		inspectErr = ErrCorrupt
	}
	fits := len(data) <= p.MaxViewBytes-s.viewBytes
	var owned []byte
	if inspectErr == nil && fits {
		owned = copyApplicationBytes(data)
	}
	if err := errors.Join(inspectErr, closer.Close()); err != nil {
		s.poison = err
		return nil, err
	}
	if !fits {
		return nil, ErrLimit
	}
	ref, err := s.pinGeneration(s.activeBank())
	if err != nil {
		return nil, err
	}
	s.views++
	s.viewBytes += len(owned)
	v := &ApplicationView{s: s, index: index, image: owned, bank: s.activeBank(), generation: s.activeGeneration(), ref: ref}
	s.registerApplicationView(v)
	return v, nil
}
func (v *ApplicationView) lock(ctx context.Context) error {
	if v == nil || v.s == nil || v.self != v || ctx == nil {
		return ErrInvalid
	}
	v.mu.Lock()
	if v.closed {
		v.mu.Unlock()
		return ErrClosed
	}
	if err := ctx.Err(); err != nil {
		v.mu.Unlock()
		return err
	}
	v.s.mu.Lock()
	if !v.s.ownsApplicationView(v) {
		v.s.mu.Unlock()
		v.mu.Unlock()
		return ErrInvalid
	}
	if v.generation != 0 && v.s.meta.Gen.Banks[v.bank].Generation != v.generation {
		v.s.mu.Unlock()
		v.mu.Unlock()
		return ErrClosed
	}
	if err := v.s.check(); err != nil {
		v.s.mu.Unlock()
		v.mu.Unlock()
		return err
	}
	if v.prepared != nil {
		p := v.prepared
		if p.s != v.s || p.self != p || p.bank != v.bank || p.generation != v.generation {
			v.s.mu.Unlock()
			v.mu.Unlock()
			return ErrInvalid
		}
		if err := p.live(); err != nil {
			v.s.mu.Unlock()
			v.mu.Unlock()
			return err
		}
	}
	return nil
}
func (v *ApplicationView) unlock() { v.s.mu.Unlock(); v.mu.Unlock() }

// Root returns owned root bytes after checking both view and store lifetime.
// The image has exact capacity within MaxImageBytes; root metadata is fixed-size.
func (v *ApplicationView) Root() (ApplicationRoot, error) {
	if err := v.lock(context.Background()); err != nil {
		return ApplicationRoot{}, err
	}
	defer v.unlock()
	return ApplicationRoot{Generation: v.generation, Index: v.index, Image: copyApplicationBytes(v.image), ImageHash: sha256.Sum256(v.image)}, nil
}

// Close releases root accounting and is safe to repeat, including after Store.Close.
func (v *ApplicationView) Close() error {
	if v == nil || v.s == nil || v.self != v {
		return ErrInvalid
	}
	v.mu.Lock()
	defer v.mu.Unlock()
	if v.closed {
		return nil
	}
	v.s.mu.Lock()
	defer v.s.mu.Unlock()
	if !v.s.ownsApplicationView(v) {
		return ErrInvalid
	}
	v.s.unregisterApplicationView(v)
	v.closed = true
	v.s.views--
	v.s.viewBytes -= len(v.image)
	v.image = nil
	if v.prepared != nil {
		v.prepared.readers--
	}
	v.s.pinnedApplicationBytes -= v.reservation
	v.reservation = 0
	ref := v.ref
	v.ref = nil
	return v.s.releaseGeneration(ref)
}
func (v *ApplicationView) iterator(lower, upper []byte) (*pebble.Iterator, error) {
	return v.s.db.NewIter(&pebble.IterOptions{LowerBound: lower, UpperBound: upper})
}

// Get returns exact old/current content, including an explicit tombstone.
// found=false means never written at this root; Deleted distinguishes retraction.
// maxBytes bounds key/value payload length; exact-cap copies and the policy
// headroom additionally bound the complete owned KV output.
func (v *ApplicationView) Get(ctx context.Context, key []byte, maxBytes int) (out KV, found bool, err error) {
	if err = v.lock(ctx); err != nil {
		return KV{}, false, err
	}
	defer v.unlock()
	p := v.s.meta.App.Policy
	if len(key) == 0 || maxBytes < 0 {
		return KV{}, false, ErrInvalid
	}
	if len(key) > p.MaxKeyBytes || maxBytes > p.MaxPageBytes {
		return KV{}, false, ErrLimit
	}
	prefix := bankPrefix(v.bank, key)
	it, err := v.iterator(prefix, appNextPrefix(prefix))
	if err != nil {
		return KV{}, false, v.fail(err)
	}
	defer func() {
		err = errors.Join(err, it.Close())
		if err != nil && !errors.Is(err, ErrLimit) {
			v.s.poison = err
		}
	}()
	if !it.SeekGE(bankVersionKey(v.bank, key, v.index)) {
		return KV{}, false, it.Error()
	}
	physical := it.Key()
	actual, index, e := decodeBankAppKey(v.bank, physical, p.MaxKeyBytes)
	if e != nil || !bytes.Equal(actual, key) || index > v.index {
		return KV{}, false, v.fail(errors.Join(ErrCorrupt, e))
	}
	raw, readErr := it.ValueAndErr()
	if readErr != nil {
		return KV{}, false, v.fail(storedReadFailure(readErr))
	}
	value, deleted, e := inspectAppFrame(physical, raw, p.MaxValueBytes)
	if e != nil {
		return KV{}, false, v.fail(e)
	}
	if len(key)+len(value) > maxBytes {
		return KV{}, false, ErrLimit
	}
	return KV{copyApplicationBytes(key), copyApplicationBytes(value), deleted}, true, nil
}
func (v *ApplicationView) fail(err error) error {
	if err != nil {
		v.s.poison = err
	}
	return err
}

// ReadLimits returns immutable configured per-call row/byte maxima, not remaining
// quota, view validity or a retention lease. Nil returns zero. A closed view may
// still report its configuration; the store's application policy never changes.
func (v *ApplicationView) ReadLimits() ReadBudget {
	if v == nil {
		return ReadBudget{}
	}
	p := v.s.ApplicationLimits()
	return ReadBudget{Rows: p.MaxPageRows, Bytes: p.MaxPageBytes}
}

// Scan enumerates logical keys in byte order, seeking over version runs without
// decoding history or building a resident key map. Tombstones are omitted but
// budgeted. nil upper is unbounded; nil lower starts the namespace. after must
// be empty or a key in this exact range. Owned bytes include keys/Next and a
// conservative 64-byte header for each retained row-capacity slot; one bounded
// lookahead is borrowed internally.
func (v *ApplicationView) Scan(ctx context.Context, lower, upper, after []byte, b ReadBudget) (page ApplicationPage, err error) {
	if err = v.lock(ctx); err != nil {
		return page, err
	}
	defer v.unlock()
	p := v.s.meta.App.Policy
	if b.Rows < 1 || b.Bytes < 1 || len(upper) > 0 && bytes.Compare(lower, upper) >= 0 || len(after) > 0 && (bytes.Compare(after, lower) < 0 || len(upper) > 0 && bytes.Compare(after, upper) >= 0) {
		return page, ErrInvalid
	}
	if b.Rows > p.MaxPageRows || b.Bytes > p.MaxPageBytes || len(lower) > p.MaxKeyBytes || len(upper) > p.MaxKeyBytes || len(after) > p.MaxKeyBytes {
		return page, ErrLimit
	}
	lo := []byte{bankTag(v.bank, appDataTag)}
	if len(lower) > 0 {
		lo = bankPrefix(v.bank, lower)
	}
	hi := []byte{bankTag(v.bank, appDataTag) + 1}
	if len(upper) > 0 {
		hi = bankPrefix(v.bank, upper)
	}
	it, err := v.iterator(lo, hi)
	if err != nil {
		return page, v.fail(err)
	}
	defer func() {
		e := it.Close()
		err = errors.Join(err, e)
		if e != nil {
			v.s.poison = e
		}
	}()
	seek := lo
	if len(after) > 0 {
		seek = appNextPrefix(bankPrefix(v.bank, after))
	}
	// Work includes every visited key. Owned output additionally reserves the
	// complete Rows backing array, including capacity beyond its length.
	workBytes, outputBytes := 0, 0
	for valid := it.SeekGE(seek); valid; {
		if e := ctx.Err(); e != nil {
			return ApplicationPage{}, e
		}
		key, index, e := decodeBankAppKey(v.bank, it.Key(), p.MaxKeyBytes)
		if e != nil {
			return ApplicationPage{}, v.fail(e)
		}
		prefix := bankPrefix(v.bank, key)
		visible := true
		if index > v.index {
			visible = it.SeekGE(bankVersionKey(v.bank, key, v.index)) && bytes.HasPrefix(it.Key(), prefix)
			if e := it.Error(); e != nil {
				return ApplicationPage{}, v.fail(e)
			}
		}
		var value []byte
		deleted := false
		if visible {
			actual, version, e := decodeBankAppKey(v.bank, it.Key(), p.MaxKeyBytes)
			if e != nil || !bytes.Equal(actual, key) || version > v.index {
				return ApplicationPage{}, v.fail(errors.Join(ErrCorrupt, e))
			}
			raw, readErr := it.ValueAndErr()
			if readErr != nil {
				return ApplicationPage{}, v.fail(storedReadFailure(readErr))
			}
			value, deleted, e = inspectAppFrame(it.Key(), raw, p.MaxValueBytes)
			if e != nil {
				return ApplicationPage{}, v.fail(e)
			}
		}
		// Every discovered logical key consumes work, even if it was created
		// after this view. Otherwise an old empty root could scan an unbounded
		// later database in a single Rows=1 call.
		cost := len(key) + len(value) + 64
		emit := visible && !deleted
		rowBytes, capacity := 0, cap(page.Rows)
		if emit {
			rowBytes = len(key) + len(value)
			if len(page.Rows) == capacity {
				// Grow geometrically where room permits, but never retain an
				// uncharged backing array. Header accounting is conservative
				// on supported Go architectures; byte copies have exact cap.
				available := b.Bytes - (outputBytes - 64*capacity) - rowBytes - len(key)
				capacity = min(max(1, 2*capacity), available/64, b.Rows)
			}
		}
		owned := outputBytes + 64*(capacity-cap(page.Rows)) + rowBytes + len(key)
		if page.Visited >= b.Rows || cost+len(key) > b.Bytes-workBytes || emit && capacity < len(page.Rows)+1 || owned > b.Bytes {
			if page.Visited == 0 {
				return ApplicationPage{}, ErrLimit
			}
			page.Bytes = max(workBytes+len(page.Next), outputBytes+len(page.Next))
			return page, nil
		}
		page.Visited++
		workBytes += cost
		page.Next = copyApplicationBytes(key)
		if emit {
			if capacity > cap(page.Rows) {
				rows := make([]KV, len(page.Rows), capacity)
				copy(rows, page.Rows)
				outputBytes += 64 * (capacity - cap(page.Rows))
				page.Rows = rows
			}
			page.Rows = append(page.Rows, KV{Key: copyApplicationBytes(key), Value: copyApplicationBytes(value)})
			outputBytes += rowBytes
		}
		valid = it.SeekGE(appNextPrefix(prefix))
	}
	if e := it.Error(); e != nil {
		return ApplicationPage{}, v.fail(e)
	}
	page.Complete = true
	page.Next = nil
	page.Bytes = max(workBytes, outputBytes)
	return page, nil
}

// copyApplicationBytes owns only the requested length; unlike append/Clone,
// it exposes no spare byte capacity in returned application output.
func copyApplicationBytes(src []byte) []byte {
	if src == nil {
		return nil
	}
	dst := make([]byte, len(src))
	copy(dst, src)
	return dst
}

// ApplicationRecord retrieves a retained complete change/outcome envelope at a
// local applied entry. Neither its index nor a root is a public database cut.
func (s *Store) ApplicationRecord(ctx context.Context, index uint64, outcome bool, maxBytes int) ([]byte, error) {
	if s == nil || ctx == nil {
		return nil, ErrInvalid
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.check(); err != nil {
		return nil, err
	}
	p := s.meta.App.Policy
	if !p.Enabled() || index == 0 || index > s.meta.Applied || maxBytes < 0 {
		return nil, ErrInvalid
	}
	limit := p.MaxChangeBytes
	tag := appChangeTag
	if outcome {
		limit = p.MaxOutcomeBytes
		tag = appOutcomeTag
	}
	if maxBytes > p.MaxPageBytes {
		return nil, ErrLimit
	}
	key := bankIndexKey(s.activeBank(), tag, index)
	raw, closer, err := s.db.Get(key)
	if errors.Is(err, pebble.ErrNotFound) {
		s.poison = ErrCorrupt
		return nil, ErrCorrupt
	}
	if err != nil {
		s.poison = err
		return nil, err
	}
	data, deleted, inspectErr := inspectAppFrame(key, raw, limit)
	var out []byte
	if inspectErr == nil && !deleted && len(data) <= maxBytes {
		out = copyApplicationBytes(data)
	}
	if deleted {
		inspectErr = ErrCorrupt
	}
	if err := errors.Join(inspectErr, closer.Close()); err != nil {
		s.poison = err
		return nil, err
	}
	if len(data) > maxBytes {
		return nil, ErrLimit
	}
	return out, nil
}

// ApplicationUsage reports independent logical and bounded live-root ledgers.
// CheckpointBytes/SnapshotBytes are the fixed-bounded consensus image copies;
// RetainedBytes covers all immutable application namespaces. Do not interpret
// their sum as physical disk, heap or OS-cache consumption.
type ApplicationUsage struct {
	RecoveryBytes, RecoveryRecords                         uint64
	RetainedBytes, RetainedRecords, TailBytes, TailEntries uint64
	CheckpointBytes, SnapshotBytes                         uint64
	Views, ViewBytes                                       int
	GraphBytes, GraphRecords, ControlBytes, ControlRecords uint64
}

// ApplicationUsage returns a serialized accounting snapshot.
func (s *Store) ApplicationUsage() (ApplicationUsage, error) {
	if s == nil {
		return ApplicationUsage{}, ErrInvalid
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.check(); err != nil {
		return ApplicationUsage{}, err
	}
	if !s.meta.App.Policy.Enabled() {
		return ApplicationUsage{}, ErrInvalid
	}
	m := s.meta
	totalBytes, totalRecords := applicationTotals(m)
	return ApplicationUsage{RetainedBytes: totalBytes, RetainedRecords: totalRecords, TailBytes: m.App.TailBytes, TailEntries: m.Last - m.Applied, CheckpointBytes: m.ImageBytes, SnapshotBytes: m.SnapBytes, Views: s.views, ViewBytes: s.viewBytes, GraphBytes: m.App.Bytes, GraphRecords: m.App.Records, ControlBytes: m.Controls.Bytes, ControlRecords: m.Controls.Records, RecoveryBytes: m.Recovery.Bytes, RecoveryRecords: m.Recovery.Records}, nil
}

// admitScrubControlKey owns the next canonical control key only after stored
// shape and index validation. Previous is the last admitted canonical key.
func admitScrubControlKey(bank byte, key, previous []byte, maxKeyBytes int, applied uint64) ([]byte, error) {
	_, index, err := decodeControlKey(bank, key, maxKeyBytes)
	if err != nil || index > applied {
		return nil, ErrCorrupt
	}
	canonical := canonicalApplicationKey(bank, key)
	if sameControlLogical(previous, canonical, maxKeyBytes) {
		return nil, ErrCorrupt
	}
	return canonical, nil
}

// ScrubApplication verifies every immutable version/root/change/outcome in
// constant resident scan space, recomputes retained ledgers and checks complete
// per-index envelope runs. It never materializes a database key map. Cancellation
// is checked between bounded frames; corruption/read errors poison the store.
func (s *Store) ScrubApplication(ctx context.Context) (err error) {
	if s == nil || ctx == nil {
		return ErrInvalid
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.check(); err != nil {
		return err
	}
	p := s.meta.App.Policy
	if !p.Enabled() {
		return ErrInvalid
	}
	it, err := newApplicationIterator(s.db.NewIter, s.activeBank(), s.meta.Controls.Config.enabled(), s.meta.Recovery.Config.enabled())
	if err != nil {
		s.poison = err
		return err
	}
	defer func() {
		closeErr := it.Close()
		err = errors.Join(err, closeErr)
		if err != nil && !errors.Is(err, context.Canceled) && !errors.Is(err, context.DeadlineExceeded) {
			s.poison = err
		}
	}()
	var total, records, controlBytes, controlRecords, recoveryBytes, recoveryRecords, recoveryThrough uint64
	var previousControl []byte
	var envelopes [3]uint64
	for valid := it.First(); valid; valid = it.Next() {
		if err := ctx.Err(); err != nil {
			return err
		}
		key := it.Key()
		raw, readErr := it.ValueAndErr()
		if readErr != nil {
			return storedReadFailure(readErr)
		}
		cost := uint64(len(key)) + uint64(len(raw))
		aggregateBytes, aggregateRecords := total+controlBytes+recoveryBytes, records+controlRecords+recoveryRecords
		if aggregateBytes > p.RetainedApplicationBytes || cost > p.RetainedApplicationBytes-aggregateBytes || aggregateRecords >= p.RetainedApplicationRecords {
			return ErrCorrupt
		}
		limit := p.MaxValueBytes
		isControl := key[0] == controlBankTag(s.activeBank())
		isRecovery := key[0] == recoveryRootTag+s.activeBank()
		if isRecovery {
			if len(key) != 9 {
				return ErrCorrupt
			}
			index := binary.BigEndian.Uint64(key[1:])
			if index != recoveryThrough+1 || index > s.meta.Applied {
				return ErrCorrupt
			}
			recoveryThrough = index
			limit = min(p.MaxValueBytes, maxMetadataBytes)
		} else if isControl {
			canonical, err := admitScrubControlKey(s.activeBank(), key, previousControl, p.MaxKeyBytes, s.meta.Applied)
			if err != nil {
				return err
			}
			previousControl = canonical
		} else if key[0] == bankTag(s.activeBank(), appDataTag) {
			_, index, err := decodeBankAppKey(s.activeBank(), key, p.MaxKeyBytes)
			if err != nil || index > s.meta.Applied {
				return errors.Join(ErrCorrupt, err)
			}
		} else {
			if len(key) != 9 {
				return ErrCorrupt
			}
			slot := int(key[0] - bankTag(s.activeBank(), appRootTag))
			index := binary.BigEndian.Uint64(key[1:])
			if index != envelopes[slot]+1 || index > s.meta.Applied {
				return ErrCorrupt
			}
			envelopes[slot] = index
			switch key[0] - s.activeBank()*4 {
			case appRootTag:
				limit = p.MaxImageBytes
			case appChangeTag:
				limit = p.MaxChangeBytes
			case appOutcomeTag:
				limit = p.MaxOutcomeBytes
			}
		}
		data, deleted, err := inspectAppFrame(key, raw, limit)
		if err != nil || deleted && key[0] != bankTag(s.activeBank(), appDataTag) {
			return errors.Join(ErrCorrupt, err)
		}
		if isRecovery {
			owner, count, err := inspectRecoveryOwner(data, p, s.limits)
			if err != nil {
				return err
			}
			if recoveryThrough == s.meta.Applied && (owner != (ApplicationRecoveryOwner{ID: s.meta.Recovery.Reservation.ID, Digest: s.meta.Recovery.Reservation.Digest}) || count != len(s.meta.Recovery.Reservation.Credits) || sha256.Sum256(data) != recoveryRootDigest(s.meta.Recovery.Reservation)) {
				return ErrCorrupt
			}
			recoveryBytes += cost
			recoveryRecords++
		} else if isControl {
			controlBytes += cost
			controlRecords++
		} else {
			total += cost
			records++
		}
	}
	if err := it.Error(); err != nil {
		return err
	}
	if total != s.meta.App.Bytes || records != s.meta.App.Records || controlBytes != s.meta.Controls.Bytes || controlRecords != s.meta.Controls.Records || recoveryBytes != s.meta.Recovery.Bytes || recoveryRecords != s.meta.Recovery.Records || s.meta.Recovery.Config.enabled() && recoveryThrough != s.meta.Applied {
		return ErrCorrupt
	}
	for _, index := range envelopes {
		if index != s.meta.Applied {
			return ErrCorrupt
		}
	}
	return nil
}
