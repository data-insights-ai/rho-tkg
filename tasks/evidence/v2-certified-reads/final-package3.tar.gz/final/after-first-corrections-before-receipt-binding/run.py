from pathlib import Path
import subprocess,os,json,hashlib,re,time
root=Path('/var/tmp/rho-v5-v2-certified-reads-20261011')
out=Path('/var/tmp/rho-v5-v2-certified-final-20261011')
limit='/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py'
env=dict(os.environ,GOTOOLCHAIN='go1.26.9',GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off')
paths=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=root,text=True).splitlines()))
paths=[p for p in paths if p.startswith('v5/') and (p.endswith('.go') or p in ['v5/go.mod','v5/go.sum','v5/Makefile']) or p in ['.golangci.yml','Makefile']]
source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
(out/'source.json').write_text(json.dumps({'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':source},indent=2)+'\n')
names=sorted(line for line in (out/'inventory.log').read_text().splitlines() if re.fullmatch(r'(Test|Fuzz|Example)[A-Za-z0-9_]*',line))
lanes={}
lanes['certified']=[x for x in names if x.startswith('TestCertified')]
lanes['registry']=[x for x in names if x.startswith(('TestRegistered','TestRegistry'))]
lanes['cross']=[x for x in names if x.startswith('TestCrossPartition')]
used=set(sum(lanes.values(),[]));remaining=[x for x in names if x not in used];middle=(len(remaining)+1)//2
lanes['remaining-a']=remaining[:middle];lanes['remaining-b']=remaining[middle:]
assert len(sum(lanes.values(),[]))==len(names)==len(set(names));assert all(lanes.values())
(out/'lanes.json').write_text(json.dumps({'discovered':names,'lanes':lanes,'exhaustive':True,'disjoint':True},indent=2)+'\n')
print(json.dumps({'source_manifest':str(out/'source.json'),'source_manifest_sha256':hashlib.sha256((out/'source.json').read_bytes()).hexdigest(),'counts':{k:len(v) for k,v in lanes.items()}},indent=2),flush=True)

def same_source():
 for p,h in source.items():
  if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h:raise RuntimeError('source drift '+p)

def run(name,argv,cwd=root/'v5'):
 same_source();(out/f'{name}-command.json').write_text(json.dumps({'argv':argv,'cwd':str(cwd),'environment':{k:env[k] for k in ['GOTOOLCHAIN','GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GOWORK']}},indent=2)+'\n')
 cmd=['python3',limit,'--rss-mib','4096','--seconds','180','--report',str(out/f'{name}-limit.json'),'--']+argv
 with (out/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 same_source();print(name,r.returncode,flush=True)
 records.append({'name':name,'exit_code':r.returncode});(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise RuntimeError('gate failed '+name)
records=[]
old=out/'reviewed-freeze-before-corrections'
old_lanes=json.loads((old/'lanes.json').read_text())['lanes']
for name in ['registry','cross']:
 assert lanes[name]==old_lanes[name]
 for gate in ['normal-'+name,'race-'+name]:
  r=json.loads((old/(gate+'-limit.json')).read_text());assert r['exit_code']==0 and r['reason']=='completed'
  records.append({'name':gate,'exit_code':0,'carried_from':str(old),'qualification':'same exhaustive test inventory; both corrected private paths only enter certified modes/participant queries; existing package2 and registry flows unchanged; changed-file coverage entries excluded from carry'})
run('fmt',['make','fmt-check'])
run('vet',['go','vet','./...'])
run('build',['go','build','./...'])
docker='docker run --rm --memory=4g --memory-swap=4g --cpus=2 -e GOTOOLCHAIN=local -e GOMAXPROCS=2 -e GOFLAGS=-p=1 -e GOMEMLIMIT=2GiB -e GOWORK=off -v '+str(root)+':/src -w /src/v5 -v rho-tkg-gocache:/go -v rho-tkg-buildcache:/root/.cache/go-build golang:1.26.9'
for name,target in [('lint','lint-docker'),('security','security-docker'),('vulncheck','vulncheck-docker')]:run(name,['make',target,'DOCKER_GO='+docker])
for name,ns in lanes.items():
 if name in ['registry','cross']: continue
 pattern='^('+'|'.join(ns)+')$'
 run('normal-'+name,['go','test','-short','-count=1','-run',pattern,'-covermode=atomic','-coverpkg=./internal/graphapply,./internal/graphstore,./internal/raftlog','-coverprofile='+str(out/f'normal-{name}.out'),'./internal/graphapply'])
 run('race-'+name,['go','test','-short','-race','-count=1','-run',pattern,'./internal/graphapply'])
run('normal-graphstore',['go','test','-short','-count=1','-covermode=atomic','-coverpkg=./internal/graphstore,./internal/raftlog','-coverprofile='+str(out/'normal-graphstore.out'),'./internal/graphstore'])
run('race-graphstore',['go','test','-short','-race','-count=1','./internal/graphstore'])
print('ALL GATES PASS',flush=True)
