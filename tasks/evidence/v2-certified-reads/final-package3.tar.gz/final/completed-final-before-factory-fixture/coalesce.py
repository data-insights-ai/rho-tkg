from pathlib import Path
from collections import defaultdict
import json,hashlib,tarfile,re,subprocess
root=Path('/var/tmp/rho-v5-v2-certified-reads-20261011');out=Path('/var/tmp/rho-v5-v2-certified-final-20261011')
module='github.com/data-insights-ai/rho-tkg/v5/'
current=json.loads((out/'source.json').read_text())['files']
for p,h in current.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
previous=json.loads((out/'previous-source.json').read_text());previous={x['path']:x['sha256'] for x in previous['files']}
old=json.loads((out/'reviewed-freeze-before-corrections/source.json').read_text())['files']
profiles=[]
with tarfile.open(root/'tasks/evidence/v2-cross-partition/combined-final.tar.gz') as a:
 data=a.extractfile('combined/coverage.out').read().decode();(out/'previous-coverage.out').write_text(data)
profiles.append(('previous-accepted-module',out/'previous-coverage.out',previous))
for lane in ['registry','cross']:
 profiles.append(('carried-'+lane,out/'reviewed-freeze-before-corrections'/('normal-'+lane+'.out'),old))
for lane in ['certified','remaining-a','remaining-b','graphstore']:
 profiles.append(('current-'+lane,out/('normal-'+lane+'.out'),current))
blocks={};file_blocks=defaultdict(set);accepted=[];excluded={}
for name,p,source in profiles:
 hit=skip=0
 for line in p.read_text().splitlines()[1:]:
  loc,n,k=line.split();f=loc.split(':')[0];assert f.startswith(module),f;rel='v5/'+f[len(module):]
  if source.get(rel)!=current.get(rel) or rel not in current:skip+=1;continue
  n,k=int(n),int(k)
  if loc in blocks:assert blocks[loc][0]==n,(name,loc,blocks[loc][0],n)
  blocks[loc]=(n,bool(k) or blocks.get(loc,(n,False))[1]);file_blocks[rel].add(loc);hit+=1
 accepted.append({'name':name,'profile':str(p),'accepted_blocks':hit,'excluded_changed_source_blocks':skip})
(out/'coverage.out').write_text('mode: set\n'+''.join(f'{loc} {n} {int(k)}\n' for loc,(n,k) in sorted(blocks.items())))
# Every current production file must appear. Instrumentation excludes empty files
# without statements, but no statement-bearing file can quietly fall out.
files={}
for f,locs in sorted(file_blocks.items()):
 total=sum(blocks[x][0] for x in locs);hit=sum(blocks[x][0] for x in locs if blocks[x][1]);files[f]={'covered':hit,'statements':total,'percent':100*hit/total}
new_prod=sorted(p for p in current if p.endswith('.go') and not p.endswith('_test.go') and p not in previous)
changed=sorted(p for p in current if p.endswith('.go') and not p.endswith('_test.go') and previous.get(p)!=current[p])
new_bad=[p for p in new_prod if p not in files or files[p]['percent']<80]
changed_bad=[p for p in changed if p not in files or files[p]['percent']<80]
(out/'coverage-files.json').write_text(json.dumps(files,indent=2)+'\n')
summary={'profiles':accepted,'covered_statements':sum(n for n,k in blocks.values() if k),'total_statements':sum(n for n,k in blocks.values()),'percent':100*sum(n for n,k in blocks.values() if k)/sum(n for n,k in blocks.values()),'new_production_files':new_prod,'new_below80':new_bad,'changed_production_files':changed,'changed_below80':changed_bad,'qualification':'All contributing file/block statement counts agree. Carried counts admitted only for exact matching current file hashes; changed-file entries discarded. Legacy registry/cross runtime carry separately qualified in results.json.'}
(out/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['profiles','changed_production_files','new_production_files']},indent=2))
# Direct call witnesses are recorded separately from the coverage percentages.
new_exports=[]
for p in sorted(set(changed+new_prod)):
 source=(root/p).read_text()
 previous_text=''
 try:previous_text=subprocess.check_output(['git','show','40104a61:'+p],cwd=root,text=True,stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError:pass
 for m in re.finditer(r'^func\s+(?:\(([^)]*)\)\s+)?([A-Z][A-Za-z0-9_]*)\s*\(',source,re.M):
  receiver,name=m.groups();identity=(receiver or '').split('*')[-1].split()[-1] if receiver else ''
  if re.search(r'^func\s+(?:\([^)]*\)\s+)?'+re.escape(name)+r'\s*\(',previous_text,re.M):continue
  witnesses=[]
  for test in (root/'v5').rglob('*_test.go'):
   for i,line in enumerate(test.read_text().splitlines(),1):
    if re.search(r'\.'+re.escape(name)+r'\s*\(',line) or re.search(r'\b'+re.escape(name)+r'\s*\(',line):witnesses.append({'file':str(test.relative_to(root)),'line':i,'call':line.strip()})
  new_exports.append({'file':p,'receiver':identity,'method':name,'direct_call_witnesses':witnesses})
(out/'direct-exports.json').write_text(json.dumps(new_exports,indent=2)+'\n')
assert not new_bad,new_bad
assert not changed_bad,changed_bad
assert all(x['direct_call_witnesses'] for x in new_exports),new_exports
