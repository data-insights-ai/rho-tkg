import os,sys,json,hashlib,subprocess
from pathlib import Path
root=Path('/var/tmp/rho-v5-v2-preclaim-20261011');out=Path(__file__).parent
native='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go'
env=os.environ.copy();env.update(GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOCACHE='/var/tmp/rho-v5-go-build-cache-go1.26.9',PATH=str(Path(native).parent)+':'+env['PATH'])
manifest=out/'source.json'
if not manifest.exists():
 paths=sorted((root/'v5').rglob('*.go'))+[root/'v5/go.mod',root/'v5/go.sum',root/'v5/Makefile',root/'CHANGELOG.md',root/'.golangci.yml']
 manifest.write_text(json.dumps({str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in paths},indent=2)+'\n')
source=json.loads(manifest.read_text())
def verify():
 for name,digest in source.items():
  if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('changed source '+name)
verify();label=sys.argv[1]
cmd=[sys.argv[2] if sys.argv[2]!='go' else native]+sys.argv[3:]
watch=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096','--seconds','180','--report',str(out/(label+'-budget.json')),'--']+cmd
with (out/(label+'.log')).open('wb') as log:r=subprocess.run(watch,env=env,cwd=root/'v5',stdout=log,stderr=subprocess.STDOUT)
verify();print(label,'exit',r.returncode,flush=True)
print((out/(label+'.log')).read_text()[-3000:],flush=True)
sys.exit(r.returncode)
