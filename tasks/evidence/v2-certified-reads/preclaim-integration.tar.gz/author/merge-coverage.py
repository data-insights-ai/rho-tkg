from pathlib import Path
import json,hashlib
out=Path(__file__).parent;prior=Path('/var/tmp/rho-v5-v2-certified-final-20261011')
current=json.loads((out/'source.json').read_text()); old=json.loads((prior/'source.json').read_text())['files']; prefix='github.com/data-insights-ai/rho-tkg/v5/'
assert hashlib.sha256((prior/'source.json').read_bytes()).hexdigest()=='7c7c358dab99ddada4f20c98bcf30615396b4ea0615776a500749f10b4b11c16'
blocks={};accepted=excluded=fresh=0
for label,profile in [('accepted-P3',prior/'coverage.out'),('fresh-raftlog',out/'raftlog-coverage.out')]:
 lines=profile.read_text().splitlines();assert lines[0]=='mode: set'
 for line in lines[1:]:
  span,statements,count=line.split();file=span.split(':')[0];path='v5/'+file.removeprefix(prefix)
  assert file.startswith(prefix)
  if label=='accepted-P3' and current.get(path)!=old.get(path):excluded+=1;continue
  if label=='accepted-P3':accepted+=1
  else:fresh+=1
  n=int(statements);hit=int(count)>0
  if span in blocks:
   old_n,old_hit=blocks[span];assert n==old_n,(span,n,old_n);hit=hit or old_hit
  blocks[span]=(n,hit)
lines=['mode: set']+[f'{span} {n} {int(hit)}' for span,(n,hit) in sorted(blocks.items())]
(out/'coverage.out').write_text('\n'.join(lines)+'\n')
perfile={}
for span,(n,hit) in blocks.items():
 file=span.split(':')[0];path='v5/'+file.removeprefix(prefix);total,covered=perfile.get(path,(0,0));perfile[path]=(total+n,covered+(n if hit else 0))
total=sum(x[0] for x in perfile.values());covered=sum(x[1] for x in perfile.values())
new='v5/internal/raftlog/application_snapshot_prepared.go';file_total,file_hit=perfile[new]
summary={'prior_manifest_sha256':hashlib.sha256((prior/'source.json').read_bytes()).hexdigest(),'accepted_P3_blocks':accepted,'discarded_changed_file_blocks':excluded,'fresh_raftlog_blocks':fresh,'covered_statements':covered,'total_statements':total,'percent':100*covered/total,'changed_file':{'path':new,'covered':file_hit,'total':file_total,'percent':100*file_hit/file_total},'qualification':'Current raftlog runtime coverage is fresh. Other module coverage carries only exact unchanged production-file hashes from accepted P3; changed prepared.go carry discarded. Every overlapping block statement count agrees. This is qualified merged coverage, not a new full-module runtime run.'}
(out/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
assert summary['percent']>=80 and summary['changed_file']['percent']>=80
