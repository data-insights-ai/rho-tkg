#!/usr/bin/env python3
"""Fake-Go dispatcher guards; these do not claim Go compilation or race execution."""
from pathlib import Path
import json
import os
import re
import subprocess
import sys
import tempfile

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(__file__).parent
BASELINE = OUT / 'baseline-test-race.sh'
FLAGS = ['-short', '-race', '-count=1']
RESOURCES = {'GOFLAGS': '-p=1', 'GOMEMLIMIT': '2GiB', 'GOMAXPROCS': '2',
             'GOWORK': 'off', 'GOTOOLCHAIN': 'local'}
STUB = r'''#!/usr/bin/env python3
from pathlib import Path
import json, os, sys
cfg = json.loads(Path(os.environ['FAKE_CONFIG']).read_text())
args = sys.argv[1:]
p = Path(os.environ['FAKE_CALLS'])
with p.open('a') as f:
 f.write(json.dumps({'args': args, 'resources': {k: os.environ.get(k) for k in cfg['resources']}}) + '\n')
if args[0] == 'list':
 if args[-1] != './...':
  if cfg.get('fail_selected'): sys.exit(21)
  print(cfg['selected'])
 else:
  if cfg.get('fail_packages'): sys.exit(22)
  print('\n'.join(cfg['packages']))
elif '-list' in args:
 if cfg.get('fail_inventory'): sys.exit(23)
 print('\n'.join(cfg['names']))
 if cfg.get('unexpected'): print(cfg['unexpected'])
 for footer in cfg['footers']: print(footer)
elif '-run' in args:
 if cfg.get('fail_shard') == sum('"-run"' in line for line in p.read_text().splitlines()): sys.exit(24)
else:
 if cfg.get('fail_other'): sys.exit(25)
'''
NAMES = ['TestZulu', 'TestAlpha', 'FuzzSeeds', 'ExampleThing', 'TestReplicatedGraphChild',
         'TestMaterializerCrashChild', 'TestParentWithSubtests', 'TestUnicode_Ä',
         'FuzzFuture', 'ExampleFuture', 'TestLiteral[1]', 'TestLiteral+$', 'FuzzLiteral\\Name']
RESULTS = []

def run(profile='root', args=None, edit=None, script=None):
    selected = 'example.test/' + ('root/pkg/graph/internal/core' if profile == 'root' else 'v5/internal/graphapply')
    cfg = {'selected': selected, 'packages': ['example.test/other', selected, 'example.test/final'],
           'names': NAMES, 'footers': ['ok  ' + selected + ' 0.001s'], 'resources': RESOURCES}
    cfg.update(edit or {})
    with tempfile.TemporaryDirectory(prefix='race-dispatch-guard-') as tmp:
        tmp = Path(tmp)
        go = tmp / 'go'
        go.write_text(STUB)
        go.chmod(0o755)
        (tmp / 'config.json').write_text(json.dumps(cfg))
        calls_file = tmp / 'calls.jsonl'
        env = dict(os.environ, **RESOURCES, PATH=str(tmp) + ':' + os.environ['PATH'],
                   FAKE_CONFIG=str(tmp / 'config.json'), FAKE_CALLS=str(calls_file))
        command = ['/bin/bash', str(script or ROOT / 'scripts/test-race.sh')] + (args if args is not None else ['4', profile])
        result = subprocess.run(command, cwd=ROOT if profile == 'root' else ROOT / 'v5',
                                env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10)
        calls = [json.loads(line) for line in calls_file.read_text().splitlines()] if calls_file.exists() else []
        assert all(c['resources'] == RESOURCES for c in calls), calls
        return result, calls, cfg

def evidence(name, result, calls):
    (OUT / (name + '.log')).write_text(result.stdout + '\nCALLS\n' + json.dumps(calls, indent=2) + '\n')
    RESULTS.append({'name': name, 'passed': True, 'exit_code': result.returncode, 'calls': len(calls)})

def complete(name, profile='root', edit=None):
    r, calls, cfg = run(profile, edit=edit)
    assert r.returncode == 0, r.stdout
    selected = cfg['selected']
    path = './pkg/graph/internal/core' if profile == 'root' else './internal/graphapply'
    assert calls[0]['args'] == ['list', '-race', path]
    assert calls[1]['args'] == ['list', '-race', './...']
    assert calls[2]['args'] == ['test'] + FLAGS + ['-list', '^(Test|Fuzz|Example)', selected]
    runtime = calls[3:]
    others = [p for p in cfg['packages'] if p != selected]
    if others:
        assert runtime.pop(0)['args'] == ['test'] + FLAGS + others
    assert len(runtime) == 4
    assigned = []
    sorted_names = sorted(cfg['names'])
    for i, c in enumerate(runtime):
        a = c['args']
        assert a[:5] == ['test'] + FLAGS + ['-run'] and a[-1] == selected, a
        pattern = a[5]
        assert pattern.startswith('^(') and pattern.endswith(')$')
        chosen = [n for n in sorted_names if re.fullmatch(pattern, n)]
        assert chosen == sorted_names[i::4] and chosen
        assigned += chosen
        assert not re.match(pattern, 'TestPhantomName')
        # Go matches the first -run component to the parent, then runs all its subtests.
        assert '/' not in pattern
    assert sorted(assigned) == sorted_names and len(set(assigned)) == len(assigned)
    assert 'all ' + profile + ' packages and ' in r.stdout
    evidence(name, r, calls)
    return r, calls

# The existing dispatcher rejects the required v5 profile rather than scheduling it.
r, calls, _ = run('v5', script=BASELINE)
assert r.returncode != 0 and calls == []
(OUT / 'baseline-red.log').write_text(r.stdout)
(OUT / 'baseline-red.json').write_text(json.dumps({'base': '9c3891da1afb34d882fde8616670f1524c7e766b',
    'v5_profile_supported': False, 'exit_code': r.returncode, 'calls': len(calls),
    'qualification': 'RED for missing v5 dispatch, with fake Go only; actual hosted aggregate race timeout is separately recorded by the root.'}, indent=2) + '\n')

for profile in ['root', 'v5']:
    complete(profile + '-complete', profile)
    complete(profile + '-selected-only', profile, {'packages': ['example.test/' + ('root/pkg/graph/internal/core' if profile == 'root' else 'v5/internal/graphapply')]})
    complete(profile + '-new-future-names', profile, {'names': NAMES + ['TestNewTomorrow', 'FuzzNewTomorrow', 'ExampleNewTomorrow']})
    complete(profile + '-shuffled', profile, {'names': list(reversed(NAMES))})
    for args in ([[], ['1'], ['1', 'root']] if profile == 'root' else [['1', 'v5']]):
        r, calls, _ = run(profile, args=args)
        assert r.returncode == 0 and [c['args'] for c in calls] == [['test'] + FLAGS + ['./...']]
        evidence(profile + '-unsplit-' + str(len(args)), r, calls)

# Exact root compatibility against the previous dispatcher, for successful commands.
for args in [[], ['1'], ['4']]:
    old, old_calls, _ = run(args=args, script=BASELINE)
    new, new_calls, _ = run(args=args)
    assert old.returncode == new.returncode == 0 and old_calls == new_calls and old.stdout == new.stdout
    evidence('root-exact-compatibility-' + str(args), new, new_calls)

for args in [['4', 'invalid'], ['1', 'invalid'], ['4', ''], ['1', ''], ['4', 'v5', 'extra'], ['', 'v5'], ['0', 'v5'], ['2', 'v5'], ['5', 'v5'], ['4x', 'v5']]:
    r, calls, _ = run('v5', args=args)
    assert r.returncode != 0 and not calls
    evidence('bad-args-' + str(len(RESULTS)), r, calls)

for profile in ['root', 'v5']:
    selected = 'example.test/' + ('root/pkg/graph/internal/core' if profile == 'root' else 'v5/internal/graphapply')
    for name, edit in [
        ('selected-list-failure', {'fail_selected': True}),
        ('package-list-failure', {'fail_packages': True}),
        ('empty-selected', {'selected': ''}),
        ('multiple-selected', {'selected': selected + '\nexample.test/foreign'}),
        ('empty-packages', {'packages': []}),
        ('blank-package', {'packages': [selected, '', 'example.test/other']}),
        ('missing-selected', {'packages': ['example.test/other']}),
        ('duplicate-selected', {'packages': [selected, selected]}),
        ('duplicate-other', {'packages': [selected, 'example.test/other', 'example.test/other']}),
        ('inventory-failure', {'fail_inventory': True}),
        ('empty-inventory', {'names': []}),
        ('too-small', {'names': ['TestA', 'FuzzA', 'ExampleA']}),
        ('duplicate-name', {'names': NAMES + [NAMES[0]]}),
        ('space-name', {'names': NAMES + ['TestInvalid Name']}),
        ('tab-name', {'names': NAMES + ['TestInvalid\tName']}),
        ('cr-name', {'names': NAMES + ['TestInvalid\rName']}),
        ('missing-footer', {'footers': []}),
        ('foreign-footer', {'footers': ['ok example.test/foreign 0.001s']}),
        ('double-footer', {'footers': ['ok ' + selected + ' 0.001s'] * 2}),
        ('short-footer', {'footers': ['ok ' + selected]}),
        ('unexpected-output', {'unexpected': 'unexpected stdout'})]:
        r, calls, _ = run(profile, edit=edit)
        assert r.returncode != 0 and not [c for c in calls if c['args'][0] == 'test' and '-list' not in c['args']], (name, r.stdout)
        assert 'shards passed' not in r.stdout
        if profile == 'root':
            old, old_calls, _ = run(profile, args=['4'], edit=edit, script=BASELINE)
            assert old.returncode == r.returncode and old.stdout == r.stdout and old_calls == calls
        evidence(profile + '-' + name, r, calls)
    for name, edit, runtime_count in [('other-failure', {'fail_other': True}, 1), ('shard-failure', {'fail_shard': 2}, 3)]:
        r, calls, _ = run(profile, edit=edit)
        assert r.returncode != 0 and 'shards passed' not in r.stdout
        assert len([c for c in calls if c['args'][0] == 'test' and '-list' not in c['args']]) == runtime_count
        evidence(profile + '-' + name, r, calls)
    r, calls, _ = run(profile, args=['1', profile], edit={'fail_other': True})
    assert r.returncode == 25 and len(calls) == 1
    evidence(profile + '-unsplit-failure', r, calls)

for name, args, cwd, expected in [
    ('make-root-default', ['make', '-n', 'test-race', 'V5_DISPATCH=0', 'COMPARE_DISPATCH=0'], ROOT, 'scripts/test-race.sh "1"'),
    ('make-root-four', ['make', '-n', 'test-race', 'V5_DISPATCH=0', 'COMPARE_DISPATCH=0', 'ROOT_RACE_CORE_SHARDS=4'], ROOT, 'scripts/test-race.sh "4"'),
    ('make-v5-default', ['make', '-n', 'test-race'], ROOT / 'v5', '../scripts/test-race.sh "1" v5'),
    ('make-v5-four', ['make', '-n', 'test-race', 'V5_RACE_GRAPHAPPLY_SHARDS=4'], ROOT / 'v5', '../scripts/test-race.sh "4" v5'),
    ('make-root-aggregate', ['make', '-n', 'test-race'], ROOT, '../scripts/test-race.sh "1" v5')]:
    r = subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10)
    assert r.returncode == 0 and expected in r.stdout, r.stdout
    if name == 'make-root-aggregate':
        assert '-C tools/graph-compare' in r.stdout and 'scripts/test-race.sh "1"' in r.stdout
    evidence(name, r, [])

old_ci = subprocess.check_output(['git', 'show', '9c3891da:.github/workflows/ci.yml'], cwd=ROOT, text=True)
new_ci = (ROOT / '.github/workflows/ci.yml').read_text()
old_v5 = "      - run: make test-race\n        if: matrix.module != '.'"
new_v5 = '''      # v5 graphapply has the same whole-parent batching contract as root core.
      - name: v5 race tests with exhaustive graphapply batches
        if: matrix.module == 'v5'
        env:
          V5_RACE_GRAPHAPPLY_SHARDS: "4"
        run: make test-race'''
assert new_ci == old_ci.replace(old_v5, new_v5)
assert '-test.run=^TestReplicatedGraphChild$' in (ROOT / 'v5/internal/graphapply/replicated_process_test.go').read_text()
assert (ROOT / 'v5/internal/graphapply/materializer_test.go').read_text().count('-test.run=^TestMaterializerCrashChild$') == 2
RESULTS.append({'name': 'ci-only-v5-step-and-explicit-child-selectors', 'passed': True})
if (OUT / 'compiled-inventory.log').exists():
    lines = (OUT / 'compiled-inventory.log').read_text().splitlines()
    names = [line for line in lines if line.startswith(('Test', 'Fuzz', 'Example'))]
    selected = 'github.com/data-insights-ai/rho-tkg/v5/internal/graphapply'
    footers = [line for line in lines if line.startswith('ok')]
    assert len(footers) == 1 and footers[0].split()[1] == selected
    packages = (OUT / 'compiled-packages.log').read_text().splitlines()
    assert len(names) >= 4 and len(set(names)) == len(names)
    complete('actual-census-fake-dispatch', 'v5', {'names': names, 'selected': selected,
             'packages': packages, 'footers': footers})
    groups = [sorted(names)[i::4] for i in range(4)]
    (OUT / 'compiled-census.json').write_text(json.dumps({
        'go_version': (OUT / 'go-1.26.9-version.log').read_text().strip(),
        'module_packages': len(packages), 'other_packages': len(packages) - 1,
        'compiled_names': len(names), 'Test': sum(n.startswith('Test') for n in names),
        'Fuzz': sum(n.startswith('Fuzz') for n in names), 'Example': sum(n.startswith('Example') for n in names),
        'groups': groups, 'group_sizes': [len(g) for g in groups],
        'exhaustive_disjoint': True,
        'qualification': 'Real race-aware Go compiled inventory; captured names fed to fake Go to verify actual dispatcher assignment. No race test bodies or full hosted gate run locally.'
    }, indent=2) + '\n')
(OUT / 'checks.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
print(json.dumps({'passed': len(RESULTS), 'qualification': 'Fake-Go/static guards with real compiled inventory; full hosted race gate pending.'}, indent=2))
