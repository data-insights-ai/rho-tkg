# Final independent acceptance — V2 package 3

**Recommendation: ACCEPT / mergeable within the finite package 3 scope.** No remaining blocking findings or concrete nonblocking defects. Same independent reviewer: Sol6.1, `/root/v2_cross_independent_review`, 2026-10-11. This closes this review, including the three author corrections; it does not accept full V2 or package 4.

Accepted tree: `/var/tmp/rho-v5-v2-certified-reads-20261011`, baseline `40104a61853d2de9628f39e0042be94ade494ba1`. Final 418-file manifest SHA256: `7c7c358dab99ddada4f20c98bcf30615396b4ea0615776a500749f10b4b11c16`. Independently checked every current file hash: zero mismatches.

## Semantic verdict

The reviewed internal source-owned transport over one GraphID, two declared partition groups and six disk voters supports certified Fresh/Stable/At/After reads of the exact graph round prefix. The separate read fence does not masquerade as the installed graph floor. Completion consults the decision coordinator even outside the selected data scope, observes applied quorum authority, and returns pending/unavailable rather than inferring absence from unavailable authority. Historical graph roots are selected at the certified round rather than substituted with the latest root. Retained cuts, source borrowing/cleanup, cancellation and cumulative cap intersection have meaningful direct/adversarial coverage, including correction, uniqueness and both relationship endpoint lifecycles, real follower applied barriers, AS5 and durable reopen.

All three source-review findings are cleared, with executable original REDs and correction GREENs preserved:

- Early durable ABORT with an absent participant: transaction/digest/ReadID-bound completed participant observations now permit skipping only proven absent or already-resolved ABORT participants. COMMIT still resolves every participant. Actual delayed Prepare tests cover arrival before certification (pending/no read) and after certification (old graph cut unchanged, next Fresh resolves immutable ABORT), and preserve another owner's native identity/digest and Driver health.
- Oversized scope admission: length refusal now precedes cloning/sorting; the tiny known-oversized AllocsPerRun guard passes with zero allocations.
- After receipt authority: genuine local and cross receipts are bound to the selected current declaration, exact scope and captured/canonical configuration. Eight genuine successful-wrong-result REDs across topology, group, owner epoch and configuration are corrected. Closed/reopened issuer proofs remain usable without reading the old Store/Driver; real follower At succeeds. No transfer lineage is inferred.

See `SOURCE-FINDINGS.md` and `CORRECTION-RECHECK.md` for the original findings and precise correction evidence. The final missing-certificate guard also directly proves that an applied offset and matching scope alone do not authorize At: a genuine certificate absent from the current durable authority returns `replica.ErrUnavailable` via `errors.Is`.

## Gates and evidence qualifications

Reviewed sealed `author-receipt.json`, `results.json`, source manifests, watchdog receipts, final test deltas, combined inventory and coverage artifacts under `/var/tmp/rho-v5-v2-certified-final-20261011`. Every recorded gate completed with exit 0. Final fmt/vet/build, pinned lint/security/vulnerability scanners, certified and remaining graphapply lanes, and full graphstore normal/race evidence pass. Exhaustive graphapply lanes cover 267 distinct names; one additive authority guard has separate normal/race/coverage evidence, yielding 268 total names.

Registry55 and cross31 normal/race gates are explicitly carried from the reviewed earlier freeze. Independently reviewed production conservation: only certified host/reader paths changed at that correction boundary, preserving legacy registry/cross behavior. Changed-file coverage entries from carry are excluded. Previous accepted module coverage is admitted only for exact matching source-file hashes. This is qualified evidence reuse, not a claim of a fresh monolithic final-source full-module run.

Since the broad completed freeze, only `certified_graph_guards_test.go` and `cross_partition_protocol_test.go` changed; all production bytes remain identical. The latter restores the actual legacy factory success path while the certified branch retains its actual factory. Its focused normal/race/coverage checks pass. The former adds the meaningful missing durable-certificate authority guard; its focused normal/race/coverage checks and final lint pass. No test was removed or replaced.

Independently recomputed merged coverage: **28,317 / 32,130 statements = 88.132586%**. All eight new and nineteen changed production files in the reporting scope meet 80%. All twelve new exported declarations have direct receiver-specific test witnesses recorded in `direct-public-receiver-witnesses.json`; the matching coverage functions all meet 80%, minimum **81.6%** (`allocationHost.AtGraphCertificate`). Generic Open/Close/Work regex hits were not treated as evidence for unrelated receivers.

Vulnerability scanning reports zero reachable vulnerabilities; its log notes advisories in imported packages/required modules that are not called. This is not a claim that all dependency advisories are absent. Watchdog receipts preserve bounded invocation outcomes (4 GiB / 180 seconds); no reviewer runtime or source mutation was performed for this package 3 sign-off.

## Scope boundary

Package 4 process/physical-host faults, ownership transfer, GC and engine/KV comparison, the complete V2 milestone, and public V4 adapters remain open. Canonical external commit `0ebb025f` is outside this manifest and is not reviewed or accepted here. Root retains integration, documentation, commit and authorized publication responsibilities; this reviewer made no repository edit, commit or push.
