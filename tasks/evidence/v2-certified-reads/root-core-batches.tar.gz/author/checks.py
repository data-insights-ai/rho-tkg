from pathlib import Path
import json, os, re, subprocess, sys, tempfile
root=Path('/var/tmp/rho-v5-v2-ci-core-split-20261011'); out=Path(__file__).parent
stub='''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
cfg=json.loads(Path(os.environ['FAKE_GO_CONFIG']).read_text())
args=sys.argv[1:]
with Path(os.environ['FAKE_GO_CALLS']).open('a') as f:f.write(json.dumps({'args':args,'GOFLAGS':os.getenv('GOFLAGS'),'GOMEMLIMIT':os.getenv('GOMEMLIMIT'),'GOWORK':os.getenv('GOWORK')})+'\\n')
if args[0]=='list':
 if args[-1]=='./pkg/graph/internal/core':
  if cfg.get('fail_core_list'):sys.exit(21)
  print(cfg['core'])
 else:
  if cfg.get('fail_packages'):sys.exit(22)
  print('\\n'.join(cfg['packages']))
elif '-list' in args:
 if cfg.get('fail_inventory'):sys.exit(23)
 print('\\n'.join(cfg['inventory']))
 if cfg.get('unexpected_inventory'):print(cfg['unexpected_inventory'])
 if not cfg.get('missing_footer'):print('ok  '+cfg['core']+' 0.001s')
elif '-run' in args:
 if cfg.get('fail_shard') and len([x for x in Path(os.environ['FAKE_GO_CALLS']).read_text().splitlines() if '"-run"' in x])==cfg['fail_shard']:sys.exit(24)
else:
 if cfg.get('fail_other'):sys.exit(25)
'''
base={'core':'example.test/root/pkg/graph/internal/core','packages':['example.test/root/other', 'example.test/root/pkg/graph/internal/core','example.test/root/final'],'inventory':['TestZulu','FuzzSeeds','TestReImportKeepsEveryLife','ExampleThing','TestAlpha','TestNewLater','TestUnicode_Ä','FuzzLater','ExampleNew']}
results=[]
def run_case(name,edit,shards=4,baseline=False):
 with tempfile.TemporaryDirectory(prefix='race-gate-') as tmp:
  tmp=Path(tmp);go=tmp/'go';go.write_text(stub);go.chmod(0o755)
  cfg=dict(base);cfg.update(edit);config=tmp/'config.json';config.write_text(json.dumps(cfg));calls=tmp/'calls.jsonl'
  env=os.environ.copy();env.update(PATH=str(tmp)+':'+env['PATH'],FAKE_GO_CONFIG=str(config),FAKE_GO_CALLS=str(calls),GOFLAGS='-p=1 -parallel=4',GOMEMLIMIT='2GiB',GOWORK='off')
  command=['make','--no-print-directory','test-race','V5_DISPATCH=0','COMPARE_DISPATCH=0','ROOT_RACE_CORE_SHARDS='+str(shards)]
  r=subprocess.run(command,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10)
  call_list=[json.loads(line) for line in calls.read_text().splitlines()] if calls.exists() else []
  (out/(name+'.log')).write_text(r.stdout+'\nCALLS\n'+json.dumps(call_list,indent=2)+'\n')
  if baseline:
   shards_called=[x for x in call_list if '-run' in x['args']]
   assert len(shards_called)==0 and len(call_list)==1
   # The existing shared target ignores the new request and executes ./... once.
   result={'name':name,'baseline_missing_exhaustive_split':len(shards_called)!=4,'exit_code':r.returncode,'calls':len(call_list)}
   results.append(result);return
  if shards==1:
   assert r.returncode==0 and [x['args'] for x in call_list]==[['test','-short','-race','-count=1','./...']]
  elif name in ['complete','new-names','shuffled','regex-literals','core-only']:
   assert r.returncode==0,(name,r.stdout)
   runtime=[x for x in call_list if x['args'][0]=='test' and '-list' not in x['args']]
   others=[p for p in cfg['packages'] if p!=cfg['core']]
   offset=int(bool(others))
   assert len(runtime)==4+offset,(name,call_list)
   if others:assert runtime[0]['args']==['test','-short','-race','-count=1']+others
   assigned=[];patterns=[]
   for x in runtime[offset:]:
    args=x['args'];assert args[:5]==['test','-short','-race','-count=1','-run'] and args[-1]==cfg['core']
    pat=args[5];patterns.append(pat);chosen=[x for x in cfg['inventory'] if re.fullmatch(pat,x)]
    assert chosen;assigned+=chosen
    assert not re.search(r'(?:-timeout|-parallel|-p=|-cpu)', ' '.join(args))
   assert sorted(assigned)==sorted(cfg['inventory']) and len(assigned)==len(set(assigned))
   assert sum('TestReImportKeepsEveryLife' in p for p in patterns)==1
   expected=[sorted(cfg['inventory'])[i::4] for i in range(4)]
   assert [[x for x in sorted(cfg['inventory']) if re.fullmatch(p,x)] for p in patterns]==expected
  else:
   assert r.returncode!=0,(name,r.stdout,call_list)
   if name in ['core-list-failure','package-list-failure','inventory-failure','duplicate-names','duplicate-packages','empty-inventory','missing-footer','unexpected-inventory','too-few','invalid-shards','blank-shards']:
    assert not [x for x in call_list if x['args'][0]=='test' and '-list' not in x['args']],call_list
   if name=='other-failure':assert len([x for x in call_list if x['args'][0]=='test' and '-list' not in x['args']])==1
   if name=='shard-failure':assert len([x for x in call_list if '-run' in x['args']])==2
  if r.returncode:assert 'all root packages and core shards passed' not in r.stdout
  assert all(x['GOFLAGS']=='-p=1 -parallel=4' and x['GOMEMLIMIT']=='2GiB' and x['GOWORK']=='off' for x in call_list)
  results.append({'name':name,'passed':True,'exit_code':r.returncode,'calls':len(call_list)})
if len(sys.argv)>1 and sys.argv[1]=='baseline':
 run_case('baseline-no-core-split',{},baseline=True)
else:
 run_case('default-unsplit',{},shards=1)
 run_case('complete',{})
 run_case('core-only',{'packages':[base['core']]})
 run_case('new-names',{'inventory':base['inventory']+['TestAnotherBrandNew','FuzzNewInput','ExampleFresh']})
 run_case('shuffled',{'inventory':list(reversed(base['inventory']))})
 run_case('regex-literals',{'inventory':base['inventory']+['TestLiteral[1]','TestLiteral+$','FuzzLiteral\\Name']})
 for name,edit in [('core-list-failure',{'fail_core_list':True}),('package-list-failure',{'fail_packages':True}),('inventory-failure',{'fail_inventory':True}),('duplicate-names',{'inventory':base['inventory']+[base['inventory'][0]]}),('duplicate-packages',{'packages':base['packages']+[base['packages'][0]]}),('empty-inventory',{'inventory':[]}),('missing-footer',{'missing_footer':True}),('unexpected-inventory',{'unexpected_inventory':'unexpected stdout'}),('too-few',{'inventory':['TestA','FuzzA','ExampleA']}),('other-failure',{'fail_other':True}),('shard-failure',{'fail_shard':2})]:run_case(name,edit)
 run_case('invalid-shards',{},shards=5)
 run_case('blank-shards',{},shards='')
 for flags in [[],['V5_DISPATCH=0','COMPARE_DISPATCH=0'],['V5_DISPATCH=0','COMPARE_DISPATCH=0','ROOT_RACE_CORE_SHARDS=4']]:
  label='dry-'+str(len(results));r=subprocess.run(['make','-n','test-race']+flags,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10)
  assert r.returncode==0;rout=r.stdout;(out/(label+'.log')).write_text(rout)
  if not flags:assert '-C v5' in rout and '-C tools/graph-compare' in rout
  else:assert '-C v5' not in rout and '-C tools/graph-compare' not in rout
  results.append({'name':label,'passed':True})
  print(label,rout)
print(json.dumps(results,indent=2));(out/('baseline.json' if len(sys.argv)>1 else 'checks.json')).write_text(json.dumps(results,indent=2)+'\n')
