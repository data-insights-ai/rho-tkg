import os,sys,json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).parent
go='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go'
scanner='/var/tmp/rho-v5-migrate-main4517-0eb0a0ac-20261014/scanner-bin'
mode=sys.argv[1]
p01='TestCertifiedGraphP01CoordinatorOutsideRequestedDataScope'
p04='TestCrossProcessP04FrozenParticipantsEpochsAndDigestsSurviveDelayedVoteAndReopen'
args={'compile':[go,'test','-count=1','-timeout=150s','-run=^$','./internal/graphapply'],'normal':[go,'test','-count=1','-timeout=150s','-v','-work','-run=^'+p01+'$','./internal/graphapply'],'race':[go,'test','-race','-count=1','-timeout=150s','-v','-work','-run=^'+p01+'$','./internal/graphapply'],'coverage':[go,'test','-count=1','-timeout=150s','-v','-work','-coverprofile='+str(root/'coverage.out'),'-run=^'+p01+'$','./internal/graphapply'],'vet':[go,'vet','./internal/graphapply'],'lint':[scanner+'/golangci-lint','run','--config','../.golangci.yml','./internal/graphapply'],'security':[scanner+'/gosec','-quiet','./internal/graphapply']}[mode]
env=os.environ.copy(); env.update(GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local',PATH=str(Path(go).parent)+':'+env['PATH'])
cmd=['python3',str(root/'limit-local.py'),'--rss-mib','4096','--seconds','180','--report',str(root/(mode+'.watchdog.json')),'--']+args
meta={'cwd':'/var/tmp/rho-v2-ack-attribution-20261014/v5','command':cmd,'environment':{k:env[k] for k in ['GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GOWORK','GOTOOLCHAIN','PATH']},'tool_sha256':hashlib.sha256(Path(args[0]).read_bytes()).hexdigest()}
(root/(mode+'.command.json')).write_text(json.dumps(meta,indent=2)+'\n')
with (root/(mode+'.stdout.txt')).open('w') as out,(root/(mode+'.stderr.txt')).open('w') as err:
 r=subprocess.run(cmd,cwd=meta['cwd'],env=env,stdout=out,stderr=err)
print(mode,'terminal',r.returncode)
print((root/(mode+'.stdout.txt')).read_text()[-5000:]);print((root/(mode+'.stderr.txt')).read_text()[-1000:])
sys.exit(r.returncode)
