import os,sys,json,subprocess,hashlib,shutil
from pathlib import Path
repo=Path("/var/tmp/rho-v5-v2-cross-partition-20261011");out=Path(__file__).parent
go="/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin"
env=os.environ.copy();env.update(PATH=go+":/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin",GOWORK="off",GOTOOLCHAIN="local",GOPROXY="off",GOSUMDB="off",GOCACHE="/var/tmp/rho-v5-go-build-cache-go1.26.9",GOFLAGS="-p=1",GOMAXPROCS="2",GOMEMLIMIT="2GiB")


source=json.loads((out/"source.json").read_text())
def verify():
 for row in source["files"]:assert hashlib.sha256((repo/row["path"]).read_bytes()).hexdigest()==row["sha256"],row["path"]
verify()
cmd=["/usr/bin/python3","/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py","--rss-mib","4096","--seconds","180","--report",str(out/"red-budget.json"),"--","go","test","-count=1","-timeout=150s","-v","./internal/raftlog","-run","^TestRecovery(OneCreditQueuedReservationRoundTripAndReopen|ReservedSmallPhasesMustFitBeyondGenericPendingWorstCase)$"]
with (out/"red.log").open("wb") as log:r=subprocess.run(cmd,cwd=repo/"v5",env=env,stdout=log,stderr=subprocess.STDOUT)
verify()
(out/"status.json").write_text(json.dumps({"exit":r.returncode,"command":cmd,"source_before_after_verified":True,"classification":"Store exact queued frame and classified pending cliffs RED expected"},indent=2)+"\n")
print((out/"red.log").read_text());sys.exit(r.returncode)
