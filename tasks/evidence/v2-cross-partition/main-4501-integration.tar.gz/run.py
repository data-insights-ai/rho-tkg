from pathlib import Path
import json,subprocess,os,hashlib,sys
r=Path('/var/tmp/rho-v5-v2-cross-final-20261011');o=Path(__file__).parent
go=Path('/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin')
env=dict(os.environ);env.update(PATH=str(go)+os.pathsep+env['PATH'],GOWORK='off',GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off',GOFLAGS='-p=1',GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOCACHE='/var/tmp/rho-v5-go-build-cache-go1.26.9')
names=subprocess.check_output(['git','ls-files','-z','pkg','internal','bench','go.mod','go.sum','AGENTS.md','CHANGELOG.md','README.md','docs'],cwd=r,text=True).split('\0')
names=sorted(n for n in names if n and (r/n).is_file());manifest={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names};(o/'source.json').write_text(json.dumps(manifest,indent=2)+'\n')
def verify():
 for n,h in manifest.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
old=json.loads(Path('/var/tmp/rho-v5-v2-cross-final2-gates-20261011/source.json').read_text())
for f in old['files']:
 if f['path'].startswith('v5/'):assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
commands=[('build',[str(go/'go'),'build','./...']),('vet',[str(go/'go'),'vet','./...']),('interval-doc-race',[str(go/'go'),'test','-short','-race','-count=1','-timeout=150s','-run','IntervalWithTx|Doc|Errors','./pkg/graph/internal/core','./pkg/graph','./pkg/graph/temporal'])]
results=[]
for name,cmd in commands:
 verify();print('START',name,flush=True)
 with (o/(name+'.log')).open('wb') as log:
  rc=subprocess.run([sys.executable,'/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096','--seconds','180','--report',str(o/(name+'-budget.json')),'--']+cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 verify();print('END',name,rc,flush=True);results.append({'name':name,'command':cmd,'exit_code':rc});(o/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 if rc:sys.exit(rc)
(o/'status.json').write_text(json.dumps({'state':'complete','v5_source_unchanged':True,'scope':'v4.50.1 main integration: root build/vet and new interval caller-tx/doc/error tests with race; hosted full CI separate'})+'\n')
