import importlib.util,json
from pathlib import Path
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location("gates",p/"run.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
g=str(m.GO_BIN/'go')
for name in ['graphstate','graphstore']:
 for mode,args in [('race',['-race']),('coverage',['-coverpkg=./...','-coverprofile='+str(p/(name+'-coverage.out'))])]:
  m.run(name+'-'+mode,[g,'test','-short','-count=1']+args+['./internal/'+name])
for target in ['fmt-check','vet','build']:
 m.run(target,['/usr/bin/make',target])
m.verify()
print('ROOT REMAINING PASS',flush=True)
