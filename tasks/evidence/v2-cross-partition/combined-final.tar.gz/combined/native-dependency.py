import importlib.util,json,subprocess,hashlib
from pathlib import Path
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location("final_common",p/"run.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.verify()
g=str(m.GO_BIN/"go");results=[]
for name in ["txnproto"]:
 for mode,args in [("normal",[]),("race",["-race"]),("coverage",["-coverpkg=./...","-coverprofile="+str(p/("native-"+name+"-coverage.out"))])]:
  cmd=[g,"test","-short","-count=1","-timeout=150s"]+args+["./internal/"+name]
  gate="native-"+name+"-"+mode
  (p/(gate+"-command.json")).write_text(json.dumps(cmd,indent=2)+"\n")
  m.run(gate,cmd)
  result=json.loads((p/(gate+"-budget.json")).read_text());results.append({"gate":gate,"command":cmd,"budget":result})
  (p/"native-dependency-terminal-results.json").write_text(json.dumps(results,indent=2)+"\n")
  if mode=="coverage":
   profile=p/("native-"+name+"-coverage.out")
   (p/("native-"+name+"-coverage-functions.txt")).write_text(subprocess.check_output([g,"tool","cover","-func="+str(profile)],cwd=m.REPO/"v5",env=m.ENV,text=True))
m.verify()
receipt={"state":"complete","exit":0,"source_before_after_verified":True,"source_sha256":m.digest(p/"source.json"),"inputs":len(json.loads((p/"source.json").read_text())["files"]),"results":results}
(p/"native-dependency-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n");print("NATIVE DEPENDENCY PASS",flush=True)
