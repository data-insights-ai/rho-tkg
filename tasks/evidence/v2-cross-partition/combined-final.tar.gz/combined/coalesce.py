import importlib.util,json,subprocess,re
from pathlib import Path
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('gates',p/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.verify()
profiles=list(sorted((p/'carried-coverage').glob('*.out')))+[p/f'native-{name}-coverage.out' for name in ['raftlog','replica','txnproto']]+[p/f'{name}-coverage.out' for name in ['graphstate','graphstore']]+[Path('/var/tmp/rho-v5-v2-tx-identity-evidence-20261011/final-composed1/coverage.out')]
assert len(profiles)==12
blocks={}
for profile in profiles:
 lines=profile.read_text().splitlines();assert lines[0]=='mode: set'
 for line in lines[1:]:
  loc,n,h=line.split();n=int(n);h=int(h)>0
  if loc in blocks:
   assert blocks[loc][0]==n,(profile,loc);blocks[loc][1]|=h
  else:blocks[loc]=[n,h]
text='mode: set\n'+''.join(f'{k} {n} {int(h)}\n' for k,(n,h) in sorted(blocks.items()))
(p/'coverage.out').write_text(text)
funcs=subprocess.check_output([str(m.GO_BIN/'go'),'tool','cover','-func='+str(p/'coverage.out')],cwd=m.REPO/'v5',env=m.ENV,text=True);(p/'coverage-functions.txt').write_text(funcs)
counts={}
for loc,(n,h) in blocks.items():
 filename=loc.split(':')[0].replace('github.com/data-insights-ai/rho-tkg/v5/','v5/');counts.setdefault(filename,[0,0]);counts[filename][0]+=n*h;counts[filename][1]+=n
changed=subprocess.check_output(['git','diff','--name-only','ff3671b5','--','v5'],cwd=m.REPO,text=True).splitlines();changed=[x for x in changed if x.endswith('.go') and not x.endswith('_test.go')]
floors={x:{'covered':counts[x][0],'statements':counts[x][1],'percent':100*counts[x][0]/counts[x][1]} for x in changed}
(p/'coverage-changed-production.json').write_text(json.dumps(floors,indent=2)+'\n')
public=json.loads((p/'added-exported-inventory.json').read_text());functions={}
for line in funcs.splitlines():
 cols=line.split()
 if len(cols)==3 and cols[0]!='total:':functions[(cols[0].split(':',1)[0].replace('github.com/data-insights-ai/rho-tkg/v5/','v5/'),cols[1])]=float(cols[2].rstrip('%'))
for row in public:row['coverage_percent']=functions[(row['path'],row['name'])]
(p/'coverage-added-exported.json').write_text(json.dumps(public,indent=2)+'\n')
report={'profiles':[str(x) for x in profiles],'covered_statements':sum(n*h for n,h in blocks.values()),'total_statements':sum(n for n,h in blocks.values()),'changed_production_files':len(floors),'below80':[x for x,v in floors.items() if v['percent']<80],'added_exported_declarations':len(public),'uncovered_exported':[x for x in public if x['coverage_percent']==0],'qualification':'Six exact unchanged package/dependency profiles carried from combined-gates1; six affected package profiles completed on final412 source. Each contributing location has one identical statement count. Direct-test evidence is reviewed separately.'}
(p/'coverage-final.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
assert not report['below80'];assert not report['uncovered_exported'];m.verify()
