from pathlib import Path
from collections import defaultdict
import hashlib,json,subprocess,importlib.util
out=Path(__file__).parent
spec=importlib.util.spec_from_file_location('common',out/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.verify()
blocks={};mode=None
for name in ['raftlog','replica','txnproto']:
 lines=(out/('native-'+name+'-coverage.out')).read_text().splitlines()
 if mode is None:mode=lines[0]
 assert mode==lines[0]
 for row in lines[1:]:
  loc,n,count=row.rsplit(' ',2);n,count=int(n),int(count)
  if loc in blocks:assert blocks[loc][0]==n,loc
  blocks[loc]=(n,max(count,blocks.get(loc,(n,0))[1]))
coalesced=out/'native-coalesced-coverage.out';coalesced.write_text(mode+'\n'+''.join(f'{loc} {n} {count}\n' for loc,(n,count) in sorted(blocks.items())))
(out/'native-coalesced-functions.txt').write_text(subprocess.check_output([str(m.GO_BIN/'go'),'tool','cover','-func='+str(coalesced)],cwd=m.REPO/'v5',env=m.ENV,text=True))
summary=defaultdict(lambda:[0,0])
for loc,(n,count) in blocks.items():
 file=loc.split(':')[0];summary[file][1]+=n
 if count:summary[file][0]+=n
new=['internal/raftlog/application_prepared_contract.go','internal/raftlog/application_recovery.go','internal/raftlog/application_recovery_admission.go','internal/raftlog/application_recovery_history.go','internal/raftlog/application_recovery_queue.go','internal/replica/application_recovery.go']
coverage=[]
for path in new:
 c,t=summary['github.com/data-insights-ai/rho-tkg/v5/'+path];coverage.append({'file':path,'covered':c,'statements':t,'percent':100*c/t});assert c/t>=.8,path
(out/'native-new-file-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
results=json.loads((out/'native-terminal-results.json').read_text())+json.loads((out/'native-dependency-terminal-results.json').read_text());assert len(results)==9
artifacts=[]
for r in results:
 assert r['budget']['exit_code']==0
 for suffix in ['.log','-budget.json','-command.json']:
  p=out/(r['gate']+suffix);artifacts.append({'path':str(p),'sha256':m.digest(p)})
for name in ['source.json','source.tar.gz','native-final-receipt.json','native-dependency-receipt.json','native-new-file-coverage.json','native-coalesced-coverage.out','native-coalesced-functions.txt']+[f'native-{p}-coverage.{ext}' for p in ['raftlog','replica','txnproto'] for ext in ['out']]+[f'native-{p}-coverage-functions.txt' for p in ['raftlog','replica','txnproto']]:
 p=out/name;artifacts.append({'path':str(p),'sha256':m.digest(p)})
m.verify()
receipt={'source':str(out/'source.json'),'source_sha256':m.digest(out/'source.json'),'inputs':len(json.loads((out/'source.json').read_text())['files']),'base':json.loads((out/'source.json').read_text())['base'],'results':results,'new_native_file_coverage':coverage,'artifacts':artifacts,'source_before_after_verified':True,'runtime_released':True,'qualification':'Complete -short normal/race/coverage for raftlog, replica and affected txnproto only, Go1.26.9/4GiB/180s per invocation, separate coverpkg=./... profiles coalesced by exact source block max. Whole module graph/scanner acceptance remains root coordinated. No source edits or cap changes. Original exact-source REDs retained; root explicitly declined redundant mutants.'}
(out/'native-qualified-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out/'native-qualified-receipt.json'),'receipt_sha256':m.digest(out/'native-qualified-receipt.json'),'source_sha256':receipt['source_sha256'],'results':[{ 'gate':r['gate'],'exit':r['budget']['exit_code'],'seconds':r['budget']['elapsed_s'],'rss_mib':r['budget']['peak_tree_rss_mib']} for r in results],'coverage':coverage},indent=2))
