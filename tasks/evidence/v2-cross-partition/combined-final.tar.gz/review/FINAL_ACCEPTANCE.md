# Final same-reviewer V2 package 2 acceptance

Recommendation: **accept V2 package 2; mergeable within the reviewed scope**. No blocking or non-blocking defect remains in the reviewed implementation. This final recommendation supersedes the original blocked freeze recommendation in `REVIEW.md`; original failing reproductions remain retained.

The accepted source is `/var/tmp/rho-v5-v2-cross-final-20261011`, exactly 412 manifest inputs, SHA256 `05a91666717441e100f9bf0617dbbcac418b7f5b7503a2f2cdd7957b1b53d187`. The final tree independently hash-matches every input after gates. Root's coalesced source is identical to the graph author's final-composed1 source. Later origin/main v4.50.1/docs integration is a separate root action; this recommendation makes no claim about unreviewed future source changes.

Both independently reproduced P1 findings are corrected and rechecked by this same reviewer:

- Qualified transaction identity binds GraphID, coordinator and original request key, while retaining coordinator-local deduplication. Same raw request keys at different coordinators now recover through deterministic loser ABORT and winner COMMIT; durable reopen, cleanup, immutable terminal retries and foreign-key local replay are tested.
- Completion-creation admission uses the canonical pending-install record helper including the native recovery-root envelope. Exact fitting and one-record-over boundaries, actual local/forwarded Driver refusal before RawNode mutation, and subsequent healthy progress are tested under unchanged caps.

The separately discovered external AS5 `PreparedApplicationSnapshot.ApplicationContract` integration mismatch is corrected with the recovery-aware constructor. Genuine AS5 returns the complete version-3 contract, and existing AS2/AS4 contracts and lifetime guards remain preserved.

Final evidence audit:

- Native raftlog/replica/txnproto full normal, race and coverage: all nine gates PASS; receipt artifact hashes independently verified.
- Graphapply full normal plus coverage: PASS. Race inventory independently recomputed against all 232 actual test declarations: 33 cross-family and 199 complement tests form an exact disjoint union, both PASS. No test omission or relaxed deadline.
- Graphstate/graphstore race and coverage, format, vet and build: terminal PASS receipts inspected, source verified unchanged.
- Twelve complete package coverage profiles coalesced by identical source-block statement counts: independently recomputed **27,153/30,788 = 88.19345%**. All **46 changed production files >=80%**; all **47 added exported declarations nonzero**, with direct tests reviewed in the original/correction review.
- Pinned golangci-lint v2.13.2, gosec v2.29.0 and govulncheck v1.7.0 on Go 1.26.9: PASS. Govulncheck reports **zero reachable vulnerabilities**, while noting two imported-package and two required-module advisories not called by the code; counts can overlap, and absence of advisories is not claimed.
- Six unchanged package/dependency profiles are carried with explicit byte-conservation qualifications; affected profiles were rerun. Earlier watchdog failures and intermediate fixture failures remain retained and honestly qualified.
- Every heavy invocation retains the 4 GiB/180-second watchdog; tests retain 150-second deadlines. Scanner containers are capped at 4 GiB/two CPUs; recorded scanner RSS is the host CLI tree, not a container peak. No runtime or code mutation was performed during final reviewer rechecks.

Acceptance covers one GraphID, two declared partitions and three disk-backed voters each; complete routed graph dependencies and both endpoint effects; durable private prepare kernels/locks blocking conflicting local writes; immutable decisions and retries; typed decided-round state/history/CDC; protected applied/queued completion capacity through proposal, application, snapshots, failover and durable reopen. Unavailable/missing authority remains unavailable and cannot become a timeout ABORT.

This **does not accept V2 as a whole**. Certified distributed current/historical reads belong to package 3. The full same-graph serial-history/cut oracle under process/message faults and ownership transfer, physical-host durability, transactional-KV comparison and engine decision belong to package 4 or their separately declared gates. No distributed cut, physical capacity/performance, multi-host or broader registry-readiness claim follows from package 2 acceptance.

Evidence pointers: original `REVIEW.md`, `BLOCKER-1.md`, `BLOCKER-2.md` and exact reproduction archive; `NATIVE-RECHECK.md`, `IDENTITY-RECHECK.md`; root `cross-final2-gates/coverage-final.json` and `native-qualified-receipt.json`; graph `final-composed1/author-receipt.json`. The reviewer made no production changes, commit, push, tag or roadmap update.
