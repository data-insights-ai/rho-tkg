Owned graphapply source and author evidence are final. `owned-overlay.tar.gz` and `owned.patch` contain exactly 18 graphapply paths: 13 production files and five tests. Native, graphstore and root-authorized assertion overlays are support only and are excluded. `receipt.json` records all hashes, commands, results, qualifications and support provenance.

The authoritative author freeze is `../final-author5`: 399 exact mirror/archive inputs, source-manifest SHA256 `fd4743b37c87ff7ef5010447af37548f20cc540a715bde5a8b0122559659047e`. Mirror, tar, worktree and owned-overlay hashes were rechecked after all gates. Reverse application of the owned patch was checked successfully.

Author gates on that same freeze:

| Gate | Result | Watchdog seconds | Peak process-tree RSS MiB |
| --- | --- | ---: | ---: |
| Full graphapply normal + coverage | PASS; package 85.6% | 127.268 | 497.578 |
| CrossPartition/CrossRecovery/PartitionGraphVersions race | PASS | 128.786 | 458.469 |
| Pinned make lint-docker, golangci v2.13.2 | PASS; zero issues | 13.265 | 27.797* |
| Pinned make security-docker, gosec v2.29.0 | PASS; zero findings | 1.974 | 27.938* |

All 13 owned production files meet 80%. New file coverage: capacity 80.172%, codec 89.062%, host 80.797%, materializer 80.333%, recovery 84.337%. All ten new exported methods have direct test calls and nonzero coverage; exact percentages and call locations are in `coverage-direct-public.json`.

*Scanner RSS is the host Docker CLI process tree. Each Docker invocation explicitly caps the container at 4 GiB and two CPUs; no container peak RSS or performance claim is made. Tool module/build metadata and hashes are retained in the final freeze. All Go tests retain the 150-second timeout and 180-second/4-GiB process watchdog.

The finite actual-network acceptance covers six local disk voters, immutable typed per-partition kernels, both endpoint postings and ordered CDC, retained local history, leader loss/reopen before and after decision, actual prepared follower snapshot activation/reopen, reserved completion through proposal and application, exact retries, aggregate source/output caps, and malformed proof/manifest/configuration/routing/epoch refusals. Resource-cycle tests cover both coordinator/priority directions and byte/record ordinary-capacity cliffs. Queued competing COMMIT/ABORT tests preserve the first decision at those cliffs, and late prepares cannot reverse terminal state. Unavailable authority creates no capacity-abort proof.

Atomic lifecycle/publication semantics:

- Registration and first prepare co-install the native charged obligation and its bounded global-TxID owner pointer. Prepare installs the immutable manifest, YES/NO, and (for YES) kernel plus lock in one application batch. It publishes no graph effects.
- The coordinator installs one immutable decision. An authenticated completed capacity-conflict observation selects the bytewise larger global TxID's own coordinator for ABORT, spending only that transaction's protected credits. ErrLimit is not a participant NO; a missing vote, timeout or unavailable coordinator cannot authorize this ABORT. Existing COMMIT is returned unchanged. Own unused earlier credits retire only at actual terminal install; Resolve remains protected.
- Local resolve restores its immutable GPP/GPK authority from the genuine supplied bank/view and publishes graph state, typed metadata, both endpoint effects, ordered CDC, round floor, terminal status and lock/owner cleanup together in one application batch. Errors return no partial batch. It needs no remote fresh view or original-history RootAt after YES. Exact retries publish no repeated effects or credit.

Quota-cliff tests prove the loser can terminate with zero ordinary headroom. They do not claim winner COMMIT when ordinary reservation capacity is globally exhausted. Local retained history checks are not certified distributed graph cuts. This work implements only V2 package 2; later read/cut phases and V3–V7 remain outside scope.

The routed view Close result now joins the named error before the existing source-view cleanup, which clears transaction/proposal outputs on any error. A genuine nonnil routed Close currently returns nil; no artificial Close failure was introduced or claimed.

Actual RED archives and the capped/uncapped scanner failures remain intact. Root owns the combined integration gates, one independent review and subsequent authorized commit/push. Root's five preserved external/CHANGELOG differences are not overwritten by this handoff. No author gate failures remain, and the runtime is released.
