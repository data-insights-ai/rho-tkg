# Independent package 2 review - blocking finding 2

P1: native completion-reservation creation undercharges pending installation records before consensus admission.

Location: `v5/internal/raftlog/application_recovery_admission.go:169` computes `pending * (MaxInstallWrites + 3)`. In native recovery mode every ordinary installation also retains one recovery-root envelope: `applicationInstallRecords` returns `MaxInstallWrites + 4`, and the authoritative `recoveryProjected`/`validateApplicationMeta` path uses that complete count.

For sufficiently many existing pending entries, the admission's two-entry headroom no longer compensates for the missing one record per pending installation. This admits a reservation that the same Store refuses when the exact next entry reaches serialized persistence. The actual Driver proposes into RawNode after this admission and stops when drain receives a Persist error (`driver.go`), so this is a progress/admission failure, although the native Store correctly preserves durable state at the final refusal.

Reproduction uses the unchanged valid `boundedControlStore` fixture and its trusted selected verifier, not a caller-created credit token:

- native Recovery version 1, `MaxInstallWrites=1`, existing large byte/generation limits, `RetainedApplicationRecords=128`;
- initial actual retained records 4, Applied 1;
- four durable uncommitted ordinary entries at indexes 2-5, Last 5;
- one valid protected phase, RetainedRecords 100, RetainedBytes 1000, CommandBytes 6;
- `AdmitApplicationRecovery("register")` succeeds with an opaque token;
- exact `Persist` of index 6 with that registration fails with `raftlog: resource limit`, with the durable metadata fingerprint unchanged.

Independent arithmetic: admission books `4 + (4+2)*(1+3) + 100 = 128`, which fits. Actual five pending ordinary/registration installations need `4 + 5*(1+4) + 100 = 129`, which exceeds the unchanged 128 ceiling. The public native policy and credit validation accept all these numbers.

Command: complete environment and watchdog arguments are in `creation-watchdog.json`; Go 1.26.9, offline dependencies, `go test -short -count=1 -timeout=150s -run '^TestIndependentRecoveryCreationCannotUnderchargePendingRecordCliff$' -v ./internal/raftlog`, `limit-local.py --rss-mib 4096 --seconds 180`. RED exit 1, 3.574 seconds, 387.297 MiB peak process-tree RSS. No live process remains.

Evidence: `creation.log`, `creation-watchdog.json`, `source/v5/internal/raftlog/independent_creation_probe_test.go`. All 402 original archived source inputs remain unchanged; the probe is the only added native test.

Correction should use the canonical complete pending-record cost at the shared reservation-creation admission seam, preserving the limits and checking fitting/one-record-over counterparts before RawNode mutation. Package 2 remains unaccepted pending correction and independent recheck.
