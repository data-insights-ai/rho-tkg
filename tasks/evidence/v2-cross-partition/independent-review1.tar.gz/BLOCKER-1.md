# Independent package 2 review - blocking finding 1

P1: two coordinator-scoped request keys alias one global TxID and permanently strand prepared work.

Location: `v5/internal/graphapply/cross_partition_host.go:283` creates `crossManifest.tx` directly from `requestID`; `v5/internal/graphapply/cross_partition_capacity.go:299` refuses a real holder when the raw TxID matches the desired transaction. The different coordinator/template identity is not considered there. `crossRecovery` rejects the cross-coordinator prepare when the same raw TxID already has a different manifest digest.

The existing request contract validates a nonzero `[16]byte` request ID. No globally unique external request-ID precondition is declared by `requestID`, `PrepareCrossPartitionGraphOperations`, or the reviewed plan. Existing local request identity is namespace-qualified. PLAN section 5.2 distinguishes TxID from request key and requires a globally ordered transaction priority.

Reproduction on exact source manifest `543543c282f179a5a49584b9cc12fed7fd5426cb7685117f1b7b3c8284ee40fa`, with one added isolated test and no production changes:

1. Create the real one-GraphID/two-partition/six-disk-voter fixture and its endpoint nodes.
2. Plan A at coordinator partition 3 and B at coordinator partition 8 with requestID `{80}`, different provenance 24/25, from completed source reads.
3. Both plans and both durable registrations succeed. Both get TxID `50000000000000000000000000000000`; A digest is `17e9f201d5f6f93db0ea542f5bf6de2cf1d422cdb7f1747913f366633592dea2`, B digest is `90091d498da4aa16d9c6e2ad29d5f41875a22758bb780ae5b745fbb1ca6f7209`.
4. A durably prepares YES on partition 3, retaining its coarse lock and completion owner. B retains its coordinator reservation on partition 8.
5. B's prepare on 3 and A's prepare on 8 both refuse with `graphapply: invalid input` before voting.
6. A completed quorum capacity-conflict read on healthy partition 8 returns `replica: authoritative leader read unavailable`, with no loser proof. Missing participant votes cannot authorize either normal abort. Both live owners remain stuck without a recoverable decision.

This is a progress failure with healthy quorums, not a claimed safety violation or timeout-abort requirement. The immutable template hashes prevent unsafe effects, but accepted work has no protocol completion path. A coordinator-qualified global transaction identity, or equivalent enforceable collision handling before durable registration, must preserve the local request/deduplication contract and stable recovery identity. Merely documenting a new caller uniqueness assumption would weaken the existing contract.

Command and resource limits: the complete command is recorded in `duplicate-watchdog.json`. Go 1.26.9, `GOWORK=off`, `GOTOOLCHAIN=local`, `GOFLAGS=-p=1`, `GOMAXPROCS=2`, `GOMEMLIMIT=2GiB`, offline dependencies, shared build cache; `go test -short -count=1 -timeout=150s -run '^TestIndependentSameRequestIDTwoCoordinatorsHaveRecoverableProgress$' -v ./internal/graphapply`, supervised by `limit-local.py --rss-mib 4096 --seconds 180`.

Terminal result: RED, exit 1, 4.993 seconds, 452.672 MiB peak process-tree RSS. Evidence: `duplicate.log`, `duplicate-watchdog.json`, and `source/v5/internal/graphapply/independent_progress_probe_test.go` in this directory. No live command remains.

Package 2 acceptance recommendation: do not accept until corrected and independently rechecked. Scope does not demand package 3 certified reads or package 4 serial-cut/ownership/comparator completion.
