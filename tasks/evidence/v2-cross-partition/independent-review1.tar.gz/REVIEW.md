# Independent V2 package 2 acceptance review

Recommendation: **do not accept this freeze yet**. Two blocking progress/admission findings are reproduced. No additional concrete package 2 blocker emerged from the remaining staged-delta, call-path, and adversarial-test review.

Reviewed source: integration branch `codex/v5-v2-cross-integrated-20261011`, base `ff3671b5b18bd2cbf0628a931549efd0a3cb89ad`; complete staged delta of 65 paths. Original 402 archived inputs independently hash-match manifest `543543c282f179a5a49584b9cc12fed7fd5426cb7685117f1b7b3c8284ee40fa`. The integration and canonical worktrees were not edited. Only two test files were added in an isolated extracted source copy.

## Blocking findings

1. **P1 - coordinator-scoped request IDs alias one global TxID.** `cross_partition_host.go:283` takes TxID directly from requestID. Two healthy coordinators can durably register different manifests under that same raw ID. Once one prepares YES, each refuses the other's prepare, and `cross_partition_capacity.go:299` labels the real collision unavailable instead of producing a recoverable loser. Neither normal decision path has a complete vote set. The exact six-disk-voter reproduction, both manifest digests, commands and RED are in [BLOCKER-1.md](BLOCKER-1.md).
2. **P1 - reservation-creation admission undercharges native pending records.** `application_recovery_admission.go:169` uses `MaxInstallWrites+3` although RLM8 adds a recovery-root envelope, and authoritative persistence uses `+4`. A valid record-boundary case with four pending entries succeeds in pre-proposal admission and then refuses the exact next persistence. `Driver.drain` stops on that error after proposal mutation. Native refusal preserves durable state; the bug is false admission/progress. Exact arithmetic, RED and limitations are in [BLOCKER-2.md](BLOCKER-2.md).

The author's correction must preserve the existing limits and original request-key replay behavior, carry the qualified transaction identity through controls/kernels/locks/credit owners/priority/recovery, and use the canonical complete record charge at the shared creation-admission seam. These two changes require independent correction rechecks by this same reviewer.

## Non-blocking findings and scope

No separate non-blocking defect is raised. The coarse partition lock is an acceptable initial implementation: complete declared participants are frozen, captured semantic roots/floors are checked before YES, and ordinary local graph/allocation mutations consult the durable lock. The routed graphstore paths cover global typed value identity, schema/axis authority, uniqueness, remote primaries, and both canonical/declared/current endpoint postings. Prepared restoration checks actual co-installed immutable controls and the genuine supplied local bank/view; resolution does not replan or require a fresh remote old root.

The tests contain node/relationship historical mutation controls, explicit retained/new revision slot assertions, sequential CDC Before/After cases, exact endpoint sets, phantom uniqueness queries, malformed/stale authority refusals, cumulative source/output/cursor limits, leader reopen before/after decision, actual prepared follower snapshot activation, queued competing decisions, four logical quota families, and retirement/retry checks. These assertions go beyond the coverage percentages. They did not cover the two newly reproduced boundaries.

The documented views and proofs explicitly deny certified global-cut authority. Certified distributed reads belong to package 3; the full E15-E18 serial-cut oracle, ownership transfer, physical-host faults and transactional-KV comparison belong to package 4. Their absence is not a package 2 blocker or a reason to weaken the two findings above.

A third integration boundary is tracked separately by root: external commit `9600d634` adds `PreparedApplicationSnapshot.ApplicationContract`, whose controls-only constructor must honor the newly integrated recovery contract/version 3. That source is outside this 402-input review freeze. Root/native author owns its RED/fix and combined integration validation; this report makes no claim that this external correction was independently accepted here.

## Evidence and limitations

- Existing combined validation was inspected: full-module normal/race coverage and pinned static/security/vulnerability evidence apply to the stated frozen inputs. Failed aggregate watchdog attempts are retained and qualified; graphapply race was split into exhaustive disjoint groups under unchanged limits. This reviewer did not redundantly rerun broad gates.
- Existing coverage is 26,745/30,384 statements (88.02%); all 44 changed production files meet 80%, all 46 added exported declarations have nonzero reported coverage, and direct call sites are present in the tests. This does not override failing correctness probes.
- Independent larger-transaction progress probe: 8/16/32 labels planned, prepared, committed and resolved successfully at the same limits; 64 labels refused during planning before protocol state. PASS, 12.022 seconds, 497.516 MiB peak process-tree RSS (`progress.log`, `progress-watchdog.json`).
- Independent identity collision probe: RED, 4.993 seconds, 452.672 MiB (`duplicate.log`, `duplicate-watchdog.json`). Uses real six disk-backed voters and completed quorum reads.
- Independent pending-record probe: RED, 3.574 seconds, 387.297 MiB (`creation.log`, `creation-watchdog.json`). This directly proves native admission/Persist disagreement; Driver stop follows the inspected `driver.go:713-714` path and was not separately executed in this probe.
- All commands use Go 1.26.9, one invocation at a time, a 4 GiB process-tree RSS watchdog and 180-second wall limit, two CPUs and GOMEMLIMIT 2 GiB. No cap or test timeout was raised. No runtime remains live.
- `reproduction-source.json` and `reproduction-source.tar.gz` retain all original 402 inputs unchanged plus exactly the two isolated probe sources. Logs and watchdog receipts retain full commands/results. No production fix, commit, push, tag, or new roadmap was made by this reviewer.

Package 2 is blocked on the two findings, pending author correction and independent recheck. This report does not accept V2 as a whole.
