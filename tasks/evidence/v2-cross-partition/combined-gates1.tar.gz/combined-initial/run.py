import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

REPO = Path('/var/tmp/rho-v5-v2-cross-integrated-20261011')
OUT = Path(__file__).parent
GO_BIN = Path('/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin')
WATCHDOG = '/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py'
ENV = dict(os.environ)
ENV.update(PATH=str(GO_BIN) + os.pathsep + ENV['PATH'], GOWORK='off',
           GOTOOLCHAIN='local', GOPROXY='off', GOSUMDB='off', GOFLAGS='-p=1',
           GOMAXPROCS='2', GOMEMLIMIT='2GiB',
           GOCACHE='/var/tmp/rho-v5-go-build-cache-go1.26.9')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z',
         'v5', '.golangci.yml', 'AGENTS.md', 'CHANGELOG.md'], cwd=REPO).decode().split('\0')
    names = sorted({name for name in names if name and (REPO / name).is_file()})
    manifest = {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                cwd=REPO, text=True).strip(),
                'files': [{'path': name, 'sha256': digest(REPO / name)} for name in names]}
    (OUT / 'source.json').write_text(json.dumps(manifest, indent=2) + '\n')
    with tarfile.open(OUT / 'source.tar.gz', 'w:gz') as archive:
        for name in names:
            archive.add(REPO / name, arcname=name, recursive=False)
    print(f'Frozen {len(names)} files', flush=True)


def verify():
    manifest = json.loads((OUT / 'source.json').read_text())
    for row in manifest['files']:
        if digest(REPO / row['path']) != row['sha256']:
            raise RuntimeError('frozen input changed: ' + row['path'])


def run(name, command):
    verify()
    if shutil.disk_usage(REPO).free < 2 * 2**30:
        raise RuntimeError('disk launch guard')
    print('START ' + name, flush=True)
    (OUT / 'status.json').write_text(json.dumps({'step': name, 'state': 'running'}) + '\n')
    invocation = [sys.executable, WATCHDOG, '--rss-mib', '4096', '--seconds', '180',
                  '--report', str(OUT / (name + '-budget.json')), '--'] + command
    with (OUT / (name + '.log')).open('wb') as log:
        result = subprocess.run(invocation, cwd=REPO / 'v5', env=ENV,
                                stdout=log, stderr=subprocess.STDOUT)
    verify()
    (OUT / 'status.json').write_text(json.dumps(
        {'step': name, 'state': 'finished', 'exit_code': result.returncode,
         'source_verified': True}) + '\n')
    print(f'END {name} exit={result.returncode}', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


def gates():
    run('fmt-check', ['/usr/bin/make', 'fmt-check'])
    run('check', ['/usr/bin/make', 'check'])
    packages = subprocess.check_output([str(GO_BIN / 'go'), 'list', './...'],
                                      cwd=REPO / 'v5', env=ENV, text=True).splitlines()
    (OUT / 'race-packages.json').write_text(json.dumps(packages, indent=2) + '\n')
    # The complete suite previously took ~300 s in aggregate. Every package
    # receives the exact make test-race flags, sequentially, retaining the
    # 180 s watchdog per invocation and the unchanged Go test timeout.
    for index, package in enumerate(packages):
        run(f'race-{index:02d}-{package.rsplit("/", 1)[-1]}',
            [str(GO_BIN / 'go'), 'test', '-short', '-race', '-count=1', package])
    run('cover', ['/usr/bin/make', 'cover'])
    shutil.copyfile(REPO / 'v5/coverage.out', OUT / 'coverage.out')
    (OUT / 'coverage-functions.txt').write_text(subprocess.check_output(
        [str(GO_BIN / 'go'), 'tool', 'cover', '-func=' + str(OUT / 'coverage.out')],
        cwd=REPO / 'v5', env=ENV, text=True))
    docker = ('/usr/local/bin/docker run --rm --memory=4g --cpus=2 '
              '-e GOTOOLCHAIN=local -e GOWORK=off -e GOMAXPROCS=2 -e GOFLAGS=-p=1 '
              f'-v {REPO}:/src -w /src/v5 '
              '-v rho-tkg-gocache:/go -v rho-tkg-buildcache:/root/.cache/go-build '
              'golang:1.26.9')
    for target in ['lint-docker', 'security-docker', 'vulncheck-docker']:
        run(target, ['/usr/bin/make', 'DOCKER_GO=' + docker, target])
    (OUT / 'status.json').write_text(json.dumps(
        {'state': 'complete', 'exit_code': 0, 'source_verified': True,
         'race_packages': len(packages), 'qualification': 'All v5 packages; v4 unchanged and not rerun here'}) + '\n')
    print('COMBINED GATES PASS', flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['freeze']:
        freeze()
    elif sys.argv[1:] == ['run']:
        gates()
    else:
        raise SystemExit('usage: run.py freeze|run')
