import importlib.util
import json
import shutil
import subprocess
from pathlib import Path
p=Path(__file__).parent
s=importlib.util.spec_from_file_location('gates',p/'run.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
packages=json.loads((p/'race-packages.json').read_text())
parts=p/'coverage-parts';parts.mkdir(exist_ok=True)
if (m.REPO/'v5/coverage.out').exists():
    shutil.copyfile(m.REPO/'v5/coverage.out',p/'coverage-interrupted.out')
profiles=[]
for index,package in enumerate(packages):
    profile=parts/f'{index:02d}.out'
    m.run(f'cover-{index:02d}-{package.rsplit("/",1)[-1]}',[str(m.GO_BIN/'go'),'test','-short','-count=1','-coverpkg=./...','-coverprofile='+str(profile),package])
    profiles.append(profile)
blocks={}
for profile in profiles:
    lines=profile.read_text().splitlines()
    assert lines[0]=='mode: set',(profile,lines[:1])
    for line in lines[1:]:
        location,statements,count=line.split()
        statements,count=int(statements),int(count)
        assert statements>=0 and count>=0
        if location in blocks:
            assert blocks[location][0]==statements,(profile,location)
            blocks[location][1]|=count>0
        else:
            blocks[location]=[statements,count>0]
merged='mode: set\n'+''.join(f'{key} {n} {int(hit)}\n' for key,(n,hit) in sorted(blocks.items()))
(p/'coverage.out').write_text(merged)
(m.REPO/'v5/coverage.out').write_text(merged)
(p/'coverage-functions.txt').write_text(subprocess.check_output([str(m.GO_BIN/'go'),'tool','cover','-func='+str(p/'coverage.out')],cwd=m.REPO/'v5',env=m.ENV,text=True))
m.run('cover-html',[str(m.GO_BIN/'go'),'tool','cover','-html='+str(p/'coverage.out'),'-o',str(p/'coverage.html')])
shutil.copyfile(p/'coverage.html',m.REPO/'v5/coverage.html')
(p/'coverage-complete.json').write_text(json.dumps({'packages':packages,'profiles':[str(x.relative_to(p)) for x in profiles],'mode':'set','merge':'Union of covered blocks; repeated block statement counts must agree; identical frozen source before/after every invocation.','covered_statements':sum(n for n,hit in blocks.values() if hit),'total_statements':sum(n for n,hit in blocks.values()),'qualification':'make cover initially reached180s watchdog; exact test/coverpkg scope rerun per package, all successful profiles coalesced without omitting tests or raising limits.'},indent=2)+'\n')
docker=('/usr/local/bin/docker run --rm --memory=4g --memory-swap=4g --cpus=2 '
        '-e GOTOOLCHAIN=local -e GOWORK=off -e GOMAXPROCS=2 -e GOFLAGS=-p=1 -e GOMEMLIMIT=2GiB '
        f'-v {m.REPO}:/src -w /src/v5 '
        '-v rho-tkg-gocache:/go -v rho-tkg-buildcache:/root/.cache/go-build golang:1.26.9')
for target in ['lint-docker','security-docker','vulncheck-docker']:
    m.run(target,['/usr/bin/make','DOCKER_GO='+docker,target])
(p/'status.json').write_text(json.dumps({'state':'complete','exit_code':0,'source_verified':True,'race_packages':len(packages),'coverage_packages':len(packages),'qualification':'All v5 test/race/coverage scope. Graphapply race split by exhaustive inventory; coverage coalesced from complete per-package profiles after retained180s watchdog failures. v4 unchanged and not rerun here.'})+'\n')
print('COMBINED GATES PASS',flush=True)
