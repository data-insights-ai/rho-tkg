import importlib.util
import json
import re
import shutil
import subprocess
from pathlib import Path
p=Path(__file__).parent
s=importlib.util.spec_from_file_location("gates",p/"run.py")
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
plan=json.loads((p/"race-graphapply-groups.json").read_text())
for i,names in enumerate(plan["groups"]):
    expression="^("+"|".join(re.escape(x) for x in names)+")$"
    m.run(f"race-01-graphapply-group{i}",[str(m.GO_BIN/"go"),"test","-short","-race","-count=1","-run",expression,"./internal/graphapply"])
packages=json.loads((p/"race-packages.json").read_text())
for index,package in enumerate(packages):
    if index<2: continue
    m.run(f"race-{index:02d}-{package.rsplit('/',1)[-1]}",[str(m.GO_BIN/"go"),"test","-short","-race","-count=1",package])
m.run("cover",["/usr/bin/make","cover"])
shutil.copyfile(m.REPO/"v5/coverage.out",p/"coverage.out")
(p/"coverage-functions.txt").write_text(subprocess.check_output([str(m.GO_BIN/"go"),"tool","cover","-func="+str(p/"coverage.out")],cwd=m.REPO/"v5",env=m.ENV,text=True))
docker=("/usr/local/bin/docker run --rm --memory=4g --memory-swap=4g --cpus=2 "
        "-e GOTOOLCHAIN=local -e GOWORK=off -e GOMAXPROCS=2 -e GOFLAGS=-p=1 -e GOMEMLIMIT=2GiB "
        f"-v {m.REPO}:/src -w /src/v5 "
        "-v rho-tkg-gocache:/go -v rho-tkg-buildcache:/root/.cache/go-build golang:1.26.9")
for target in ["lint-docker","security-docker","vulncheck-docker"]:
    m.run(target,["/usr/bin/make","DOCKER_GO="+docker,target])
(p/"status.json").write_text(json.dumps({"state":"complete","exit_code":0,"source_verified":True,"race_packages":len(packages),"qualification":"All v5 packages; graphapply race exactly partitioned by recorded test inventory after180s watchdog; unchanged v4 not rerun here"})+"\n")
print("COMBINED GATES PASS",flush=True)
