import importlib.util,json
from pathlib import Path
s=importlib.util.spec_from_file_location("ci","scripts/ci-changes.py");c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
p=c.changed_paths("5cc915c7","560e852d");d=c.ROOT/"v5/internal/graphapply";q=[c.ROOT/x for x in p if x.startswith("v5/internal/graphapply/")];defs={x:c.changed_definitions(x,"5cc915c7") for x in q if x.name.endswith("_test.go") and x.is_file()}
print(json.dumps({"base":"5cc915c7","head":"560e852d","paths":p,"definitions":{str(k.relative_to(c.ROOT)):v for k,v in defs.items()}},indent=2),flush=True)
print(json.dumps({"parents":c.graph_selection(d,q,defs)},indent=2))
