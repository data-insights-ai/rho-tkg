import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/var/tmp/rho-v5-graph-creation-admission-20261012'); e=Path('/var/tmp/rho-v5-replacement-admission-evidence-20261012')
manifest=json.loads((e/'source-hashes.json').read_text()); freeze=json.loads((e/'publication-freeze.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
assert hashlib.sha256((root/freeze['new_test']).read_bytes()).hexdigest()==freeze['new_test_sha256']
stage=sys.argv[1]; assert stage in ('normal','race','coverage','coverfunc')
go='/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go'
command=[go,'test','-count=1','-json','-run','^'+freeze['test']+'$','./internal/graphapply']
if stage=='race': command.insert(2,'-race')
if stage=='coverage': command[2:2]=['-covermode=set','-coverprofile='+str(e/'publication-coverage.out')]
if stage=='coverfunc': command=[go,'tool','cover','-func='+str(e/'coverage-with-publication.out')]
env=dict(os.environ,GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local')
receipt={'command':command,'cwd':str(root/'v5'),'env':{k:env[k] for k in ('GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GOWORK','GOTOOLCHAIN')},'original_source_freeze_sha256':freeze['original_source_freeze_sha256'],'original533_sources_unchanged':True,'new_test_sha256':freeze['new_test_sha256'],'publication_freeze_sha256':hashlib.sha256((e/'publication-freeze.json').read_bytes()).hexdigest(),'scope':freeze['scope'],'stage':stage}
(e/f'publication-{stage}-command.json').write_text(json.dumps(receipt,indent=2)+'\n')
limited=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096MiB','--seconds','180','--report',str(e/f'publication-{stage}-limit.json'),*command]
name='publication-'+stage+('.jsonl' if stage!='coverfunc' else '-functions.txt')
with (e/name).open('w') as output,(e/f'publication-{stage}.stderr.log').open('w') as errors:
 result=subprocess.run(limited,cwd=root/'v5',env=env,stdout=output,stderr=errors,check=False)
limit=json.loads((e/f'publication-{stage}-limit.json').read_text())
print(json.dumps({'stage':stage,'exit_code':result.returncode,'elapsed_s':limit['elapsed_s'],'peak_tree_rss_mib':limit['peak_tree_rss_mib']},indent=2)); sys.exit(result.returncode)
