import pathlib,json,hashlib
b=pathlib.Path(__file__).resolve().parent
selected=set()
def keep(name):
 p=b/name
 if p.is_file():selected.add(name)
def lane(name,coverage=False):
 for suffix in ['.jsonl','.stderr','.watchdog.json']+(['.cover'] if coverage else []):keep(name+suffix)
coverage=json.loads((b/'FINAL_NORMAL_COVERAGE.json').read_text())
for name in coverage['profiles']:lane(name,True)
for name in ['final-test-only-normal','final-transition-test-only-normal']:lane(name,True)
for name in ['final-test-only-race','final-transition-test-only-race','registered-genesis-as4-race']:lane(name)
for p in b.glob('existing-*-race.watchdog.json'):lane(p.name.removesuffix('.watchdog.json'))
for p in b.glob('range-*-race.watchdog.json'):lane(p.name.removesuffix('.watchdog.json'))
red_names=['target-movement','graphstore-generation-red','graphstore-source-output-both-red','graphstore-scan-holes-red','graphapply-seal-enum-compiled-red','graphapply-enum-red','native-coordinator-first','native-admission-allocation-dispatch-red','native-numbered-undo-final-red','native-coordinator-capture-grant','native-abort-new-handoff-tombstone-red','native-abort-new-handoff-and-prepared-red','active-cross-capacity-binding-red','native-replay-capability-red','native-late-fence-red','native-frozen-row-budget-red','native-frozen-lifetime-red','native-durable-export-row-red']
green_names=['graphapply-codec-authority-green','native-coordinator-retained-baseline','native-continuation-profiles-corrected','native-numbered-undo-final-green','native-abort-new-handoff-tombstone-green','prepared-bank-cross-green','active-cross-capacity-binding-green','native-replay-original-copy','native-late-fence-green','native-frozen-session-corrections-green','graphstore-scan-holes-consumers-green']
for name in red_names+green_names:lane(name)
for pattern in ['*red*.txt','*red*source.json','*red*provenance.json','*compiled-guard.json','*qualification.json','continuation-fixture-*.patch','continuation-fixture-calibration.json','*generation-red*.txt','*source-output-red*.txt','*source-output-both-red*']:
 for p in b.glob(pattern):keep(p.name)
for name in ['mutant-current-certified-root','mutant-current-certified-root-at','mutant-skip-target-content']:lane(name)
for p in b.glob('mutant-*.patch'):keep(p.name)
for name in ['final-fmt-vet-build','final-lint-docker','final-lint-amended','final-lint-all-findings','security-bounds-amended','final-vulncheck-docker']:
 for suffix in ['.log','.stderr','.watchdog.json']:keep(name+suffix)
for p in b.glob('final-lint-before-*.txt'):keep(p.name)
for name in ['FINAL_RECEIPT.json','FINAL_INDEX.md','SOURCE_CHECKPOINT.json','final-go-source.json','final-go-source-amended.json','FINAL_NORMAL.cover','FINAL_NORMAL_COVERAGE.json','CHANGED_PRODUCTION_FILE_COVERAGE.json','PUBLIC_DIRECT_WITNESSES.json','existing-lanes.json','range-final-lanes.json','run-existing-lanes.py','run-range-lanes.py','pinned-native-environment.txt','final-lint-test-before.json','package-final-evidence.py']:
 keep(name)
assert not any(n.endswith('.go') or '/' in n for n in selected)
(b/'FINAL_EVIDENCE_FILES.json').write_text(json.dumps(sorted(selected),indent=2)+'\n')
print(len(selected),'selected files',sum((b/n).stat().st_size for n in selected),'bytes')
