import json, os, pathlib, subprocess, sys
base=pathlib.Path(__file__).resolve().parent
repo=base.parents[2]
lanes=json.loads((base/'existing-lanes.json').read_text())
mode=sys.argv[1]
selected=set(sys.argv[2:])
env=os.environ.copy()
env.update(GOTOOLCHAIN='go1.26.9',GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off')
for lane in lanes:
 if selected and lane['lane'] not in selected:continue
 name=lane['lane']+'-'+mode
 command=['go','test','-count=1','-json']
 if mode=='race':command+=['-race']
 else:command+=['-covermode=atomic','-coverprofile='+str(base/(name+'.cover'))]
 command+=['-run',lane['regex'],lane['package']]
 argv=['python3','/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py','--rss-mib','4096','--seconds','180','--report',str(base/(name+'.watchdog.json')),'--']+command
 with (base/(name+'.jsonl')).open('w') as out,(base/(name+'.stderr')).open('w') as err:
  status=subprocess.call(argv,cwd=repo/'v5',env=env,stdout=out,stderr=err)
 print(name,'exit',status,flush=True)
 if status:sys.exit(status)
