import concurrent.futures, hashlib, importlib.util, json, os, pathlib, subprocess, time, traceback
Q=pathlib.Path(__file__).parent
S=pathlib.Path('/var/tmp/rho-v5-v4516-reconcile-20261014/tools/v5-substrate/fdb')
N=pathlib.Path('/var/tmp/rho-fdb-graph-cdc-launcher-exec-20261010-lay9hngb/native')
IMAGE='sha256:37cfcca63222ec499bec5e8ad7aad52dbf7529db36d5812b8eae2f0621aa92d6'
TAG='rho-fdb-stream-20261014-'+str(os.getpid())
parents='^(TestGraphCostStreamRejectsInvalidBoundsAndRawKeys|TestGraphCostStreamActualPagesOldCutOriginalsAndQuiescence)$'
owned=[]; network=None
spec=importlib.util.spec_from_file_location('monitor',S/'cost_monitor.py'); monitor=importlib.util.module_from_spec(spec); spec.loader.exec_module(monitor)
def save(name,data): (Q/name).write_text(json.dumps(data,indent=2)+'\n')
def run(label,args,seconds=45,check=True):
 start=time.monotonic()
 try:
  r=subprocess.run(args,capture_output=True,timeout=seconds)
  code=r.returncode; out=r.stdout; err=r.stderr
 except subprocess.TimeoutExpired as e:
  code=124;out=e.stdout or b'';err=(e.stderr or b'')+b'\nexternal command deadline\n'
 (Q/(label+'.stdout')).write_bytes(out);(Q/(label+'.stderr')).write_bytes(err)
 with (Q/'commands.jsonl').open('a') as f: f.write(json.dumps({'label':label,'argv':args,'deadlineSeconds':seconds,'elapsedSeconds':time.monotonic()-start,'exit':code})+'\n')
 if check and code: raise RuntimeError(label+' exit '+str(code))
 return out.decode(errors='replace'),code

def common(name,mem,networkName=None):
 args=['docker','create','--pull=never','--name',name,'--label','rho.qualifier='+TAG,'--memory',mem,'--memory-swap',mem,'--cpus','0.375' if mem=='512m' else '0.5','--pids-limit','512','--network',networkName or 'none','-v',str(N)+':/native:ro','-v',str(Q)+':/out','-e','LD_LIBRARY_PATH=/native/lib']
 owned.append(name)
 return args

def client(label,script,cluster=False):
 name=TAG+'-'+label
 args=common(name,'2048m',network if cluster else None)
 args+=['-v',str(S)+':/src:ro','-v','/Users/markusnissl/go/pkg/mod:/gomod:ro','-e','GOMODCACHE=/gomod','-v','rho-tkg-gocache:/go','-v','rho-tkg-buildcache:/root/.cache/go-build','-w','/src']
 for env in ['GOMAXPROCS=2','GOMEMLIMIT=2GiB','GOFLAGS=-p=1','GOWORK=off','GOTOOLCHAIN=local','GOPROXY=off','CGO_CFLAGS=-I/native/include','CGO_LDFLAGS=-L/native/lib']:
  args+=['-e',env]
 if cluster:args+=['-e','FDB_CONNECTION_STRING='+connection]
 payload="trap 'r=$?; cat /sys/fs/cgroup/memory.current /sys/fs/cgroup/memory.peak /sys/fs/cgroup/memory.stat > /out/"+label+"-cgroup.txt; exit $r' EXIT; "+script
 run(label+'-create',args+[IMAGE,'/bin/bash','-c',payload])
 run(label+'-inspect',['docker','inspect',name])
 start=time.monotonic();run(label+'-start',['docker','start',name])
 peak=0;reason='completed'
 try:
  with (Q/(label+'-rss.jsonl')).open('x') as f,concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
   while True:
    state=json.loads(run(label+'-poll',['docker','inspect','--format','{{json .State}}',name],check=True)[0])
    if not state['Running']: break
    names=servers+[name] if cluster else [name]
    observations=list(pool.map(lambda n:monitor.sample(n,True),names))
    pids=[p['pid'] for c in observations for p in c['processes']]
    if len(pids)!=len(set(pids)):raise RuntimeError('duplicate actual PID')
    rss=sum(p['rssKiB'] for c in observations for p in c['processes']);peak=max(peak,rss)
    f.write(json.dumps({'elapsedSeconds':time.monotonic()-start,'rssKiB':rss,'containers':observations})+'\n');f.flush()
    if rss>4096*1024:reason='aggregate-rss-limit';raise RuntimeError(reason)
    if time.monotonic()-start>=180:reason='deadline';raise RuntimeError(reason)
    time.sleep(.5)
 except Exception:
  reason='monitor-or-runtime-error' if reason=='completed' else reason
  run(label+'-kill',['docker','kill',name],check=False)
  raise
 finally:
  run(label+'-terminal',['docker','inspect',name],check=False)
  run(label+'-logs',['docker','logs',name],check=False)
  save(label+'-watchdog.json',{'secondsLimit':180,'rssLimitMiB':4096,'sampledPeakAggregateRSSKiB':peak,'elapsedSeconds':time.monotonic()-start,'reason':reason,'aggregateContainerMemoryAdmissionMiB':4096 if cluster else 2048,'accounting':'sum of actual Linux processes sampled by docker top; cgroup hard limits separately recorded; not host Docker CLI RSS'})
 state=json.loads((Q/(label+'-terminal.stdout')).read_text())[0]['State']
 if state['Running'] or state['OOMKilled'] or state['ExitCode']:raise RuntimeError(label+' genuine terminal '+str(state))
 print(label+' PASS',flush=True)

def inventory():
 return {str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(S.iterdir()) if p.is_file() and (p.suffix=='.go' or p.name in ['go.mod','go.sum','.golangci.yml'])}

save('source-before.json',inventory());save('native-before.json',{str(p.relative_to(N)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(N.rglob('*')) if p.is_file() and p.name!='fdb.cluster'})
run('image',['docker','image','inspect',IMAGE]);run('docker-before',['docker','ps','-a']);run('volumes-before',['docker','volume','ls'])
servers=[];connection='';result='not completed'
try:
 client('provenance',"set -e; /usr/local/go/bin/go version; sha256sum /usr/local/go/bin/go /usr/local/go/pkg/tool/linux_arm64/compile /usr/local/go/pkg/tool/linux_arm64/link /native/bin/* /native/lib/* /native/include/foundationdb/*; /native/bin/fdbserver --version; /native/bin/fdbcli --version; ldd /native/bin/* /native/lib/*; /usr/local/go/bin/go mod verify; ls /go/bin; find /go/pkg/mod -maxdepth 4 -path '*foundationdb*'")
 network=TAG+'-network';run('network-create',['docker','network','create','--internal','--label','rho.qualifier='+TAG,network])
 net=json.loads(run('network-inspect',['docker','network','inspect',network])[0])[0]
 subnet=net['IPAM']['Config'][0]['Subnet'].split('/')[0].split('.')
 ips=['.'.join(subnet[:3]+[str(10+i)]) for i in range(4)]
 connection='rho_stream:'+TAG.replace('-','')+'@'+','.join(ip+':4500' for ip in ips[:3])
 (Q/'fdb.cluster').write_text(connection+'\n')
 for i,ip in enumerate(ips):
  name=TAG+'-zone'+str(i);servers.append(name)
  script=f'exec /native/bin/fdbserver -C /out/fdb.cluster -p {ip}:4500 -l 0.0.0.0:4500 --datadir /state/data --logdir /state/logs --locality-zoneid=zone{i} --locality-machineid=zone{i} --memory 384MiB --storage-memory 64MiB --cache-memory 64MiB --maxlogssize 20MiB'
  (Q/('state-zone'+str(i))).mkdir()
  run('server'+str(i)+'-create',common(name,'512m',network)+['--ip',ip,'-v',str(Q/('state-zone'+str(i)))+':/state',IMAGE,'/bin/bash','-c','mkdir -p /state/data /state/logs; '+script])
  run('server'+str(i)+'-start',['docker','start',name]);run('server'+str(i)+'-inspect',['docker','inspect',name])
 run('configure',['docker','exec',servers[0],'/native/bin/fdbcli','-C','/out/fdb.cluster','--timeout','30','--exec','configure new triple ssd'])
 for i in range(90):
  out,code=run('status-'+str(i),['docker','exec',servers[0],'/native/bin/fdbcli','-C','/out/fdb.cluster','--timeout','3','--exec','status json'],10,False)
  if code==0:
   try:
    spec2=importlib.util.spec_from_file_location('launcher',S/'launcher.py'); l=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(l);l.healthy(json.loads(out));break
   except (ValueError,KeyError,AssertionError):pass
  time.sleep(1)
 else:raise RuntimeError('healthy fully replicated triple never observed')
 for label,flags in [('normal',''),('race','-race'),('cover','-coverprofile=/out/coverage.out -covermode=atomic')]:
  client(label,"/usr/local/go/bin/go test -json -count=1 -timeout=150s "+flags+" -run '"+parents+"' .",True)
  run(label+'-reset',['docker','exec',servers[0],'/native/bin/fdbcli','-C','/out/fdb.cluster','--timeout','10','--exec','writemode on; clearrange g0/ g2/; getrange g0/ g2/'])
 client('vet','/usr/local/go/bin/go vet .')
 client('cover-report','/usr/local/go/bin/go tool cover -func=/out/coverage.out')
 result='normal/race/coverage/vet PASS; scanner gates pending'
except Exception:
 result='ERROR';(Q/'failure.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
 cleanup=[]
 for name in reversed(owned):
  run(name+'-final',['docker','inspect',name],check=False);run(name+'-final-log',['docker','logs',name],check=False)
  _,code=run(name+'-remove',['docker','rm','-f',name],45,False);cleanup.append({'name':name,'removeExit':code})
 if network:run('network-remove',['docker','network','rm',network],45,False)
 run('docker-after',['docker','ps','-a']);run('networks-after',['docker','network','ls']);save('cleanup.json',cleanup)
 save('source-after.json',inventory());save('terminal.json',{'result':result,'sourceUnchanged':inventory()==json.loads((Q/'source-before.json').read_text()),'ownedContainers':owned,'ownedNetwork':network})
 print('TERMINAL '+result,flush=True)
