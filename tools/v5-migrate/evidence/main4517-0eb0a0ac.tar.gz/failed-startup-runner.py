from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
W=Path('/var/tmp/rho-v5-v4516-reconcile-20261014'); Q=Path(__file__).parent
GO=Path('/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go')
LIMIT=Path('/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py')
MOD=W/'tools/v5-migrate'; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((Q/'inputs.json').read_text()); frozen=json.loads((Q/'source.json').read_text())
spec=importlib.util.spec_from_file_location('owned_limiter',LIMIT); limiter=importlib.util.module_from_spec(spec); spec.loader.exec_module(limiter)
env=os.environ.copy(); env.update(GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOBIN=str(Q/'scanner-bin'),PATH=str(GO.parent)+':'+str(Q/'scanner-bin')+':'+env['PATH'])
(Q/'environment.json').write_text(json.dumps({k:env[k] for k in ['GOTOOLCHAIN','GOWORK','GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GOBIN','PATH']},indent=2)+'\n')

def version(label):
 assert sha(GO)==frozen['compilerSHA256']
 v=subprocess.check_output([str(GO),'version'],cwd=MOD,env=env,text=True); assert v.startswith('go version go1.26.9 '),v
 info=subprocess.check_output([str(GO),'env','GOROOT','GOVERSION','GOMOD'],cwd=MOD,env=env,text=True)
 assert info.splitlines()[1]=='go1.26.9' and info.splitlines()[2]==str(MOD/'go.mod'),info
 (Q/(label+'-compiler.txt')).write_text(v+info+'binarySHA256 '+sha(GO)+'\n')

def scanner_metadata(label):
 result={}
 for name,args in [('golangci-lint',['version']),('gosec',['-version']),('govulncheck',['-version'])]:
  p=Q/'scanner-bin'/name; body=subprocess.run([str(p),*args],cwd=MOD,env=env,capture_output=True,text=True,check=True)
  build=subprocess.check_output([str(GO),'version','-m',str(p)],env=env,text=True)
  (Q/(label+'-'+name+'-version.txt')).write_text(body.stdout+body.stderr); (Q/(label+'-'+name+'-build.txt')).write_text(build); result[name]=sha(p)
 (Q/(label+'-scanner-sha256.json')).write_text(json.dumps(result,indent=2)+'\n'); return result

version('initial'); scanner_metadata('initial')
checks={}; all_owned={}
for target in ['fmt-check','vet','build','test','test-race','cover-gate','tools','lint','security','vulncheck']:
 for p,h in inputs.items(): assert sha(W/p)==h,p
 if target in ['test','test-race','cover-gate']: version(target)
 cmd=['make',target,'GO='+str(GO)]; start=time.time()
 with (Q/(target+'.stdout')).open('w') as stdout,(Q/(target+'.stderr')).open('w') as stderr:
  p=subprocess.Popen([sys.executable,str(LIMIT),'--rss-mib','4096','--seconds','180','--report',str(Q/(target+'-watchdog.json')),'--',*cmd],cwd=MOD,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  tree=limiter.Tree(p); observed={}
  while p.poll() is None:
   tree.sample(); observed.update(tree.known); time.sleep(.25)
  code=p.wait(); observed.update(tree.known)
 live=limiter.processes(); survivors={pid:birth for pid,birth in observed.items() if pid in live and live[pid][3]==birth}; assert not survivors,(target,survivors)
 all_owned.update(observed); profile=json.loads((Q/(target+'-watchdog.json')).read_text())
 checks[target]={'target':target,'command':cmd,'supervisorPID':p.pid,'startedUnix':start,'finishedUnix':time.time(),'exitCode':code,'profile':profile,'observedIdentities':{str(pid):birth for pid,birth in observed.items()},'observedIdentitiesAbsent':True}
 (Q/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(target,'PASS' if code==0 else 'FAIL',json.dumps(profile),flush=True)
 if code: sys.exit(code)
 if target=='tools':
  after=scanner_metadata('after-tools'); assert after==json.loads((Q/'scanner-before-sha256.json').read_text()),'cached pinned tool bytes changed'
for p,h in inputs.items(): assert sha(W/p)==h,p
live=limiter.processes(); survivors={pid:birth for pid,birth in all_owned.items() if pid in live and live[pid][3]==birth}; assert not survivors,survivors
(Q/'terminal.json').write_text(json.dumps({'exit':0,'targets':list(checks),'all2250InputsUnchanged':True,'observedIdentityCount':len(all_owned),'observedIdentitiesAbsent':True,'allWatchdogsTerminal':True},indent=2)+'\n')
print('ALL TEN PASS; observed owned identities absent; inputs unchanged',flush=True)
