#!/usr/bin/env python3
"""Run a command with an aggregate process-tree RSS watchdog and deadline.

This is a sampled RSS limit, not a kernel allocation limit: a command can
overshoot between samples. GOMEMLIMIT alone does not bound all workers or mmap.
Use a budget well below host RAM. Only processes belonging to this invocation
are terminated; commands must not daemonize between observations.
"""
import argparse
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time


def positive_finite(value):
    if not math.isfinite(value) or value <= 0:
        raise ValueError("memory and time limits must be finite and positive")
    return value


def parse_rss_mib(text):
    """Bare numbers are MiB; byte units use binary scaling, like MemoryMax."""
    match = re.fullmatch(r"(\d+(?:\.\d*)?|\.\d+)([KMGT](?:i?B)?|B)?", text, re.IGNORECASE)
    if match is None:
        raise argparse.ArgumentTypeError("memory must be positive MiB or a size such as 512MiB or 2G")
    unit = (match[2] or "M").upper()
    power = {"B": -2, "K": -1, "M": 0, "G": 1, "T": 2}[unit[0]]
    try:
        return positive_finite(float(match[1]) * 1024 ** power)
    except ValueError as error:
        raise argparse.ArgumentTypeError(str(error)) from error


def parse_seconds(text):
    """Accept seconds or composed durations, for example 1m30s."""
    try:
        value = float(text)
    except ValueError:
        parts = re.findall(r"(\d+(?:\.\d*)?|\.\d+)(ns|us|ms|s|m|h)", text)
        if not parts or "".join(number + unit for number, unit in parts) != text:
            raise argparse.ArgumentTypeError("deadline must be seconds or a duration such as 1m30s")
        factors = {"ns": 1e-9, "us": 1e-6, "ms": 1e-3, "s": 1, "m": 60, "h": 3600}
        value = sum(float(number) * factors[unit] for number, unit in parts)
    try:
        return positive_finite(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError(str(error)) from error


def processes():
    result = subprocess.run(
        ["/bin/ps", "-axo", "pid=,ppid=,pgid=,rss=,lstart="],
        capture_output=True, text=True, check=True, timeout=10,
    )
    rows = {}
    for line in result.stdout.splitlines():
        pid, parent, group, rss, started = line.split(maxsplit=4)
        rows[int(pid)] = (int(parent), int(group), int(rss), started)
    return rows


class Tree:
    def __init__(self, child):
        self.child = child
        self.known = {}

    def sample(self):
        rows = processes()
        # Keep process identity as well as PID so a recycled PID is not ours.
        self.known = {pid: birth for pid, birth in self.known.items()
                      if pid in rows and rows[pid][3] == birth}
        for pid, (_, group, _, birth) in rows.items():
            if group == self.child.pid:
                self.known[pid] = birth
        while True:
            descendants = {pid: birth for pid, (parent, _, _, birth) in rows.items()
                           if parent in self.known}
            if descendants.keys() <= self.known.keys():
                break
            self.known.update(descendants)
        return sum(rows[pid][2] for pid in self.known)

    def stop(self):
        # The child's process group also covers descendants born since the
        # last sample. Separately tracked descendants may have changed groups.
        try:
            os.killpg(self.child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        live = processes()
        for pid, birth in self.known.items():
            if pid in live and live[pid][3] == birth:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        self.child.wait()


def supervise(command, rss_mib, seconds, report=None):
    positive_finite(rss_mib)
    positive_finite(seconds)
    if not command:
        raise ValueError("a command is required")
    started = time.monotonic()
    env = dict(os.environ, TYLA_BENCH_LIMIT_PID=str(os.getpid()))
    tree = None
    peak = 0
    reason = "completed"
    code = 126

    interrupted_signal = None

    def interrupted(sig, frame):
        # Record instead of raising between Popen returning and Tree creation.
        # The monitoring loop then owns cleanup even during process startup.
        nonlocal interrupted_signal
        interrupted_signal = sig

    watched_signals = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT)
    old_handlers = {sig: signal.signal(sig, interrupted) for sig in watched_signals}
    try:
        child = subprocess.Popen(command, env=env, start_new_session=True)
        tree = Tree(child)
        while True:
            if interrupted_signal is not None:
                reason, code = "interrupted", 130
                break
            rss = tree.sample()
            peak = max(peak, rss)
            if rss > rss_mib * 1024:
                reason, code = "memory-limit", 125
                break
            if time.monotonic() - started >= seconds:
                reason, code = "time-limit", 124
                break
            status = child.poll()
            if status is not None:
                code = status if status >= 0 else 128 - status
                if code:
                    reason = "command-failed"
                break
            time.sleep(0.25)
    except KeyboardInterrupt:
        reason, code = "interrupted", 130
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        # Loss of monitoring must terminate the workload, not leave it uncapped.
        reason, code = "monitor-failed", 126
        print(f"limit: {error}", file=sys.stderr)
    finally:
        try:
            if tree is not None:
                tree.stop()
        finally:
            for sig, handler in old_handlers.items():
                signal.signal(sig, handler)
    record = {
        "command": command, "rss_limit_mib": rss_mib,
        "wall_limit_s": seconds, "sample_interval_s": 0.25,
        "peak_tree_rss_mib": round(peak / 1024, 3),
        "elapsed_s": round(time.monotonic() - started, 3),
        "exit_code": code, "reason": reason,
    }
    if report:
        Path(report).write_text(json.dumps(record, indent=2) + "\n")
    print("limit: " + json.dumps(record), file=sys.stderr)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rss-mib", type=parse_rss_mib, required=True,
                        help="process-tree RSS ceiling in MiB, or a byte size such as 2G")
    parser.add_argument("--seconds", type=parse_seconds, required=True,
                        help="whole-command deadline in seconds, or a duration such as 10m")
    parser.add_argument("--report", help="write supervision metadata as JSON")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    try:
        return supervise(command, args.rss_mib, args.seconds, args.report)
    except (OSError, ValueError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    sys.exit(main())
