module github.com/data-insights-ai/rho-tkg/tools/v5-migrate

go 1.26.9

require (
	github.com/data-insights-ai/rho-tkg/v4 v4.51.5
	github.com/data-insights-ai/rho-tkg/v5 v5.0.0
)

require (
	github.com/bds421/rho-mclock v0.2.1 // indirect
	github.com/bds421/rho-snowflake-2026 v1.3.2 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/dgraph-io/badger/v4 v4.9.2 // indirect
	github.com/dgraph-io/ristretto/v2 v2.2.0 // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/google/flatbuffers v25.2.10+incompatible // indirect
	github.com/klauspost/compress v1.18.7 // indirect
	github.com/vmihailenco/msgpack/v5 v5.4.1 // indirect
	github.com/vmihailenco/tagparser/v2 v2.0.0 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/otel v1.42.0 // indirect
	go.opentelemetry.io/otel/metric v1.42.0 // indirect
	go.opentelemetry.io/otel/trace v1.42.0 // indirect
	golang.org/x/sys v0.44.0 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)

replace github.com/data-insights-ai/rho-tkg/v4 => ../..

replace github.com/data-insights-ai/rho-tkg/v5 => ../../v5
