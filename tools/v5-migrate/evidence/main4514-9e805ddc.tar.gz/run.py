import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/var/tmp/rho-v5-main4513-integration-20261013').resolve();out=pathlib.Path(__file__).parent;cwd=root/'tools/v5-migrate';go=pathlib.Path('/Users/markusnissl/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.9.darwin-arm64/bin/go');limiter=pathlib.Path('/var/tmp/rho-v5-rebase-main-20261010-0mdr6yaw/limit-local.py')
env=dict(os.environ,GOMAXPROCS='2',GOMEMLIMIT='2GiB',GOFLAGS='-p=1',GOWORK='off',GOTOOLCHAIN='local',GOBIN=str(out/'scanner-bin'),PATH=str(out/'scanner-bin')+':'+str(go.parent)+':/opt/homebrew/bin:/usr/bin:/bin');(out/'scanner-bin').mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');sources={f:sha(root/f) for f in files if f and (f.endswith(('.go','go.mod','go.sum')) or f in ('tools/v5-migrate/Makefile','.golangci.yml'))}
(out/'inputs.json').write_text(json.dumps({'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceSHA256':sources,'env':{k:env[k] for k in ('GOMAXPROCS','GOMEMLIMIT','GOFLAGS','GOWORK','GOTOOLCHAIN','GOBIN','PATH')},'goSHA256':sha(go),'limiterSHA256':sha(limiter)},indent=2)+'\n');(out/'limit-local.py').write_bytes(limiter.read_bytes());(out/'toolchain-VERSION').write_bytes((go.parent.parent/'VERSION').read_bytes())
checks={}
def run(name,args,gate=False):
 report=out/(name+'-profile.json');started=time.time()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  p=subprocess.Popen(['python3',str(limiter),'--rss-mib','4096','--seconds','180','--report',str(report),'--',*args],cwd=cwd,env=env,stdout=stdout,stderr=stderr);print(name,'LIVE limiter PID',p.pid,flush=True);code=p.wait()
 checks[name]={'gate':gate,'command':args,'supervisorPID':p.pid,'startedUnix':started,'finishedUnix':time.time(),'exitCode':code,'profile':json.loads(report.read_text())};(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,'TERMINAL',code,flush=True)
 if code:raise SystemExit(code)
run('compiler-env',[str(go),'env','GOVERSION','GOOS','GOARCH','GOROOT','GOMOD','GOWORK'])
run('modules',[str(go),'list','-m','-json','all'])
for target in ('fmt-check','vet','build','test','test-race','cover-gate','tools','lint','security','vulncheck'):
 run(target,['make',target,'GO='+str(go)],True)
 if target=='cover-gate':(out/'coverage.out').write_bytes((cwd/'coverage.out').read_bytes())
 if target=='tools':
  for tool in ('golangci-lint','gosec','govulncheck'):run(tool+'-identity',[str(go),'version','-m',str(out/'scanner-bin'/tool)])
assert all(sha(root/f)==h for f,h in sources.items());print('ALL TEN GATES PASS; frozen source unchanged',flush=True)
