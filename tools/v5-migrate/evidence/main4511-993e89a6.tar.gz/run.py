import os,subprocess,json,time
from pathlib import Path
out=Path(__file__).parent
meta=json.loads((out/'inputs-before.json').read_text());go=meta['compiler_path'];env=dict(os.environ,**meta['environment']);env['PATH']=str(Path(go).parent)+':'+str(out/'scanner-bin')+':'+env['PATH'];module=Path('/var/tmp/rho-v5-migrate4511-prepare-20261012/tools/v5-migrate');events=[]
def run(name,cmd):
 print('START '+name,flush=True)
 log=out/(name+'.log');report=out/(name+'.resource.json')
 with log.open('w') as f:
  proc=subprocess.Popen(['python3',str(out/'limit-local.py'),'--rss-mib','4096','--seconds','180','--report',str(report),'--',*cmd],cwd=module,env=env,stdout=f,stderr=subprocess.STDOUT)
  events.append({'name':name,'supervisor_pid':proc.pid,'started_unix':time.time(),'command':cmd});(out/'session-events.json').write_text(json.dumps(events,indent=2)+'\n');rc=proc.wait();events[-1]['exit_code']=rc;events[-1]['finished_unix']=time.time();(out/'session-events.json').write_text(json.dumps(events,indent=2)+'\n')
 print('END '+name+' exit='+str(rc),flush=True)
 if rc: print(log.read_text()[-5000:],flush=True);raise SystemExit(rc)
run('compiler-version',[go,'version']);run('compiler-env',[go,'env','GOVERSION','GOOS','GOARCH','GOROOT','GOMOD','GOWORK']);run('modules',[go,'list','-m','-json','all'])
for target in ['fmt-check','vet','build','test','test-race','cover-gate','tools','lint','security','vulncheck']:
 run(target,['make',target,'GO='+go])
 if target=='tools':
  for tool in ['golangci-lint','gosec','govulncheck']:run(tool+'-build-identity',[go,'version','-m',str(out/'scanner-bin'/tool)])
print('TEN_GATES_TERMINAL_SUCCESS',flush=True)
